# Champion simulator coverage

67 of 173 champions have simulator kits; 106 remain. This covers 2,211 unordered simulated pairings.

A simulator kit is implemented coverage, not a certification of every mechanic. Each kit page records source revisions and explicit assumptions. Other champions retain interaction estimates until their kit is implemented and checked.

## Implemented kits

| Champion | ID | Source reads | Assumptions |
|---|---|--:|--:|
| Aatrox | Aatrox | 49 | 3 |
| Ahri | Ahri | 73 | 4 |
| Akali | Akali | 52 | 5 |
| Ambessa | Ambessa | 46 | 6 |
| Amumu | Amumu | 47 | 4 |
| Annie | Annie | 64 | 8 |
| Ashe | Ashe | 43 | 8 |
| Aurora | Aurora | 52 | 2 |
| Brand | Brand | 56 | 7 |
| Camille | Camille | 41 | 4 |
| Cassiopeia | Cassiopeia | 52 | 9 |
| Cho'Gath | Chogath | 42 | 3 |
| Darius | Darius | 49 | 2 |
| Dr. Mundo | DrMundo | 40 | 3 |
| Fiora | Fiora | 50 | 3 |
| Gangplank | Gangplank | 57 | 5 |
| Garen | Garen | 32 | 3 |
| Gnar | Gnar | 70 | 7 |
| Gwen | Gwen | 52 | 5 |
| Heimerdinger | Heimerdinger | 77 | 9 |
| Illaoi | Illaoi | 68 | 12 |
| Irelia | Irelia | 45 | 6 |
| Jax | Jax | 35 | 3 |
| Jayce | Jayce | 66 | 4 |
| K'Sante | KSante | 55 | 3 |
| Kassadin | Kassadin | 56 | 6 |
| Kayle | Kayle | 40 | 2 |
| Kennen | Kennen | 47 | 3 |
| Kled | Kled | 88 | 7 |
| Leona | Leona | 53 | 4 |
| Lissandra | Lissandra | 70 | 6 |
| Lux | Lux | 48 | 4 |
| Malphite | Malphite | 41 | 1 |
| Master Yi | MasterYi | 51 | 5 |
| Mordekaiser | Mordekaiser | 38 | 5 |
| Morgana | Morgana | 43 | 4 |
| Nasus | Nasus | 40 | 2 |
| Nautilus | Nautilus | 58 | 6 |
| Olaf | Olaf | 36 | 3 |
| Ornn | Ornn | 50 | 6 |
| Pantheon | Pantheon | 51 | 7 |
| Poppy | Poppy | 50 | 3 |
| Quinn | Quinn | 39 | 4 |
| Rammus | Rammus | 56 | 7 |
| Renekton | Renekton | 53 | 3 |
| Riven | Riven | 47 | 4 |
| Rumble | Rumble | 62 | 5 |
| Sett | Sett | 36 | 6 |
| Shen | Shen | 29 | 4 |
| Singed | Singed | 42 | 4 |
| Sion | Sion | 75 | 5 |
| Skarner | Skarner | 62 | 5 |
| Tahm Kench | TahmKench | 61 | 4 |
| Teemo | Teemo | 29 | 2 |
| Trundle | Trundle | 43 | 3 |
| Tryndamere | Tryndamere | 34 | 3 |
| Udyr | Udyr | 80 | 11 |
| Urgot | Urgot | 50 | 5 |
| Vayne | Vayne | 47 | 7 |
| Veigar | Veigar | 48 | 11 |
| Vladimir | Vladimir | 64 | 10 |
| Volibear | Volibear | 50 | 4 |
| Xin Zhao | XinZhao | 65 | 6 |
| Yasuo | Yasuo | 49 | 4 |
| Yone | Yone | 34 | 3 |
| Yorick | Yorick | 81 | 9 |
| Zaahen | Zaahen | 61 | 5 |

## Remaining implementation queue

- [ ] Akshan (Akshan)
- [ ] Alistar (Alistar)
- [ ] Anivia (Anivia)
- [ ] Aphelios (Aphelios)
- [ ] Aurelion Sol (AurelionSol)
- [ ] Azir (Azir)
- [ ] Bard (Bard)
- [ ] Bel'Veth (Belveth)
- [ ] Blitzcrank (Blitzcrank)
- [ ] Braum (Braum)
- [ ] Briar (Briar)
- [ ] Caitlyn (Caitlyn)
- [ ] Corki (Corki)
- [ ] Diana (Diana)
- [ ] Draven (Draven)
- [ ] Ekko (Ekko)
- [ ] Elise (Elise)
- [ ] Evelynn (Evelynn)
- [ ] Ezreal (Ezreal)
- [ ] Fiddlesticks (Fiddlesticks)
- [ ] Fizz (Fizz)
- [ ] Galio (Galio)
- [ ] Gragas (Gragas)
- [ ] Graves (Graves)
- [ ] Hecarim (Hecarim)
- [ ] Hwei (Hwei)
- [ ] Ivern (Ivern)
- [ ] Janna (Janna)
- [ ] Jarvan IV (JarvanIV)
- [ ] Jhin (Jhin)
- [ ] Jinx (Jinx)
- [ ] Kai'Sa (Kaisa)
- [ ] Kalista (Kalista)
- [ ] Karma (Karma)
- [ ] Karthus (Karthus)
- [ ] Katarina (Katarina)
- [ ] Kayn (Kayn)
- [ ] Kha'Zix (Khazix)
- [ ] Kindred (Kindred)
- [ ] Kog'Maw (KogMaw)
- [ ] LeBlanc (Leblanc)
- [ ] Lee Sin (LeeSin)
- [ ] Lillia (Lillia)
- [ ] Locke (Locke)
- [ ] Lucian (Lucian)
- [ ] Lulu (Lulu)
- [ ] Malzahar (Malzahar)
- [ ] Maokai (Maokai)
- [ ] Mel (Mel)
- [ ] Milio (Milio)
- [ ] Miss Fortune (MissFortune)
- [ ] Wukong (MonkeyKing)
- [ ] Naafiri (Naafiri)
- [ ] Nami (Nami)
- [ ] Neeko (Neeko)
- [ ] Nidalee (Nidalee)
- [ ] Nilah (Nilah)
- [ ] Nocturne (Nocturne)
- [ ] Nunu & Willump (Nunu)
- [ ] Orianna (Orianna)
- [ ] Pyke (Pyke)
- [ ] Qiyana (Qiyana)
- [ ] Rakan (Rakan)
- [ ] Rek'Sai (RekSai)
- [ ] Rell (Rell)
- [ ] Renata Glasc (Renata)
- [ ] Rengar (Rengar)
- [ ] Ryze (Ryze)
- [ ] Samira (Samira)
- [ ] Sejuani (Sejuani)
- [ ] Senna (Senna)
- [ ] Seraphine (Seraphine)
- [ ] Shaco (Shaco)
- [ ] Shyvana (Shyvana)
- [ ] Sivir (Sivir)
- [ ] Smolder (Smolder)
- [ ] Sona (Sona)
- [ ] Soraka (Soraka)
- [ ] Swain (Swain)
- [ ] Sylas (Sylas)
- [ ] Syndra (Syndra)
- [ ] Taliyah (Taliyah)
- [ ] Talon (Talon)
- [ ] Taric (Taric)
- [ ] Thresh (Thresh)
- [ ] Tristana (Tristana)
- [ ] Twisted Fate (TwistedFate)
- [ ] Twitch (Twitch)
- [ ] Varus (Varus)
- [ ] Vel'Koz (Velkoz)
- [ ] Vex (Vex)
- [ ] Vi (Vi)
- [ ] Viego (Viego)
- [ ] Viktor (Viktor)
- [ ] Warwick (Warwick)
- [ ] Xayah (Xayah)
- [ ] Xerath (Xerath)
- [ ] Yunara (Yunara)
- [ ] Yuumi (Yuumi)
- [ ] Zac (Zac)
- [ ] Zed (Zed)
- [ ] Zeri (Zeri)
- [ ] Ziggs (Ziggs)
- [ ] Zilean (Zilean)
- [ ] Zoe (Zoe)
- [ ] Zyra (Zyra)
