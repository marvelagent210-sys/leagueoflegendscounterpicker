# Private Counter Picker

This ZIP contains a static build from the private development workspace, including
the accuracy corrections and the implemented champion expansion batches. These source
changes may still be uncommitted on the repository's main branch.

On a computer, unzip the archive. In a terminal in the folder containing
counter-picker, run:

    python3 -m http.server 8000 --bind 127.0.0.1 --directory counter-picker

On Windows, use python instead of python3 if that is how Python is installed.
Open http://127.0.0.1:8000 in a browser on that same computer.
Press Ctrl+C in the terminal to stop the server.

The computer server binds to its loopback interface. Opening index.html directly
will not work reliably because the app uses module workers and fetched data.
Optional Google Fonts are requested externally; fallback fonts remain available.

For a phone, use the private Codespaces setup:

https://codespaces.new/marvelagent210-sys/leagueoflegendscounterpicker/tree/counter-picker-download-5d28e245?quickstart=1

Sign in to GitHub, select Create codespace, and wait for port 8000 to open. Keep
the port visibility Private. A stopped or sleeping Codespace does not serve the
app. An existing Codespace with an older build does not automatically update;
the link above starts the setup for this packaged build.

Model fingerprint: 5d28e2451925b24ce97f0b72890ba8fb1047125bd6b1da3b3e2cd637530a06c4
Dataset: 16.20; patch: 26.20; 85 simulator kits; 3,570 unordered pairings.
The other 88 champions use interaction estimates until their simulator kits are
implemented. Coverage is not certification of every mechanic. Read ACCURACY.md
for validation and remaining limits, and COVERAGE.md for the implementation queue.
DATA-LICENSE.md and WIKI-REVISIONS.json retain the data attribution and revisions.

The SOURCE folder contains the exact working source and parsed inputs behind
this build, including changes not yet committed on main. It excludes dependencies,
raw downloads, generated web exports, caches, Git metadata and credential files.
With Node.js 22.19 or later installed, open a terminal in counter-picker/SOURCE:

    npm ci
    npm run typecheck
    npm run build:sim -- --dataset 16.20 --check
    npm run build:web

To run development mode, use npm run dev. After changing simulator inputs, refresh
the pairings with npm run build:sim -- --dataset 16.20 --threads 4 before rebuilding.
The included tests can be run with npm test; see ACCURACY.md for the recorded
passed, failed and skipped outcomes. The source snapshot's freshness was checked
against the same fingerprint as the packaged browser matrix.
