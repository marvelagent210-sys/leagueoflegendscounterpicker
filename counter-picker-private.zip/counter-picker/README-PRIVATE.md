# Private Counter Picker

This package contains the current production build from the private development workspace.
It includes the latest accuracy changes, which are not yet published on GitHub Pages.

Unzip the archive. In a terminal in the folder containing counter-picker, run:

    python3 -m http.server 8000 --bind 127.0.0.1 --directory counter-picker

On Windows, use python instead of python3 if that is how Python is installed.
Open http://127.0.0.1:8000 in a browser on that same computer.
Press Ctrl+C in the terminal to stop the server.

The server binds only to your computer's loopback interface. This does not deploy
the app publicly or make your GitHub repository public. Opening index.html directly
will not work reliably because the app uses module workers and fetched data.
Optional Google Fonts are requested externally; fallback fonts remain available.

Model fingerprint: b1311dfa0642fc86d3a56e9fc15813dd6c5e9fd884918287d3c16eab1c97194b
Dataset: 16.20; 49 simulator kits.
The model still has documented limits. See ACCURACY.md in this package.
