# Counters to Nunu & Willump (patch 26.20)

Every champion ranked by what its kit does against Nunu & Willump's, from the interaction ledger: projectile blocks, spell shields,
parries, dash stops, crowd control and its defenses, range and more (PLAN.md §5). This ranking is **partial**: it weighs the
interactions but doesn't play the fight out. The duel simulator replaces it as each champion's behavior is verified.

"For" sums the interactions in the champion's favor, "against" those in Nunu & Willump's; net = for − against.
A hard counter shuts down part of a kit every time it is used (projectile block, attack dodge, attack block, blind, disarm, attack speed slow, attack reflect, dash stop, grounding, range) with an impact of 0.4 or more (0.5 for range).
Run `npm run matchup -- <champion> Nunu` for the full ledger of a matchup, with sources.

## Top 10

### 1. Rell (net +2.33)

- **0.35** interrupt: Ferromancy: Crash Down's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Ferromancy: Crash Down must land during the channel. (Rell W Ferromancy: Crash Down → Nunu & Willump W Biggest Snowball Ever!)
- **0.35** interrupt: Ferromancy: Mount Up's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Ferromancy: Mount Up must land during the channel. (Rell W Ferromancy: Mount Up → Nunu & Willump W Biggest Snowball Ever!)
- **0.35** interrupt: Full Tilt's stun interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Full Tilt must land during the channel. (Rell E Full Tilt → Nunu & Willump W Biggest Snowball Ever!)

### 2. Sivir (net +1.99)

- **0.94** range: Sivir's basic attacks reach 375 units farther than Nunu & Willump's (500 vs 125 attack range). Nunu & Willump has no dash or blink to close the gap. (Sivir basic attacks → Nunu & Willump basic attacks)
- **0.61** spell shield: Spell Shield's spell shield blocks Nunu & Willump's Biggest Snowball Ever!. Spell shield for 1.5 s, long enough to use ahead of Biggest Snowball Ever!. A spell shield blocks only the first enemy ability that reaches it. (Sivir E Spell Shield → Nunu & Willump W Biggest Snowball Ever!)
- **0.55** spell shield: Spell Shield's spell shield blocks Nunu & Willump's Absolute Zero. Spell shield for 1.5 s, long enough to use ahead of Absolute Zero. A spell shield blocks only the first enemy ability that reaches it. (Sivir E Spell Shield → Nunu & Willump R Absolute Zero)

### 3. Yasuo (net +1.58)

- **0.53** projectile block: Wind Wall blocks Nunu & Willump's Snowball Barrage, a projectile. Wind Wall for 4 s, long enough to use ahead of Snowball Barrage. (Yasuo W Wind Wall → Nunu & Willump E Snowball Barrage)
- **0.35** interrupt: Steel Tempest's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Steel Tempest must land during the channel. (Yasuo Q Steel Tempest → Nunu & Willump W Biggest Snowball Ever!)
- **0.31** projectile block: Wind Wall blocks part of Nunu & Willump's Biggest Snowball Ever!, a projectile. Wind Wall for 4 s, long enough to use ahead of Biggest Snowball Ever!. Only part of the ability is a projectile. Projectile-interception effects will destroy the snowball only after it has been released. (Yasuo W Wind Wall → Nunu & Willump W Biggest Snowball Ever!)

### 4. Xayah (net +1.57)

- **0.77** range: Xayah's basic attacks reach 400 units farther than Nunu & Willump's (525 vs 125 attack range). Nunu & Willump has no dash or blink to close the gap. (Xayah basic attacks → Nunu & Willump basic attacks)
- **0.52** untargetable: Featherstorm makes Xayah untargetable, dodging Nunu & Willump's Absolute Zero. Untargetable for 1.5 s, long enough to use ahead of Absolute Zero. (Xayah R Featherstorm → Nunu & Willump R Absolute Zero)
- **0.34** untargetable: Featherstorm makes Xayah untargetable, dodging Nunu & Willump's Biggest Snowball Ever!. Untargetable for 1.5 s, long enough to use ahead of Biggest Snowball Ever!. (Xayah R Featherstorm → Nunu & Willump W Biggest Snowball Ever!)

### 5. Nocturne (net +1.56)

- **0.70** spell shield: Shroud of Darkness's spell shield blocks Nunu & Willump's Biggest Snowball Ever!. Spell shield for 1.5 s, long enough to use ahead of Biggest Snowball Ever!. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Nunu & Willump W Biggest Snowball Ever!)
- **0.63** spell shield: Shroud of Darkness's spell shield blocks Nunu & Willump's Snowball Barrage. Spell shield for 1.5 s, long enough to use ahead of Snowball Barrage. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Nunu & Willump E Snowball Barrage)
- **0.55** spell shield: Shroud of Darkness's spell shield blocks Nunu & Willump's Absolute Zero. Spell shield for 1.5 s, long enough to use ahead of Absolute Zero. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Nunu & Willump R Absolute Zero)
- Watch out: Biggest Snowball Ever! makes Nunu & Willump immune to Nocturne's Unspeakable Horror (slow).

### 6. Milio (net +1.52)

- **0.77** range: Milio's basic attacks reach 400 units farther than Nunu & Willump's (525 vs 125 attack range). Nunu & Willump has no dash or blink to close the gap. (Milio basic attacks → Nunu & Willump basic attacks)
- **0.35** interrupt: Ultra Mega Fire Kick's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Ultra Mega Fire Kick must land during the channel. (Milio Q Ultra Mega Fire Kick → Nunu & Willump W Biggest Snowball Ever!)
- **0.28** interrupt: Ultra Mega Fire Kick's airborne interrupts Nunu & Willump's Absolute Zero (normal channel). Ultra Mega Fire Kick must land during the channel. (Milio Q Ultra Mega Fire Kick → Nunu & Willump R Absolute Zero)
- Watch out: Biggest Snowball Ever! makes Nunu & Willump immune to Milio's Ultra Mega Fire Kick (slow).

### 7. Zaahen (net +1.52)

- **0.35** cc immunity: Grim Deliverance makes Zaahen immune to Nunu & Willump's Biggest Snowball Ever! (airborne, stun). Immune for ?; Biggest Snowball Ever! takes 1.76 s to land, enough to react. (Zaahen R Grim Deliverance → Nunu & Willump W Biggest Snowball Ever!)
- **0.35** interrupt: Dreaded Return's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Dreaded Return must land during the channel. (Zaahen W Dreaded Return → Nunu & Willump W Biggest Snowball Ever!)
- **0.35** interrupt: The Darkin Glaive's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). The Darkin Glaive must land during the channel. (Zaahen Q The Darkin Glaive → Nunu & Willump W Biggest Snowball Ever!)

### 8. Maokai (net +1.47)

- **0.70** untargetable: Twisted Advance makes Maokai untargetable, dodging Nunu & Willump's Biggest Snowball Ever!. Untargetable for 1.4 s; Biggest Snowball Ever! takes 1.76 s to land, enough to react. (Maokai W Twisted Advance → Nunu & Willump W Biggest Snowball Ever!)
- **0.70** untargetable: Twisted Advance makes Maokai untargetable, dodging Nunu & Willump's Snowball Barrage. Untargetable for 1.4 s; Snowball Barrage takes 0.35 s to land, enough to react. (Maokai W Twisted Advance → Nunu & Willump E Snowball Barrage)
- **0.42** untargetable: Twisted Advance makes Maokai untargetable, dodging Nunu & Willump's Consume. Untargetable for 1.4 s; Consume takes 0.3 s to land, enough to react. (Maokai W Twisted Advance → Nunu & Willump Q Consume)
- Watch out: Biggest Snowball Ever! makes Nunu & Willump immune to Maokai's Bramble Smash (slow).

### 9. Bard (net +1.44)

- **0.72** range: Bard's basic attacks reach 375 units farther than Nunu & Willump's (500 vs 125 attack range). Nunu & Willump has no dash or blink to close the gap. (Bard basic attacks → Nunu & Willump basic attacks)
- **0.55** untargetable: Tempered Fate makes Bard untargetable, dodging Nunu & Willump's Absolute Zero. Untargetable for 2.5 s, long enough to use ahead of Absolute Zero. (Bard R Tempered Fate → Nunu & Willump R Absolute Zero)
- **0.35** untargetable: Tempered Fate makes Bard untargetable, dodging Nunu & Willump's Biggest Snowball Ever!. Untargetable for 2.5 s, long enough to use ahead of Biggest Snowball Ever!. (Bard R Tempered Fate → Nunu & Willump W Biggest Snowball Ever!)
- Watch out: Biggest Snowball Ever! makes Nunu & Willump immune to Bard's Cosmic Binding (slow).

### 10. Renata Glasc (net +1.44)

- **0.77** range: Renata Glasc's basic attacks reach 425 units farther than Nunu & Willump's (550 vs 125 attack range). Nunu & Willump has no dash or blink to close the gap. (Renata Glasc basic attacks → Nunu & Willump basic attacks)
- **0.32** interrupt: Handshake's airborne interrupts Nunu & Willump's Biggest Snowball Ever! (movement channel). Handshake must land during the channel. (Renata Glasc Q Handshake → Nunu & Willump W Biggest Snowball Ever!)
- **0.28** interrupt: Handshake's airborne interrupts Nunu & Willump's Absolute Zero (normal channel). Handshake must land during the channel. (Renata Glasc Q Handshake → Nunu & Willump R Absolute Zero)
- Watch out: Biggest Snowball Ever! makes Nunu & Willump immune to Renata Glasc's Loyalty Program (slow).

## Full ranking

| # | Champion | Net | For | Against | Hard counters |
|--:|---|--:|--:|--:|---|
| 1 | Rell | +2.33 | 2.33 | 0.00 |  |
| 2 | Sivir | +1.99 | 1.99 | 0.00 | range (attacks) |
| 3 | Yasuo | +1.58 | 1.58 | 0.00 | projectile block (Wind Wall) |
| 4 | Xayah | +1.57 | 1.57 | 0.00 | range (attacks) |
| 5 | Nocturne | +1.56 | 1.76 | 0.20 |  |
| 6 | Milio | +1.52 | 1.72 | 0.20 | range (attacks) |
| 7 | Zaahen | +1.52 | 1.52 | 0.00 |  |
| 8 | Maokai | +1.47 | 1.69 | 0.22 |  |
| 9 | Bard | +1.44 | 1.58 | 0.14 | range (attacks) |
| 10 | Renata Glasc | +1.44 | 1.57 | 0.13 | range (attacks) |
| 11 | Yuumi | +1.43 | 1.84 | 0.41 | range (attacks) |
| 12 | Braum | +1.43 | 1.71 | 0.28 | projectile block (Unbreakable) |
| 13 | Alistar | +1.42 | 1.42 | 0.00 |  |
| 14 | Malzahar | +1.41 | 1.81 | 0.40 |  |
| 15 | Blitzcrank | +1.38 | 1.38 | 0.00 |  |
| 16 | Vayne | +1.35 | 1.35 | 0.00 | range (attacks) |
| 17 | Rek'Sai | +1.33 | 1.33 | 0.00 |  |
| 18 | Lulu | +1.30 | 1.59 | 0.29 | range (attacks) |
| 19 | Viktor | +1.30 | 1.51 | 0.21 | range (attacks) |
| 20 | Vladimir | +1.29 | 1.46 | 0.17 |  |
| 21 | Fizz | +1.26 | 1.57 | 0.31 |  |
| 22 | Gnar | +1.24 | 1.55 | 0.31 | range (attacks) |
| 23 | Taliyah | +1.22 | 1.82 | 0.60 | range (attacks) |
| 24 | Heimerdinger | +1.22 | 1.48 | 0.26 |  |
| 25 | Samira | +1.22 | 1.22 | 0.00 | range (attacks), projectile block (Blade Whirl) |
| 26 | Anivia | +1.18 | 1.42 | 0.24 |  |
| 27 | Morgana | +1.18 | 1.35 | 0.17 |  |
| 28 | K'Sante | +1.17 | 1.39 | 0.22 |  |
| 29 | Sona | +1.17 | 1.17 | 0.00 | range (attacks) |
| 30 | Kled | +1.14 | 1.33 | 0.19 |  |
| 31 | Elise | +1.14 | 1.14 | 0.00 | range (attacks) |
| 32 | Thresh | +1.13 | 1.37 | 0.24 |  |
| 33 | Janna | +1.10 | 1.56 | 0.46 | range (attacks) |
| 34 | Seraphine | +1.08 | 1.38 | 0.30 | range (attacks) |
| 35 | Sejuani | +1.07 | 1.35 | 0.28 |  |
| 36 | Kennen | +1.07 | 1.07 | 0.00 | range (attacks) |
| 37 | Kayle | +1.04 | 1.17 | 0.13 | range (attacks) |
| 38 | Fiora | +1.03 | 1.20 | 0.17 |  |
| 39 | Udyr | +1.03 | 1.18 | 0.15 |  |
| 40 | Aurelion Sol | +1.02 | 1.27 | 0.25 |  |
| 41 | Nami | +1.02 | 1.27 | 0.25 |  |
| 42 | Lissandra | +1.01 | 1.30 | 0.29 |  |
| 43 | Camille | +1.01 | 1.14 | 0.13 |  |
| 44 | Ashe | +1.01 | 1.10 | 0.09 | range (attacks) |
| 45 | Draven | +1.00 | 1.21 | 0.21 | range (attacks) |
| 46 | Zilean | +1.00 | 1.14 | 0.14 | range (attacks) |
| 47 | Kalista | +0.99 | 1.12 | 0.13 | range (attacks) |
| 48 | Riven | +0.98 | 0.98 | 0.00 |  |
| 49 | Master Yi | +0.97 | 1.16 | 0.19 |  |
| 50 | Veigar | +0.97 | 0.97 | 0.00 |  |
| 51 | Quinn | +0.96 | 1.26 | 0.30 | range (attacks) |
| 52 | Aurora | +0.94 | 1.19 | 0.25 | range (attacks) |
| 53 | Jayce | +0.94 | 1.10 | 0.16 | range (attacks) |
| 54 | Zoe | +0.93 | 1.14 | 0.21 | range (attacks) |
| 55 | Annie | +0.93 | 0.93 | 0.00 |  |
| 56 | Yone | +0.93 | 0.93 | 0.00 |  |
| 57 | Twisted Fate | +0.91 | 1.35 | 0.44 | range (attacks) |
| 58 | Evelynn | +0.91 | 1.11 | 0.20 |  |
| 59 | Mel | +0.90 | 1.10 | 0.20 | range (attacks), projectile block (Rebuttal) |
| 60 | Corki | +0.89 | 1.09 | 0.20 | range (attacks) |
| 61 | Tristana | +0.89 | 1.07 | 0.18 | range (attacks) |
| 62 | Fiddlesticks | +0.88 | 1.37 | 0.49 |  |
| 63 | Urgot | +0.88 | 1.16 | 0.28 |  |
| 64 | Ziggs | +0.88 | 1.02 | 0.14 | range (attacks) |
| 65 | Rammus | +0.86 | 1.25 | 0.39 |  |
| 66 | Rakan | +0.86 | 1.11 | 0.25 |  |
| 67 | Shaco | +0.86 | 1.10 | 0.24 |  |
| 68 | Vex | +0.86 | 1.06 | 0.20 | range (attacks) |
| 69 | Teemo | +0.86 | 1.03 | 0.17 | range (attacks) |
| 70 | Soraka | +0.85 | 0.99 | 0.14 | range (attacks) |
| 71 | Zyra | +0.85 | 0.85 | 0.00 |  |
| 72 | Sion | +0.84 | 1.15 | 0.31 |  |
| 73 | Amumu | +0.84 | 0.84 | 0.00 |  |
| 74 | Gwen | +0.82 | 0.99 | 0.17 |  |
| 75 | Garen | +0.82 | 0.82 | 0.00 |  |
| 76 | Zac | +0.81 | 1.35 | 0.54 |  |
| 77 | Kindred | +0.81 | 0.94 | 0.13 | range (attacks) |
| 78 | Neeko | +0.81 | 0.81 | 0.00 |  |
| 79 | Azir | +0.78 | 0.90 | 0.12 | range (attacks) |
| 80 | Orianna | +0.78 | 0.90 | 0.12 | range (attacks) |
| 81 | Kai'Sa | +0.77 | 0.77 | 0.00 | range (attacks) |
| 82 | Tahm Kench | +0.76 | 1.35 | 0.59 |  |
| 83 | Brand | +0.76 | 0.93 | 0.17 |  |
| 84 | Cho'Gath | +0.75 | 0.98 | 0.23 |  |
| 85 | Pyke | +0.75 | 0.98 | 0.23 |  |
| 86 | Zeri | +0.75 | 0.88 | 0.13 | range (attacks) |
| 87 | Twitch | +0.73 | 0.86 | 0.13 | range (attacks) |
| 88 | Ahri | +0.72 | 0.93 | 0.21 |  |
| 89 | Swain | +0.72 | 0.91 | 0.19 |  |
| 90 | Viego | +0.71 | 1.07 | 0.36 |  |
| 91 | Xin Zhao | +0.70 | 0.97 | 0.27 |  |
| 92 | Hwei | +0.70 | 0.95 | 0.25 |  |
| 93 | Syndra | +0.68 | 0.92 | 0.24 |  |
| 94 | Xerath | +0.67 | 1.02 | 0.35 | range (attacks) |
| 95 | Rengar | +0.67 | 0.87 | 0.20 |  |
| 96 | Singed | +0.67 | 0.76 | 0.09 |  |
| 97 | Gragas | +0.66 | 0.86 | 0.20 |  |
| 98 | Ezreal | +0.65 | 0.65 | 0.00 | range (attacks) |
| 99 | Galio | +0.64 | 1.28 | 0.64 |  |
| 100 | Vel'Koz | +0.64 | 1.02 | 0.38 | range (attacks) |
| 101 | Leona | +0.62 | 0.87 | 0.25 |  |
| 102 | Nilah | +0.62 | 0.87 | 0.25 |  |
| 103 | Gangplank | +0.62 | 0.82 | 0.20 |  |
| 104 | Nidalee | +0.60 | 0.60 | 0.00 | range (attacks) |
| 105 | Kayn | +0.56 | 1.11 | 0.55 |  |
| 106 | Aphelios | +0.56 | 0.87 | 0.31 | range (attacks) |
| 107 | Yunara | +0.56 | 0.72 | 0.16 | range (attacks) |
| 108 | Jax | +0.56 | 0.56 | 0.00 |  |
| 109 | Ornn | +0.55 | 0.91 | 0.36 |  |
| 110 | Varus | +0.55 | 0.71 | 0.16 | range (attacks) |
| 111 | Vi | +0.54 | 0.87 | 0.33 |  |
| 112 | Cassiopeia | +0.54 | 0.81 | 0.27 |  |
| 113 | Sett | +0.52 | 0.88 | 0.36 |  |
| 114 | Warwick | +0.51 | 1.19 | 0.68 |  |
| 115 | Senna | +0.51 | 0.65 | 0.14 | range (attacks) |
| 116 | Renekton | +0.49 | 0.49 | 0.00 |  |
| 117 | Taric | +0.49 | 0.49 | 0.00 |  |
| 118 | Zed | +0.46 | 0.60 | 0.14 |  |
| 119 | Smolder | +0.45 | 0.65 | 0.20 | range (attacks) |
| 120 | Lux | +0.45 | 0.58 | 0.13 | range (attacks) |
| 121 | Lucian | +0.44 | 0.72 | 0.28 | range (attacks) |
| 122 | Jinx | +0.44 | 0.58 | 0.14 | range (attacks) |
| 123 | LeBlanc | +0.44 | 0.44 | 0.00 |  |
| 124 | Irelia | +0.42 | 0.59 | 0.17 |  |
| 125 | Olaf | +0.42 | 0.55 | 0.13 |  |
| 126 | Kog'Maw | +0.41 | 0.54 | 0.13 | range (attacks) |
| 127 | Malphite | +0.41 | 0.54 | 0.13 |  |
| 128 | Akshan | +0.40 | 0.68 | 0.28 | range (attacks) |
| 129 | Mordekaiser | +0.38 | 0.55 | 0.17 |  |
| 130 | Sylas | +0.37 | 0.49 | 0.12 |  |
| 131 | Wukong | +0.37 | 0.37 | 0.00 |  |
| 132 | Caitlyn | +0.36 | 0.72 | 0.36 | range (attacks) |
| 133 | Aatrox | +0.36 | 0.49 | 0.13 |  |
| 134 | Yorick | +0.36 | 0.49 | 0.13 |  |
| 135 | Graves | +0.35 | 0.49 | 0.14 |  |
| 136 | Kassadin | +0.35 | 0.49 | 0.14 |  |
| 137 | Miss Fortune | +0.30 | 0.65 | 0.35 | range (attacks) |
| 138 | Skarner | +0.30 | 0.49 | 0.19 |  |
| 139 | Lillia | +0.28 | 0.56 | 0.28 |  |
| 140 | Karma | +0.28 | 0.44 | 0.16 |  |
| 141 | Shen | +0.25 | 0.76 | 0.51 |  |
| 142 | Volibear | +0.25 | 0.56 | 0.31 |  |
| 143 | Jarvan IV | +0.25 | 0.38 | 0.13 |  |
| 144 | Lee Sin | +0.25 | 0.38 | 0.13 |  |
| 145 | Nautilus | +0.25 | 0.37 | 0.12 |  |
| 146 | Trundle | +0.23 | 0.48 | 0.25 |  |
| 147 | Darius | +0.22 | 0.46 | 0.24 |  |
| 148 | Ambessa | +0.22 | 0.35 | 0.13 |  |
| 149 | Ivern | +0.20 | 0.38 | 0.18 |  |
| 150 | Shyvana | +0.18 | 0.51 | 0.33 |  |
| 151 | Bel'Veth | +0.17 | 0.49 | 0.32 |  |
| 152 | Jhin | +0.15 | 0.53 | 0.38 | range (attacks) |
| 153 | Nasus | +0.14 | 0.27 | 0.13 |  |
| 154 | Diana | +0.12 | 0.37 | 0.25 |  |
| 155 | Qiyana | +0.11 | 0.31 | 0.20 |  |
| 156 | Poppy | +0.08 | 0.35 | 0.27 |  |
| 157 | Hecarim | +0.05 | 0.36 | 0.31 |  |
| 158 | Karthus | +0.04 | 0.39 | 0.35 |  |
| 159 | Ryze | +0.03 | 0.48 | 0.45 |  |
| 160 | Briar | +0.03 | 0.37 | 0.34 |  |
| 161 | Pantheon | -0.03 | 0.57 | 0.60 |  |
| 162 | Illaoi | -0.06 | 0.07 | 0.13 |  |
| 163 | Katarina | -0.10 | 0.18 | 0.28 |  |
| 164 | Talon | -0.12 | 0.00 | 0.12 |  |
| 165 | Akali | -0.14 | 0.00 | 0.14 |  |
| 166 | Dr. Mundo | -0.14 | 0.00 | 0.14 |  |
| 167 | Tryndamere | -0.14 | 0.00 | 0.14 |  |
| 168 | Kha'Zix | -0.15 | 0.00 | 0.15 |  |
| 169 | Ekko | -0.17 | 0.00 | 0.17 |  |
| 170 | Locke | -0.20 | 0.00 | 0.20 |  |
| 171 | Rumble | -0.20 | 0.00 | 0.20 |  |
| 172 | Naafiri | -0.59 | 0.00 | 0.59 |  |
