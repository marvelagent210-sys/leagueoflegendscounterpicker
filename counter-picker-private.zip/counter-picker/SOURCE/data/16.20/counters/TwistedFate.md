# Counters to Twisted Fate (patch 26.20)

Every champion ranked by what its kit does against Twisted Fate's, from the interaction ledger: projectile blocks, spell shields,
parries, dash stops, crowd control and its defenses, range and more (PLAN.md §5). This ranking is **partial**: it weighs the
interactions but doesn't play the fight out. The duel simulator replaces it as each champion's behavior is verified.

"For" sums the interactions in the champion's favor, "against" those in Twisted Fate's; net = for − against.
A hard counter shuts down part of a kit every time it is used (projectile block, attack dodge, attack block, blind, disarm, attack speed slow, attack reflect, dash stop, grounding, range) with an impact of 0.4 or more (0.5 for range).
Run `npm run matchup -- <champion> TwistedFate` for the full ledger of a matchup, with sources.

## Top 10

### 1. Rell (net +1.50)

- **0.35** interrupt: Ferromancy: Crash Down's airborne interrupts Twisted Fate's Destiny (movement channel). Ferromancy: Crash Down must land during the channel. (Rell W Ferromancy: Crash Down → Twisted Fate R Destiny)
- **0.35** interrupt: Ferromancy: Mount Up's airborne interrupts Twisted Fate's Destiny (movement channel). Ferromancy: Mount Up must land during the channel. (Rell W Ferromancy: Mount Up → Twisted Fate R Destiny)
- **0.35** interrupt: Full Tilt's stun interrupts Twisted Fate's Destiny (movement channel). Full Tilt must land during the channel. (Rell E Full Tilt → Twisted Fate R Destiny)
- Watch out: Twisted Fate's basic attacks reach 350 units farther than Rell's (525 vs 175 attack range).

### 2. Braum (net +1.26)

- **0.60** projectile block: Unbreakable blocks Twisted Fate's basic attacks, which are projectiles. Unbreakable lasts 4 s on a 8 s cooldown. (Braum E Unbreakable → Twisted Fate basic attacks)
- **0.60** projectile block: Unbreakable blocks Twisted Fate's Pick a Card, a projectile. Unbreakable for 4 s, long enough to use ahead of Pick a Card. (Braum E Unbreakable → Twisted Fate W Pick a Card)
- **0.35** interrupt: Concussive Blows's stun interrupts Twisted Fate's Destiny (movement channel). Concussive Blows must land during the channel. (Braum I Concussive Blows → Twisted Fate R Destiny)
- Watch out: Twisted Fate's basic attacks reach 400 units farther than Braum's (525 vs 125 attack range).

### 3. Yasuo (net +1.20)

- **0.47** projectile block: Wind Wall blocks Twisted Fate's basic attacks, which are projectiles. Wind Wall lasts 4 s on a 17 s cooldown. (Yasuo W Wind Wall → Twisted Fate basic attacks)
- **0.43** projectile block: Wind Wall blocks Twisted Fate's Pick a Card, a projectile. Wind Wall for 4 s, long enough to use ahead of Pick a Card. (Yasuo W Wind Wall → Twisted Fate W Pick a Card)
- **0.35** interrupt: Last Breath's airborne interrupts Twisted Fate's Destiny (movement channel). Last Breath must land during the channel. (Yasuo R Last Breath → Twisted Fate R Destiny)
- Watch out: Twisted Fate's basic attacks reach 350 units farther than Yasuo's (525 vs 175 attack range).

### 4. Lulu (net +0.93)

- **0.40** disarm: Whimsy disarms Twisted Fate for 2 s: no basic attacks. Disarm for 2 s on a 18 s cooldown. (Lulu W Whimsy → Twisted Fate basic attacks)
- **0.35** interrupt: Whimsy's polymorph interrupts Twisted Fate's Destiny (movement channel). Whimsy must land during the channel. (Lulu W Whimsy → Twisted Fate R Destiny)
- **0.35** interrupt: Wild Growth's airborne interrupts Twisted Fate's Destiny (movement channel). Wild Growth must land during the channel. (Lulu R Wild Growth → Twisted Fate R Destiny)

### 5. K'Sante (net +0.85)

- **0.35** interrupt: All Out's airborne interrupts Twisted Fate's Destiny (movement channel). All Out must land during the channel. (K'Sante R All Out → Twisted Fate R Destiny)
- **0.35** interrupt: Ntofo Strikes's airborne interrupts Twisted Fate's Destiny (movement channel). Ntofo Strikes must land during the channel. (K'Sante Q Ntofo Strikes → Twisted Fate R Destiny)
- **0.35** interrupt: Path Maker's airborne interrupts Twisted Fate's Destiny (movement channel). Path Maker must land during the channel. (K'Sante W Path Maker → Twisted Fate R Destiny)
- Watch out: Twisted Fate's basic attacks reach 375 units farther than K'Sante's (525 vs 150 attack range).

### 6. Heimerdinger (net +0.77)

- **0.35** interrupt: CH-2 Electron Storm Grenade's stun interrupts Twisted Fate's Destiny (movement channel). CH-2 Electron Storm Grenade must land during the channel. (Heimerdinger E CH-2 Electron Storm Grenade → Twisted Fate R Destiny)
- **0.35** interrupt: CH-3X Lightning Grenade's stun interrupts Twisted Fate's Destiny (movement channel). CH-3X Lightning Grenade must land during the channel. (Heimerdinger E CH-3X Lightning Grenade → Twisted Fate R Destiny)
- **0.07** cc immunity: H-28G Evolution Turret makes Heimerdinger immune to Twisted Fate's Pick a Card (slow). H-28G Evolution Turret lasts ? on a 20 s cooldown. (Heimerdinger Q H-28G Evolution Turret → Twisted Fate W Pick a Card)

### 7. Anivia (net +0.74)

- **0.35** interrupt: Crystallize's airborne interrupts Twisted Fate's Destiny (movement channel). Crystallize must land during the channel. (Anivia W Crystallize → Twisted Fate R Destiny)
- **0.35** interrupt: Flash Frost's stun interrupts Twisted Fate's Destiny (movement channel). Flash Frost must land during the channel. (Anivia Q Flash Frost → Twisted Fate R Destiny)
- **0.04** range: Anivia's basic attacks reach 75 units farther than Twisted Fate's (600 vs 525 attack range). Twisted Fate closes the gap with Destiny. (Anivia basic attacks → Twisted Fate basic attacks)

### 8. Teemo (net +0.72)

- **0.57** blind: Blinding Dart's blind makes Twisted Fate's basic attacks miss for 3 s. Blind for 3 s on a 7 s cooldown. (Teemo Q Blinding Dart → Twisted Fate basic attacks)
- **0.46** blind: Blinding Dart's blind makes Twisted Fate's Pick a Card, an empowered attack, miss. Blind for 3 s. (Teemo Q Blinding Dart → Twisted Fate W Pick a Card)
- Watch out: Destiny reveals Teemo through Guerrilla Warfare's stealth.

### 9. Gnar (net +0.70)

- **0.35** interrupt: GNAR!'s airborne interrupts Twisted Fate's Destiny (movement channel). GNAR! must land during the channel. (Gnar R GNAR! → Twisted Fate R Destiny)
- **0.35** interrupt: Wallop's stun interrupts Twisted Fate's Destiny (movement channel). Wallop must land during the channel. (Gnar W Wallop → Twisted Fate R Destiny)

### 10. Nami (net +0.70)

- **0.35** interrupt: Aqua Prison's suspension interrupts Twisted Fate's Destiny (movement channel). Aqua Prison must land during the channel. (Nami Q Aqua Prison → Twisted Fate R Destiny)
- **0.35** interrupt: Tidal Wave's airborne interrupts Twisted Fate's Destiny (movement channel). Tidal Wave must land during the channel. (Nami R Tidal Wave → Twisted Fate R Destiny)

## Full ranking

| # | Champion | Net | For | Against | Hard counters |
|--:|---|--:|--:|--:|---|
| 1 | Rell | +1.50 | 1.75 | 0.25 |  |
| 2 | Braum | +1.26 | 1.69 | 0.43 | projectile block (Unbreakable), projectile block (Unbreakable) |
| 3 | Yasuo | +1.20 | 1.45 | 0.25 | projectile block (Wind Wall), projectile block (Wind Wall) |
| 4 | Lulu | +0.93 | 0.93 | 0.00 | disarm (Whimsy) |
| 5 | K'Sante | +0.85 | 1.05 | 0.20 |  |
| 6 | Heimerdinger | +0.77 | 0.77 | 0.00 |  |
| 7 | Anivia | +0.74 | 0.74 | 0.00 |  |
| 8 | Teemo | +0.72 | 0.80 | 0.08 | blind (Blinding Dart), blind (Blinding Dart) |
| 9 | Gnar | +0.70 | 0.70 | 0.00 |  |
| 10 | Nami | +0.70 | 0.70 | 0.00 |  |
| 11 | Renata Glasc | +0.70 | 0.70 | 0.00 |  |
| 12 | Viktor | +0.70 | 0.70 | 0.00 |  |
| 13 | Milio | +0.69 | 0.69 | 0.00 |  |
| 14 | Seraphine | +0.68 | 0.68 | 0.00 |  |
| 15 | Malzahar | +0.65 | 1.05 | 0.40 |  |
| 16 | Sejuani | +0.65 | 1.05 | 0.40 |  |
| 17 | Thresh | +0.65 | 0.70 | 0.05 |  |
| 18 | Zaahen | +0.64 | 0.89 | 0.25 |  |
| 19 | Kled | +0.64 | 0.79 | 0.15 |  |
| 20 | Nilah | +0.63 | 0.95 | 0.32 | attack dodge (Jubilant Veil) |
| 21 | Aurelion Sol | +0.60 | 0.70 | 0.10 |  |
| 22 | Camille | +0.58 | 0.79 | 0.21 |  |
| 23 | Taliyah | +0.55 | 1.03 | 0.48 |  |
| 24 | Rakan | +0.54 | 0.70 | 0.16 |  |
| 25 | Samira | +0.54 | 0.54 | 0.00 |  |
| 26 | Mel | +0.53 | 0.53 | 0.00 |  |
| 27 | Alistar | +0.52 | 0.95 | 0.43 |  |
| 28 | Fizz | +0.52 | 0.71 | 0.19 |  |
| 29 | Cassiopeia | +0.52 | 0.52 | 0.00 |  |
| 30 | Urgot | +0.51 | 0.70 | 0.19 |  |
| 31 | Yone | +0.51 | 0.70 | 0.19 |  |
| 32 | Bard | +0.51 | 0.51 | 0.00 |  |
| 33 | Lissandra | +0.51 | 0.51 | 0.00 |  |
| 34 | Tristana | +0.51 | 0.51 | 0.00 |  |
| 35 | Jax | +0.45 | 0.88 | 0.43 | attack dodge (Counter Strike), attack dodge (Counter Strike) |
| 36 | Udyr | +0.45 | 0.88 | 0.43 |  |
| 37 | Ornn | +0.45 | 0.70 | 0.25 |  |
| 38 | Kalista | +0.45 | 0.45 | 0.00 |  |
| 39 | Ashe | +0.42 | 0.42 | 0.00 |  |
| 40 | Sivir | +0.42 | 0.42 | 0.00 |  |
| 41 | Nocturne | +0.41 | 0.84 | 0.43 |  |
| 42 | Riven | +0.41 | 0.70 | 0.29 |  |
| 43 | Rek'Sai | +0.41 | 0.66 | 0.25 |  |
| 44 | Annie | +0.40 | 0.40 | 0.00 |  |
| 45 | Xin Zhao | +0.39 | 0.77 | 0.38 |  |
| 46 | Shen | +0.36 | 1.10 | 0.74 | attack block (Spirit's Refuge), attack block (Spirit's Refuge) |
| 47 | Rammus | +0.35 | 1.13 | 0.78 | attack reflect (Defensive Ball Curl) |
| 48 | Ahri | +0.35 | 0.35 | 0.00 |  |
| 49 | Azir | +0.35 | 0.35 | 0.00 |  |
| 50 | Brand | +0.35 | 0.35 | 0.00 |  |
| 51 | Corki | +0.35 | 0.35 | 0.00 |  |
| 52 | Draven | +0.35 | 0.35 | 0.00 |  |
| 53 | Elise | +0.35 | 0.35 | 0.00 |  |
| 54 | Hwei | +0.35 | 0.35 | 0.00 |  |
| 55 | Jayce | +0.35 | 0.35 | 0.00 |  |
| 56 | Kennen | +0.35 | 0.35 | 0.00 |  |
| 57 | Orianna | +0.35 | 0.35 | 0.00 |  |
| 58 | Sona | +0.35 | 0.35 | 0.00 |  |
| 59 | Soraka | +0.35 | 0.35 | 0.00 |  |
| 60 | Swain | +0.35 | 0.35 | 0.00 |  |
| 61 | Syndra | +0.35 | 0.35 | 0.00 |  |
| 62 | Veigar | +0.35 | 0.35 | 0.00 |  |
| 63 | Vex | +0.35 | 0.35 | 0.00 |  |
| 64 | Ziggs | +0.35 | 0.35 | 0.00 |  |
| 65 | Zilean | +0.35 | 0.35 | 0.00 |  |
| 66 | Zoe | +0.35 | 0.35 | 0.00 |  |
| 67 | Zyra | +0.35 | 0.35 | 0.00 |  |
| 68 | Xayah | +0.31 | 0.31 | 0.00 |  |
| 69 | Janna | +0.30 | 0.70 | 0.40 |  |
| 70 | Morgana | +0.28 | 0.44 | 0.16 |  |
| 71 | Amumu | +0.27 | 0.70 | 0.43 |  |
| 72 | Leona | +0.27 | 0.70 | 0.43 |  |
| 73 | Sett | +0.27 | 0.70 | 0.43 |  |
| 74 | Kayle | +0.25 | 0.25 | 0.00 |  |
| 75 | Maokai | +0.24 | 0.67 | 0.43 |  |
| 76 | Neeko | +0.24 | 0.35 | 0.11 |  |
| 77 | Fiddlesticks | +0.23 | 0.70 | 0.47 |  |
| 78 | Vayne | +0.21 | 0.35 | 0.14 |  |
| 79 | Malphite | +0.20 | 0.63 | 0.43 |  |
| 80 | Blitzcrank | +0.19 | 1.05 | 0.86 |  |
| 81 | Vladimir | +0.18 | 0.44 | 0.26 |  |
| 82 | Tahm Kench | +0.17 | 1.05 | 0.88 |  |
| 83 | Zac | +0.17 | 1.05 | 0.88 |  |
| 84 | Viego | +0.17 | 0.70 | 0.53 |  |
| 85 | Evelynn | +0.17 | 0.54 | 0.37 |  |
| 86 | Jarvan IV | +0.16 | 0.35 | 0.19 |  |
| 87 | Sylas | +0.16 | 0.35 | 0.19 |  |
| 88 | Galio | +0.15 | 1.01 | 0.86 |  |
| 89 | Pyke | +0.14 | 0.70 | 0.56 |  |
| 90 | Briar | +0.14 | 0.35 | 0.21 |  |
| 91 | Lillia | +0.14 | 0.35 | 0.21 |  |
| 92 | Quinn | +0.12 | 0.35 | 0.23 |  |
| 93 | Hecarim | +0.10 | 0.35 | 0.25 |  |
| 94 | Bel'Veth | +0.08 | 0.35 | 0.27 |  |
| 95 | Volibear | +0.08 | 0.35 | 0.27 |  |
| 96 | Gragas | +0.07 | 0.70 | 0.63 |  |
| 97 | Vel'Koz | +0.07 | 0.35 | 0.28 |  |
| 98 | Aphelios | +0.07 | 0.07 | 0.00 |  |
| 99 | Ambessa | +0.06 | 0.35 | 0.29 |  |
| 100 | Lee Sin | +0.06 | 0.35 | 0.29 |  |
| 101 | Shaco | +0.05 | 0.54 | 0.49 |  |
| 102 | Aurora | +0.03 | 0.18 | 0.15 |  |
| 103 | Xerath | +0.02 | 0.35 | 0.33 |  |
| 104 | Fiora | +0.01 | 0.41 | 0.40 |  |
| 105 | Irelia | 0.00 | 0.35 | 0.35 |  |
| 106 | Ezreal | 0.00 | 0.00 | 0.00 |  |
| 107 | Jinx | 0.00 | 0.00 | 0.00 |  |
| 108 | Karma | 0.00 | 0.00 | 0.00 |  |
| 109 | Kindred | 0.00 | 0.00 | 0.00 |  |
| 110 | Kog'Maw | 0.00 | 0.00 | 0.00 |  |
| 111 | Lux | 0.00 | 0.00 | 0.00 |  |
| 112 | Nidalee | 0.00 | 0.00 | 0.00 |  |
| 113 | Smolder | 0.00 | 0.00 | 0.00 |  |
| 114 | Yunara | 0.00 | 0.00 | 0.00 |  |
| 115 | Zeri | 0.00 | 0.00 | 0.00 |  |
| 116 | Aatrox | -0.03 | 0.35 | 0.38 |  |
| 117 | Nautilus | -0.03 | 0.35 | 0.38 |  |
| 118 | Diana | -0.05 | 0.35 | 0.40 |  |
| 119 | Kassadin | -0.05 | 0.35 | 0.40 |  |
| 120 | Shyvana | -0.05 | 0.35 | 0.40 |  |
| 121 | Senna | -0.05 | 0.06 | 0.11 |  |
| 122 | Sion | -0.07 | 0.86 | 0.93 |  |
| 123 | Graves | -0.07 | 0.00 | 0.07 |  |
| 124 | Renekton | -0.08 | 0.35 | 0.43 |  |
| 125 | LeBlanc | -0.08 | 0.00 | 0.08 |  |
| 126 | Vi | -0.09 | 0.70 | 0.79 |  |
| 127 | Wukong | -0.10 | 0.35 | 0.45 |  |
| 128 | Zed | -0.11 | 0.18 | 0.29 |  |
| 129 | Kai'Sa | -0.11 | 0.00 | 0.11 |  |
| 130 | Twitch | -0.11 | 0.00 | 0.11 |  |
| 131 | Varus | -0.11 | 0.00 | 0.11 |  |
| 132 | Yuumi | -0.12 | 0.42 | 0.54 |  |
| 133 | Qiyana | -0.12 | 0.33 | 0.45 |  |
| 134 | Gwen | -0.15 | 0.25 | 0.40 |  |
| 135 | Ivern | -0.15 | 0.00 | 0.15 |  |
| 136 | Cho'Gath | -0.16 | 0.70 | 0.86 |  |
| 137 | Garen | -0.16 | 0.59 | 0.75 |  |
| 138 | Kayn | -0.16 | 0.54 | 0.70 |  |
| 139 | Caitlyn | -0.17 | 0.11 | 0.28 |  |
| 140 | Warwick | -0.19 | 0.80 | 0.99 |  |
| 141 | Master Yi | -0.25 | 0.36 | 0.61 |  |
| 142 | Poppy | -0.28 | 0.35 | 0.63 |  |
| 143 | Jhin | -0.28 | 0.00 | 0.28 |  |
| 144 | Lucian | -0.28 | 0.00 | 0.28 |  |
| 145 | Miss Fortune | -0.28 | 0.00 | 0.28 |  |
| 146 | Ekko | -0.29 | 0.00 | 0.29 |  |
| 147 | Mordekaiser | -0.30 | 0.45 | 0.75 |  |
| 148 | Singed | -0.34 | 0.52 | 0.86 |  |
| 149 | Ryze | -0.35 | 0.00 | 0.35 |  |
| 150 | Skarner | -0.37 | 0.44 | 0.81 |  |
| 151 | Tryndamere | -0.38 | 0.00 | 0.38 |  |
| 152 | Darius | -0.40 | 0.35 | 0.75 |  |
| 153 | Trundle | -0.40 | 0.35 | 0.75 |  |
| 154 | Yorick | -0.40 | 0.35 | 0.75 |  |
| 155 | Akali | -0.40 | 0.00 | 0.40 |  |
| 156 | Akshan | -0.42 | 0.00 | 0.42 |  |
| 157 | Nasus | -0.43 | 0.43 | 0.86 | attack speed slow (Wither) |
| 158 | Illaoi | -0.43 | 0.00 | 0.43 |  |
| 159 | Locke | -0.43 | 0.00 | 0.43 |  |
| 160 | Talon | -0.43 | 0.00 | 0.43 |  |
| 161 | Karthus | -0.44 | 0.00 | 0.44 |  |
| 162 | Taric | -0.46 | 0.35 | 0.81 |  |
| 163 | Gangplank | -0.49 | 0.37 | 0.86 |  |
| 164 | Olaf | -0.55 | 0.31 | 0.86 |  |
| 165 | Pantheon | -0.55 | 0.21 | 0.76 |  |
| 166 | Rengar | -0.57 | 0.43 | 1.00 |  |
| 167 | Kha'Zix | -0.64 | 0.00 | 0.64 |  |
| 168 | Naafiri | -0.66 | 0.00 | 0.66 |  |
| 169 | Katarina | -0.71 | 0.00 | 0.71 |  |
| 170 | Dr. Mundo | -0.86 | 0.00 | 0.86 |  |
| 171 | Rumble | -0.86 | 0.00 | 0.86 |  |
| 172 | Nunu & Willump | -0.91 | 0.44 | 1.35 |  |
