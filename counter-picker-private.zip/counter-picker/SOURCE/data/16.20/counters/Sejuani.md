# Counters to Sejuani (patch 26.20)

Every champion ranked by what its kit does against Sejuani's, from the interaction ledger: projectile blocks, spell shields,
parries, dash stops, crowd control and its defenses, range and more (PLAN.md §5). This ranking is **partial**: it weighs the
interactions but doesn't play the fight out. The duel simulator replaces it as each champion's behavior is verified.

"For" sums the interactions in the champion's favor, "against" those in Sejuani's; net = for − against.
A hard counter shuts down part of a kit every time it is used (projectile block, attack dodge, attack block, blind, disarm, attack speed slow, attack reflect, dash stop, grounding, range) with an impact of 0.4 or more (0.5 for range).
Run `npm run matchup -- <champion> Sejuani` for the full ledger of a matchup, with sources.

## Top 10

### 1. Nocturne (net +1.54)

- **1.00** spell shield: Shroud of Darkness's spell shield blocks Sejuani's Arctic Assault. Spell shield for 1.5 s, long enough to use ahead of Arctic Assault. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Sejuani Q Arctic Assault)
- **0.40** spell shield: Shroud of Darkness's spell shield blocks part of Sejuani's Glacial Prison. Spell shield for 1.5 s, long enough to use ahead of Glacial Prison. A spell shield blocks only the first enemy ability that reaches it. Spell shields will block only a single instance of damage. (Nocturne W Shroud of Darkness → Sejuani R Glacial Prison)
- **0.38** spell shield: Shroud of Darkness's spell shield blocks Sejuani's Permafrost. Spell shield for 1.5 s, long enough to use ahead of Permafrost. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Sejuani E Permafrost)

### 2. Fiora (net +1.53)

- **0.95** parry: Riposte parries Sejuani's Arctic Assault and stuns back. Parry for 0.75 s; Arctic Assault takes 0.65 s to land, enough to react. Negating Arctic Assault's immobilizing effect turns Riposte's slow into a stun (2 s). (Fiora W Riposte → Sejuani Q Arctic Assault)
- **0.90** parry: Riposte parries Sejuani's Glacial Prison and stuns back. Parry for 0.75 s; Glacial Prison takes 1.06 s to land, enough to react. Negating Glacial Prison's immobilizing effect turns Riposte's slow into a stun (2 s). (Fiora W Riposte → Sejuani R Glacial Prison)
- **0.47** parry: Riposte parries Sejuani's Permafrost and stuns back. Parry for 0.75 s; Permafrost takes 0.25 s to land, enough to react. Negating Permafrost's immobilizing effect turns Riposte's slow into a stun (2 s). (Fiora W Riposte → Sejuani E Permafrost)

### 3. Morgana (net +1.53)

- **0.85** cc immunity: Black Shield makes Morgana immune to Sejuani's Arctic Assault (airborne). Immune for 5 s, long enough to use ahead of Arctic Assault. (Morgana E Black Shield → Sejuani Q Arctic Assault)
- **0.80** cc immunity: Black Shield makes Morgana immune to Sejuani's Glacial Prison (slow, stun). Immune for 5 s, long enough to use ahead of Glacial Prison. (Morgana E Black Shield → Sejuani R Glacial Prison)
- **0.37** cc immunity: Black Shield makes Morgana immune to Sejuani's Permafrost (airborne, stun). Immune for 5 s, long enough to use ahead of Permafrost. (Morgana E Black Shield → Sejuani E Permafrost)

### 4. Sivir (net +1.53)

- **0.80** spell shield: Spell Shield's spell shield blocks Sejuani's Arctic Assault. Spell shield for 1.5 s, long enough to use ahead of Arctic Assault. A spell shield blocks only the first enemy ability that reaches it. (Sivir E Spell Shield → Sejuani Q Arctic Assault)
- **0.44** range: Sivir's basic attacks reach 350 units farther than Sejuani's (500 vs 150 attack range). Sejuani closes the gap with Arctic Assault. (Sivir basic attacks → Sejuani basic attacks)
- **0.40** spell shield: Spell Shield's spell shield blocks part of Sejuani's Glacial Prison. Spell shield for 1.5 s, long enough to use ahead of Glacial Prison. A spell shield blocks only the first enemy ability that reaches it. Spell shields will block only a single instance of damage. (Sivir E Spell Shield → Sejuani R Glacial Prison)

### 5. Udyr (net +1.52)

- **1.00** cc immunity: Blazing Stampede makes Udyr immune to Sejuani's Arctic Assault (airborne). Immune for 1.5 s, long enough to use ahead of Arctic Assault. (Udyr E Blazing Stampede → Sejuani Q Arctic Assault)
- **0.80** cc immunity: Blazing Stampede makes Udyr immune to Sejuani's Glacial Prison (slow, stun). Immune for 1.5 s, long enough to use ahead of Glacial Prison. (Udyr E Blazing Stampede → Sejuani R Glacial Prison)
- **0.44** cc immunity: Blazing Stampede makes Udyr immune to Sejuani's Permafrost (airborne, stun). Immune for 1.5 s, long enough to use ahead of Permafrost. (Udyr E Blazing Stampede → Sejuani E Permafrost)

### 6. Fizz (net +1.50)

- **1.00** untargetable: Playful makes Fizz untargetable, dodging Sejuani's Arctic Assault. Untargetable for 0.75 s; Arctic Assault takes 0.65 s to land, enough to react. (Fizz E Playful → Sejuani Q Arctic Assault)
- **0.80** untargetable: Playful makes Fizz untargetable, dodging Sejuani's Glacial Prison. Untargetable for 0.75 s; Glacial Prison takes 1.06 s to land, enough to react. (Fizz E Playful → Sejuani R Glacial Prison)
- **0.41** untargetable: Playful makes Fizz untargetable, dodging Sejuani's Permafrost. Untargetable for 0.75 s; Permafrost takes 0.25 s to land, enough to react. (Fizz E Playful → Sejuani E Permafrost)

### 7. Maokai (net +1.50)

- **1.00** untargetable: Twisted Advance makes Maokai untargetable, dodging Sejuani's Arctic Assault. Untargetable for 1.4 s; Arctic Assault takes 0.65 s to land, enough to react. (Maokai W Twisted Advance → Sejuani Q Arctic Assault)
- **0.80** untargetable: Twisted Advance makes Maokai untargetable, dodging Sejuani's Glacial Prison. Untargetable for 1.4 s; Glacial Prison takes 1.06 s to land, enough to react. (Maokai W Twisted Advance → Sejuani R Glacial Prison)
- **0.39** untargetable: Twisted Advance makes Maokai untargetable, dodging Sejuani's Permafrost. Untargetable for 1.4 s; Permafrost takes 0.25 s to land, enough to react. (Maokai W Twisted Advance → Sejuani E Permafrost)

### 8. Bard (net +1.47)

- **0.80** untargetable: Tempered Fate makes Bard untargetable, dodging Sejuani's Glacial Prison. Untargetable for 2.5 s, long enough to use ahead of Glacial Prison. (Bard R Tempered Fate → Sejuani R Glacial Prison)
- **0.49** untargetable: Tempered Fate makes Bard untargetable, dodging Sejuani's Arctic Assault. Untargetable for 2.5 s, long enough to use ahead of Arctic Assault. (Bard R Tempered Fate → Sejuani Q Arctic Assault)
- **0.34** range: Bard's basic attacks reach 350 units farther than Sejuani's (500 vs 150 attack range). Sejuani closes the gap with Arctic Assault. (Bard basic attacks → Sejuani basic attacks)

### 9. Xayah (net +1.43)

- **0.75** untargetable: Featherstorm makes Xayah untargetable, dodging Sejuani's Glacial Prison. Untargetable for 1.5 s, long enough to use ahead of Glacial Prison. (Xayah R Featherstorm → Sejuani R Glacial Prison)
- **0.47** untargetable: Featherstorm makes Xayah untargetable, dodging Sejuani's Arctic Assault. Untargetable for 1.5 s, long enough to use ahead of Arctic Assault. (Xayah R Featherstorm → Sejuani Q Arctic Assault)
- **0.36** range: Xayah's basic attacks reach 375 units farther than Sejuani's (525 vs 150 attack range). Sejuani closes the gap with Arctic Assault. (Xayah basic attacks → Sejuani basic attacks)

### 10. Aurora (net +1.39)

- **0.75** untargetable: Between Worlds makes Aurora untargetable, dodging Sejuani's Glacial Prison. Untargetable for 0.4 s; Glacial Prison takes 1.06 s to land, enough to react. Does not destroy inbound projectiles. (Aurora R Between Worlds → Sejuani R Glacial Prison)
- **0.47** untargetable: Between Worlds makes Aurora untargetable, dodging Sejuani's Arctic Assault. Untargetable for 0.4 s; Arctic Assault takes 0.65 s to land, enough to react. Does not destroy inbound projectiles. (Aurora R Between Worlds → Sejuani Q Arctic Assault)
- **0.33** untargetable: Between Worlds makes Aurora untargetable, dodging Sejuani's Permafrost. Untargetable for 0.4 s; Permafrost takes 0.25 s to land, enough to react. Does not destroy inbound projectiles. (Aurora R Between Worlds → Sejuani E Permafrost)

## Full ranking

| # | Champion | Net | For | Against | Hard counters |
|--:|---|--:|--:|--:|---|
| 1 | Nocturne | +1.54 | 1.54 | 0.00 |  |
| 2 | Fiora | +1.53 | 1.53 | 0.00 |  |
| 3 | Morgana | +1.53 | 1.53 | 0.00 |  |
| 4 | Sivir | +1.53 | 1.53 | 0.00 |  |
| 5 | Udyr | +1.52 | 1.52 | 0.00 |  |
| 6 | Fizz | +1.50 | 1.50 | 0.00 |  |
| 7 | Maokai | +1.50 | 1.50 | 0.00 |  |
| 8 | Bard | +1.47 | 1.47 | 0.00 |  |
| 9 | Xayah | +1.43 | 1.43 | 0.00 |  |
| 10 | Aurora | +1.39 | 1.39 | 0.00 |  |
| 11 | Lissandra | +1.38 | 1.38 | 0.00 |  |
| 12 | Gwen | +1.29 | 1.29 | 0.00 |  |
| 13 | Vladimir | +1.27 | 1.50 | 0.23 |  |
| 14 | Samira | +1.26 | 1.26 | 0.00 | projectile block (Blade Whirl) |
| 15 | Mel | +1.25 | 1.25 | 0.00 | projectile block (Rebuttal) |
| 16 | Rengar | +1.21 | 1.21 | 0.00 |  |
| 17 | Rek'Sai | +1.16 | 1.16 | 0.00 |  |
| 18 | Camille | +1.15 | 1.15 | 0.00 |  |
| 19 | Evelynn | +1.13 | 1.13 | 0.00 |  |
| 20 | Gangplank | +1.13 | 1.13 | 0.00 |  |
| 21 | Kled | +1.13 | 1.13 | 0.00 |  |
| 22 | Olaf | +1.13 | 1.13 | 0.00 |  |
| 23 | Shaco | +1.13 | 1.13 | 0.00 |  |
| 24 | Zaahen | +1.13 | 1.13 | 0.00 |  |
| 25 | Kalista | +1.10 | 1.10 | 0.00 |  |
| 26 | Milio | +1.10 | 1.10 | 0.00 |  |
| 27 | Zed | +1.07 | 1.07 | 0.00 |  |
| 28 | Braum | +1.01 | 1.01 | 0.00 | projectile block (Unbreakable), projectile block (Unbreakable) |
| 29 | Yasuo | +0.98 | 0.98 | 0.00 | projectile block (Wind Wall) |
| 30 | Master Yi | +0.97 | 1.51 | 0.54 |  |
| 31 | Vex | +0.94 | 0.94 | 0.00 | dash stop (Doom 'n Gloom) |
| 32 | Kayle | +0.93 | 0.93 | 0.00 |  |
| 33 | Alistar | +0.90 | 0.90 | 0.00 |  |
| 34 | Viktor | +0.78 | 0.78 | 0.00 | dash stop (Gravity Field) |
| 35 | Sion | +0.77 | 1.15 | 0.38 |  |
| 36 | Jinx | +0.77 | 0.77 | 0.00 | dash stop (Flame Chompers!) |
| 37 | Teemo | +0.75 | 0.75 | 0.00 | blind (Blinding Dart) |
| 38 | Hwei | +0.73 | 0.73 | 0.00 | dash stop (Grim Visage) |
| 39 | Ahri | +0.72 | 0.72 | 0.00 | dash stop (Charm) |
| 40 | Yuumi | +0.70 | 1.90 | 1.20 |  |
| 41 | Cassiopeia | +0.70 | 0.70 | 0.00 | grounding (Miasma) |
| 42 | Veigar | +0.70 | 0.70 | 0.00 | dash stop (Event Horizon) |
| 43 | Lulu | +0.66 | 0.66 | 0.00 |  |
| 44 | Xin Zhao | +0.54 | 0.54 | 0.00 |  |
| 45 | Garen | +0.52 | 0.52 | 0.00 |  |
| 46 | Aphelios | +0.49 | 0.49 | 0.00 |  |
| 47 | Singed | +0.49 | 0.49 | 0.00 | grounding (Mega Adhesive) |
| 48 | Yone | +0.49 | 0.49 | 0.00 |  |
| 49 | K'Sante | +0.48 | 0.48 | 0.00 |  |
| 50 | Malphite | +0.45 | 0.45 | 0.00 |  |
| 51 | Kindred | +0.44 | 0.44 | 0.00 |  |
| 52 | Zeri | +0.44 | 0.44 | 0.00 |  |
| 53 | Twitch | +0.43 | 0.43 | 0.00 |  |
| 54 | Vayne | +0.43 | 0.43 | 0.00 |  |
| 55 | Sona | +0.41 | 0.41 | 0.00 |  |
| 56 | Nilah | +0.39 | 0.39 | 0.00 |  |
| 57 | Renata Glasc | +0.38 | 0.38 | 0.00 |  |
| 58 | Ashe | +0.36 | 0.36 | 0.00 |  |
| 59 | Draven | +0.36 | 0.36 | 0.00 |  |
| 60 | Kai'Sa | +0.36 | 0.36 | 0.00 |  |
| 61 | Tristana | +0.36 | 0.36 | 0.00 |  |
| 62 | Yunara | +0.36 | 0.36 | 0.00 |  |
| 63 | Jax | +0.35 | 0.35 | 0.00 |  |
| 64 | Nasus | +0.33 | 0.33 | 0.00 |  |
| 65 | Elise | +0.32 | 0.32 | 0.00 |  |
| 66 | Ezreal | +0.32 | 0.32 | 0.00 |  |
| 67 | Senna | +0.32 | 0.32 | 0.00 |  |
| 68 | Smolder | +0.32 | 0.32 | 0.00 |  |
| 69 | Zilean | +0.32 | 0.32 | 0.00 |  |
| 70 | Zoe | +0.32 | 0.32 | 0.00 |  |
| 71 | Gnar | +0.31 | 0.31 | 0.00 |  |
| 72 | Heimerdinger | +0.31 | 0.31 | 0.00 |  |
| 73 | Corki | +0.30 | 0.30 | 0.00 |  |
| 74 | Kennen | +0.29 | 0.29 | 0.00 |  |
| 75 | Lux | +0.29 | 0.29 | 0.00 |  |
| 76 | Jayce | +0.28 | 0.28 | 0.00 |  |
| 77 | Nidalee | +0.28 | 0.28 | 0.00 |  |
| 78 | Seraphine | +0.27 | 0.27 | 0.00 |  |
| 79 | Soraka | +0.27 | 0.27 | 0.00 |  |
| 80 | Ziggs | +0.27 | 0.27 | 0.00 |  |
| 81 | Azir | +0.25 | 0.25 | 0.00 |  |
| 82 | Hecarim | +0.25 | 0.25 | 0.00 |  |
| 83 | Kog'Maw | +0.25 | 0.25 | 0.00 |  |
| 84 | Orianna | +0.25 | 0.25 | 0.00 |  |
| 85 | Amumu | +0.24 | 0.24 | 0.00 |  |
| 86 | Anivia | +0.24 | 0.24 | 0.00 |  |
| 87 | Illaoi | +0.24 | 0.24 | 0.00 |  |
| 88 | Jarvan IV | +0.24 | 0.24 | 0.00 |  |
| 89 | Ornn | +0.24 | 0.24 | 0.00 |  |
| 90 | Sett | +0.24 | 0.24 | 0.00 |  |
| 91 | Shyvana | +0.24 | 0.24 | 0.00 |  |
| 92 | Volibear | +0.24 | 0.24 | 0.00 |  |
| 93 | Zyra | +0.24 | 0.24 | 0.00 |  |
| 94 | Annie | +0.22 | 0.22 | 0.00 |  |
| 95 | Brand | +0.22 | 0.22 | 0.00 |  |
| 96 | Graves | +0.22 | 0.22 | 0.00 |  |
| 97 | Nami | +0.22 | 0.22 | 0.00 |  |
| 98 | Neeko | +0.22 | 0.22 | 0.00 |  |
| 99 | Syndra | +0.22 | 0.22 | 0.00 |  |
| 100 | Karma | +0.21 | 0.21 | 0.00 |  |
| 101 | LeBlanc | +0.21 | 0.21 | 0.00 |  |
| 102 | Swain | +0.20 | 0.20 | 0.00 |  |
| 103 | Thresh | +0.18 | 0.18 | 0.00 |  |
| 104 | Skarner | +0.13 | 0.13 | 0.00 |  |
| 105 | Urgot | +0.13 | 0.13 | 0.00 |  |
| 106 | Rakan | +0.11 | 0.11 | 0.00 |  |
| 107 | Lillia | +0.10 | 0.10 | 0.00 |  |
| 108 | Malzahar | +0.08 | 1.25 | 1.17 |  |
| 109 | Mordekaiser | +0.08 | 0.08 | 0.00 |  |
| 110 | Poppy | +0.03 | 0.63 | 0.60 | dash stop (Steadfast Presence) |
| 111 | Varus | 0.00 | 0.27 | 0.27 |  |
| 112 | Aatrox | 0.00 | 0.00 | 0.00 |  |
| 113 | Akali | 0.00 | 0.00 | 0.00 |  |
| 114 | Ambessa | 0.00 | 0.00 | 0.00 |  |
| 115 | Bel'Veth | 0.00 | 0.00 | 0.00 |  |
| 116 | Blitzcrank | 0.00 | 0.00 | 0.00 |  |
| 117 | Briar | 0.00 | 0.00 | 0.00 |  |
| 118 | Cho'Gath | 0.00 | 0.00 | 0.00 |  |
| 119 | Darius | 0.00 | 0.00 | 0.00 |  |
| 120 | Diana | 0.00 | 0.00 | 0.00 |  |
| 121 | Dr. Mundo | 0.00 | 0.00 | 0.00 |  |
| 122 | Ekko | 0.00 | 0.00 | 0.00 |  |
| 123 | Irelia | 0.00 | 0.00 | 0.00 |  |
| 124 | Kassadin | 0.00 | 0.00 | 0.00 |  |
| 125 | Kha'Zix | 0.00 | 0.00 | 0.00 |  |
| 126 | Lee Sin | 0.00 | 0.00 | 0.00 |  |
| 127 | Leona | 0.00 | 0.00 | 0.00 |  |
| 128 | Locke | 0.00 | 0.00 | 0.00 |  |
| 129 | Wukong | 0.00 | 0.00 | 0.00 |  |
| 130 | Nautilus | 0.00 | 0.00 | 0.00 |  |
| 131 | Qiyana | 0.00 | 0.00 | 0.00 |  |
| 132 | Rell | 0.00 | 0.00 | 0.00 |  |
| 133 | Renekton | 0.00 | 0.00 | 0.00 |  |
| 134 | Riven | 0.00 | 0.00 | 0.00 |  |
| 135 | Rumble | 0.00 | 0.00 | 0.00 |  |
| 136 | Sylas | 0.00 | 0.00 | 0.00 |  |
| 137 | Talon | 0.00 | 0.00 | 0.00 |  |
| 138 | Taric | 0.00 | 0.00 | 0.00 |  |
| 139 | Trundle | 0.00 | 0.00 | 0.00 |  |
| 140 | Tryndamere | 0.00 | 0.00 | 0.00 |  |
| 141 | Yorick | 0.00 | 0.00 | 0.00 |  |
| 142 | Aurelion Sol | -0.06 | 0.22 | 0.28 |  |
| 143 | Ivern | -0.18 | 0.18 | 0.36 |  |
| 144 | Kayn | -0.19 | 1.13 | 1.32 |  |
| 145 | Quinn | -0.29 | 0.36 | 0.65 |  |
| 146 | Viego | -0.32 | 0.24 | 0.56 |  |
| 147 | Pyke | -0.40 | 0.00 | 0.40 |  |
| 148 | Rammus | -0.42 | 0.32 | 0.74 |  |
| 149 | Warwick | -0.45 | 1.41 | 1.86 |  |
| 150 | Caitlyn | -0.48 | 0.36 | 0.84 |  |
| 151 | Akshan | -0.48 | 0.32 | 0.80 |  |
| 152 | Gragas | -0.48 | 0.00 | 0.48 |  |
| 153 | Lucian | -0.50 | 0.34 | 0.84 |  |
| 154 | Miss Fortune | -0.52 | 0.32 | 0.84 |  |
| 155 | Jhin | -0.57 | 0.27 | 0.84 |  |
| 156 | Vel'Koz | -0.57 | 0.25 | 0.82 |  |
| 157 | Twisted Fate | -0.65 | 0.40 | 1.05 |  |
| 158 | Zac | -0.66 | 0.50 | 1.16 | dash stop (Stretching Strikes) |
| 159 | Karthus | -0.66 | 0.18 | 0.84 |  |
| 160 | Xerath | -0.71 | 0.25 | 0.96 |  |
| 161 | Katarina | -0.75 | 0.00 | 0.75 |  |
| 162 | Ryze | -0.81 | 0.24 | 1.05 |  |
| 163 | Pantheon | -0.83 | 0.65 | 1.48 |  |
| 164 | Vi | -0.83 | 0.24 | 1.07 |  |
| 165 | Janna | -0.84 | 0.36 | 1.20 |  |
| 166 | Shen | -1.02 | 0.33 | 1.35 |  |
| 167 | Nunu & Willump | -1.07 | 0.28 | 1.35 |  |
| 168 | Fiddlesticks | -1.11 | 0.18 | 1.29 |  |
| 169 | Taliyah | -1.19 | 0.25 | 1.44 |  |
| 170 | Tahm Kench | -1.26 | 0.00 | 1.26 |  |
| 171 | Naafiri | -1.32 | 0.00 | 1.32 |  |
| 172 | Galio | -1.73 | 0.00 | 1.73 |  |
