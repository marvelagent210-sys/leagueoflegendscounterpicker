# Counters to Gnar (patch 26.20)

## Simulated duels

The duel simulator played each of the 78 other champions with a simulator kit against Gnar: both at level 20 with 15,000 gold of plain stats, each side's spent against the other's, through six scenarios (PLAN.md §6). Scores run from −1 (Gnar wins every time) to +1 (the champion does). Run `npm run duel -- <champion> Gnar --log brawl` to watch a fight.

| # | Champion | Score | You engage | Enemy engages | Brawl | Short trade | Spacing | Escape |
|--:|---|--:|--:|--:|--:|--:|--:|--:|
| 1 | Trundle | +0.83 | +1.00 | +1.00 | +1.00 | −0.14 | +1.00 | +1.00 |
| 2 | Poppy | +0.82 | +1.00 | +1.00 | +1.00 | +0.11 | +1.00 | +0.00 |
| 3 | Ashe | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 4 | Teemo | +0.81 | +1.00 | +1.00 | +1.00 | +0.04 | +1.00 | +0.00 |
| 5 | Aurora | +0.80 | +0.99 | +0.99 | +1.00 | +0.03 | +1.00 | +0.00 |
| 6 | Vayne | +0.80 | +1.00 | +1.00 | +1.00 | −0.02 | +1.00 | +0.00 |
| 7 | Quinn | +0.80 | +1.00 | +1.00 | +1.00 | −0.03 | +1.00 | +0.00 |
| 8 | Nasus | +0.79 | +1.00 | +1.00 | +1.00 | −0.08 | +1.00 | +0.00 |
| 9 | K'Sante | +0.79 | +1.00 | +1.00 | +1.00 | −0.09 | +1.00 | +0.00 |
| 10 | Yorick | +0.78 | +1.00 | +1.00 | +1.00 | −0.11 | +1.00 | +0.00 |
| 11 | Garen | +0.78 | +1.00 | +1.00 | +1.00 | −0.12 | +1.00 | +0.00 |
| 12 | Yasuo | +0.78 | +1.00 | +1.00 | +1.00 | −0.13 | +1.00 | +0.00 |
| 13 | Olaf | +0.77 | +1.00 | +1.00 | +1.00 | −0.20 | +1.00 | +0.00 |
| 14 | Darius | +0.77 | +1.00 | +1.00 | +1.00 | −0.23 | +1.00 | +0.00 |
| 15 | Tryndamere | +0.76 | +1.00 | +1.00 | +1.00 | −0.26 | +1.00 | +0.00 |
| 16 | Mordekaiser | +0.72 | +0.97 | +0.97 | +0.88 | −0.12 | +0.78 | +0.00 |
| 17 | Xin Zhao | +0.70 | +1.00 | +1.00 | +1.00 | +0.05 | −0.04 | +0.00 |
| 18 | Jhin | +0.70 | +0.95 | +1.00 | +1.00 | +0.05 | +0.06 | +0.00 |
| 19 | Kayle | +0.67 | +1.00 | +1.00 | +0.07 | +0.35 | +1.00 | +0.00 |
| 20 | Volibear | +0.63 | +1.00 | +1.00 | +1.00 | −0.26 | −0.29 | +0.00 |
| 21 | Sion | +0.62 | +0.87 | +0.87 | +1.00 | −0.10 | −0.04 | +0.00 |
| 22 | Jinx | +0.62 | +0.63 | +0.87 | +0.64 | +0.09 | +1.00 | +0.00 |
| 23 | Zaahen | +0.61 | +1.00 | +1.00 | +0.24 | −0.23 | +1.00 | +0.00 |
| 24 | Jax | +0.61 | +1.00 | +1.00 | +1.00 | +0.03 | −0.99 | +0.00 |
| 25 | Camille | +0.60 | +1.00 | +1.00 | +1.00 | −0.19 | −0.73 | +0.00 |
| 26 | Lucian | +0.57 | +0.12 | +1.00 | +1.00 | −0.04 | +1.00 | +0.00 |
| 27 | Gangplank | +0.53 | +0.31 | +1.00 | +1.00 | −0.03 | +0.06 | +0.00 |
| 28 | Fiora | +0.47 | +0.29 | +0.29 | +1.00 | −0.17 | +1.00 | +1.00 |
| 29 | Jayce | +0.21 | +1.00 | −1.00 | +1.00 | +0.05 | +0.01 | +0.00 |
| 30 | Annie | +0.14 | +0.65 | +0.59 | −0.96 | +0.06 | +0.10 | +0.00 |
| 31 | Illaoi | +0.13 | +1.00 | −1.00 | +1.00 | −0.05 | −0.61 | +0.00 |
| 32 | Irelia | +0.13 | −0.27 | +0.45 | +0.51 | −0.04 | −0.14 | +0.00 |
| 33 | Rammus | +0.10 | +0.88 | +0.88 | −1.00 | −0.28 | −1.00 | +0.00 |
| 34 | Miss Fortune | +0.07 | +1.00 | −0.36 | −1.00 | +0.08 | +1.00 | +0.00 |
| 35 | Anivia | +0.07 | +0.08 | +0.18 | +0.09 | −0.15 | +0.10 | +0.00 |
| 36 | Sett | +0.07 | +1.00 | −1.00 | +1.00 | −0.20 | −1.00 | +0.00 |
| 37 | Aatrox | −0.01 | −0.54 | −0.55 | +1.00 | −0.25 | +1.00 | +0.00 |
| 38 | Master Yi | −0.11 | −0.69 | −0.37 | +0.00 | +0.02 | +1.00 | +1.00 |
| 39 | Dr. Mundo | −0.13 | +0.10 | +0.14 | −0.87 | −0.05 | −0.02 | +0.00 |
| 40 | Ezreal | −0.29 | −0.87 | −0.07 | −0.30 | −0.01 | +0.06 | +0.00 |
| 41 | Malphite | −0.35 | −0.92 | −0.86 | +1.00 | −0.05 | −1.00 | +0.00 |
| 42 | Tahm Kench | −0.37 | −0.25 | −0.65 | −0.33 | −0.12 | −0.66 | +0.00 |
| 43 | Renekton | −0.42 | −1.00 | −1.00 | +1.00 | −0.15 | −1.00 | +0.00 |
| 44 | Rumble | −0.53 | −0.84 | −0.84 | −0.11 | −0.16 | −0.65 | +0.00 |
| 45 | Kennen | −0.59 | −0.97 | −0.97 | −1.00 | −0.03 | +1.00 | +0.00 |
| 46 | Riven | −0.60 | −1.00 | −1.00 | +0.00 | −0.01 | −1.00 | +0.00 |
| 47 | Cho'Gath | −0.68 | −0.89 | −0.89 | −0.53 | −0.19 | −1.00 | +0.00 |
| 48 | Ambessa | −0.70 | −0.94 | −0.94 | −0.61 | −0.19 | −0.76 | +0.00 |
| 49 | Zyra | −0.71 | −1.00 | −1.00 | −1.00 | +0.03 | −0.19 | +0.00 |
| 50 | Yone | −0.73 | −0.53 | −1.00 | −1.00 | −0.28 | −1.00 | +0.00 |
| 51 | Vel'Koz | −0.73 | −1.00 | −1.00 | −0.75 | +0.11 | −1.00 | +0.00 |
| 52 | Pantheon | −0.74 | −1.00 | −1.00 | −0.86 | −0.08 | −0.57 | +0.00 |
| 53 | Karthus | −0.75 | −1.00 | −1.00 | −1.00 | −0.02 | −0.51 | +0.00 |
| 54 | Heimerdinger | −0.76 | −1.00 | −1.00 | −1.00 | +0.06 | −0.73 | +0.00 |
| 55 | Ziggs | −0.77 | −1.00 | −1.00 | −1.00 | +0.17 | −1.00 | +0.00 |
| 56 | Cassiopeia | −0.79 | −1.00 | −1.00 | −1.00 | +0.09 | −1.00 | +0.00 |
| 57 | Skarner | −0.79 | −1.00 | −1.00 | −1.00 | +0.06 | −1.00 | +0.00 |
| 58 | Caitlyn | −0.79 | −1.00 | −1.00 | −1.00 | +0.04 | −1.00 | +0.00 |
| 59 | Brand | −0.80 | −1.00 | −1.00 | −1.00 | +0.03 | −1.00 | +0.00 |
| 60 | Lissandra | −0.80 | −1.00 | −1.00 | −1.00 | +0.03 | −1.00 | +0.00 |
| 61 | Lux | −0.80 | −1.00 | −1.00 | −1.00 | +0.03 | −1.00 | +0.00 |
| 62 | Kled | −0.80 | −1.00 | −1.00 | −1.00 | +0.03 | −1.00 | +0.00 |
| 63 | Ahri | −0.80 | −1.00 | −1.00 | −1.00 | +0.02 | −1.00 | +0.00 |
| 64 | Shen | −0.80 | −1.00 | −1.00 | −1.00 | +0.02 | −1.00 | +0.00 |
| 65 | Malzahar | −0.80 | −1.00 | −1.00 | −1.00 | +0.01 | −1.00 | +0.00 |
| 66 | Urgot | −0.80 | −1.00 | −1.00 | −1.00 | +0.01 | −1.00 | +0.00 |
| 67 | Nautilus | −0.80 | −1.00 | −1.00 | −1.00 | +0.00 | −1.00 | +0.00 |
| 68 | Veigar | −0.80 | −1.00 | −1.00 | −1.00 | −0.01 | −1.00 | +0.00 |
| 69 | Leona | −0.80 | −1.00 | −1.00 | −1.00 | −0.03 | −1.00 | +0.00 |
| 70 | Akali | −0.81 | −1.00 | −1.00 | −1.00 | −0.04 | −1.00 | +0.00 |
| 71 | Morgana | −0.81 | −1.00 | −1.00 | −1.00 | −0.07 | −1.00 | +0.00 |
| 72 | Udyr | −0.82 | −1.00 | −1.00 | −1.00 | −0.14 | −1.00 | +0.06 |
| 73 | Ornn | −0.82 | −1.00 | −1.00 | −1.00 | −0.12 | −1.00 | +0.00 |
| 74 | Amumu | −0.82 | −1.00 | −1.00 | −1.00 | −0.14 | −1.00 | +0.00 |
| 75 | Singed | −0.83 | −1.00 | −1.00 | −1.00 | −0.19 | −1.00 | +0.00 |
| 76 | Kassadin | −0.83 | −1.00 | −1.00 | −1.00 | −0.22 | −1.00 | +0.00 |
| 77 | Vladimir | −0.84 | −1.00 | −1.00 | −1.00 | −0.25 | −1.00 | +0.00 |
| 78 | Gwen | −0.86 | −1.00 | −1.00 | −1.00 | −0.39 | −1.00 | +0.00 |

## Interaction ledger estimates

Every champion ranked by what its kit does against Gnar's, from the interaction ledger: projectile blocks, spell shields,
parries, dash stops, crowd control and its defenses, range and more (PLAN.md §5). This ranking is **partial**: it weighs the
interactions but doesn't play the fight out. The duel simulator replaces it as each champion's behavior is verified.

"For" sums the interactions in the champion's favor, "against" those in Gnar's; net = for − against.
A hard counter shuts down part of a kit every time it is used (projectile block, attack dodge, attack block, blind, disarm, attack speed slow, attack reflect, dash stop, grounding, range) with an impact of 0.4 or more (0.5 for range).
Run `npm run matchup -- <champion> Gnar` for the full ledger of a matchup, with sources.

### Top 10

#### 1. Morgana (net +1.09)

- **0.80** cc immunity: Black Shield makes Morgana immune to Gnar's GNAR! (airborne, slow, stun). Immune for 5 s, long enough to use ahead of GNAR!. (Morgana E Black Shield → Gnar R GNAR!)
- **0.46** cc immunity: Black Shield makes Morgana immune to Gnar's Wallop (stun). Immune for 5 s, long enough to use ahead of Wallop. (Morgana E Black Shield → Gnar W Wallop)
- **0.13** cc immunity: Black Shield makes Morgana immune to Gnar's Crunch (slow). Immune for 5 s, long enough to use ahead of Crunch. (Morgana E Black Shield → Gnar E Crunch)

#### 2. Sivir (net +1.02)

- **0.80** spell shield: Spell Shield's spell shield blocks Gnar's GNAR!. Spell shield for 1.5 s, long enough to use ahead of GNAR!. A spell shield blocks only the first enemy ability that reaches it. (Sivir E Spell Shield → Gnar R GNAR!)
- **0.44** spell shield: Spell Shield's spell shield blocks Gnar's Wallop. Spell shield for 1.5 s, long enough to use ahead of Wallop. A spell shield blocks only the first enemy ability that reaches it. (Sivir E Spell Shield → Gnar W Wallop)

#### 3. Fizz (net +0.99)

- **0.80** untargetable: Playful makes Fizz untargetable, dodging Gnar's GNAR!. Untargetable for 0.75 s; GNAR! takes 0.25 s to land, enough to react. (Fizz E Playful → Gnar R GNAR!)
- **0.65** untargetable: Playful makes Fizz untargetable, dodging Gnar's Wallop. Untargetable for 0.75 s; Wallop takes 0.6 s to land, enough to react. (Fizz E Playful → Gnar W Wallop)
- Watch out: Gnar's basic attacks reach 336.765 units farther than Fizz's (511.765 vs 175 attack range).

#### 4. Udyr (net +0.89)

- **0.80** cc immunity: Blazing Stampede makes Udyr immune to Gnar's GNAR! (airborne, slow, stun). Immune for 1.5 s, long enough to use ahead of GNAR!. (Udyr E Blazing Stampede → Gnar R GNAR!)
- **0.70** cc immunity: Blazing Stampede makes Udyr immune to Gnar's Wallop (stun). Immune for 1.5 s, long enough to use ahead of Wallop. (Udyr E Blazing Stampede → Gnar W Wallop)
- **0.15** cc immunity: Blazing Stampede makes Udyr immune to Gnar's Crunch (slow). Immune for 1.5 s, long enough to use ahead of Crunch. (Udyr E Blazing Stampede → Gnar E Crunch)
- Watch out: Gnar's basic attacks reach 386.765 units farther than Udyr's (511.765 vs 125 attack range).

#### 5. Fiora (net +0.89)

- **0.90** parry: Riposte parries Gnar's GNAR! and stuns back. Parry for 0.75 s; GNAR! takes 0.25 s to land, enough to react. Negating GNAR!'s immobilizing effect turns Riposte's slow into a stun (2 s). (Fiora W Riposte → Gnar R GNAR!)
- **0.56** parry: Riposte parries Gnar's Wallop and stuns back. Parry for 0.75 s; Wallop takes 0.6 s to land, enough to react. Negating Wallop's immobilizing effect turns Riposte's slow into a stun (2 s). (Fiora W Riposte → Gnar W Wallop)
- **0.08** attack speed slow: Riposte cuts Gnar's attack speed by 25% for 2 s. 2 s on a 16 s cooldown. (Fiora W Riposte → Gnar basic attacks)
- Watch out: Gnar's basic attacks reach 361.765 units farther than Fiora's (511.765 vs 150 attack range).

#### 6. Vladimir (net +0.88)

- **0.80** untargetable: Sanguine Pool makes Vladimir untargetable, dodging Gnar's GNAR!. Untargetable for 2 s, long enough to use ahead of GNAR!. (Vladimir W Sanguine Pool → Gnar R GNAR!)
- **0.46** untargetable: Sanguine Pool makes Vladimir untargetable, dodging Gnar's Wallop. Untargetable for 2 s, long enough to use ahead of Wallop. (Vladimir W Sanguine Pool → Gnar W Wallop)
- Watch out: Wallop's stun interrupts Vladimir's Tides of Blood (charge-up).

#### 7. Nocturne (net +0.81)

- **0.80** spell shield: Shroud of Darkness's spell shield blocks Gnar's GNAR!. Spell shield for 1.5 s, long enough to use ahead of GNAR!. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Gnar R GNAR!)
- **0.52** spell shield: Shroud of Darkness's spell shield blocks Gnar's Wallop. Spell shield for 1.5 s, long enough to use ahead of Wallop. A spell shield blocks only the first enemy ability that reaches it. (Nocturne W Shroud of Darkness → Gnar W Wallop)
- **0.08** cc immunity: Paranoia is displacement immune, ignoring Gnar's GNAR! (airborne) during it. Only during Paranoia. (Nocturne R Paranoia → Gnar R GNAR!)
- Watch out: Gnar's basic attacks reach 386.765 units farther than Nocturne's (511.765 vs 125 attack range).

#### 8. Maokai (net +0.76)

- **0.80** untargetable: Twisted Advance makes Maokai untargetable, dodging Gnar's GNAR!. Untargetable for 1.4 s; GNAR! takes 0.25 s to land, enough to react. (Maokai W Twisted Advance → Gnar R GNAR!)
- **0.57** untargetable: Twisted Advance makes Maokai untargetable, dodging Gnar's Wallop. Untargetable for 1.4 s; Wallop takes 0.6 s to land, enough to react. (Maokai W Twisted Advance → Gnar W Wallop)
- Watch out: Gnar's basic attacks reach 386.765 units farther than Maokai's (511.765 vs 125 attack range).

#### 9. Lissandra (net +0.72)

- **0.50** untargetable: Frozen Tomb makes Lissandra untargetable, dodging Gnar's GNAR!. Untargetable for 2.5 s, long enough to use ahead of GNAR!. (Lissandra R Frozen Tomb → Gnar R GNAR!)
- **0.32** untargetable: Frozen Tomb makes Lissandra untargetable, dodging Gnar's Wallop. Untargetable for 2.5 s, long enough to use ahead of Wallop. (Lissandra R Frozen Tomb → Gnar W Wallop)
- **0.15** dash stop: Frozen Tomb's knockdown can stop Gnar's Crunch mid-dash. Must land during the dash. Fails if the dashing unit is crowd control immune, displacement immune, untargetable or spell shielded. (Lissandra R Frozen Tomb → Gnar E Crunch)

#### 10. Gwen (net +0.71)

- **0.80** untargetable: Hallowed Mist makes Gwen untargetable, dodging Gnar's GNAR!. Untargetable for ?; GNAR! takes 0.25 s to land, enough to react. Does not destroy inbound projectiles for non-champion missiles but does so for champion missiles that attempt to pass through the mist, special cased to be targetable to turrets and monsters as well as enemies inside the mist. (Gwen W Hallowed Mist → Gnar R GNAR!)
- **0.44** untargetable: Hallowed Mist makes Gwen untargetable, dodging Gnar's Wallop. Untargetable for ?; Wallop takes 0.6 s to land, enough to react. Does not destroy inbound projectiles for non-champion missiles but does so for champion missiles that attempt to pass through the mist, special cased to be targetable to turrets and monsters as well as enemies inside the mist. (Gwen W Hallowed Mist → Gnar W Wallop)
- Watch out: Gnar's basic attacks reach 361.765 units farther than Gwen's (511.765 vs 150 attack range).

### Full ranking

| # | Champion | Net | For | Against | Hard counters |
|--:|---|--:|--:|--:|---|
| 1 | Morgana | +1.09 | 1.09 | 0.00 |  |
| 2 | Sivir | +1.02 | 1.02 | 0.00 |  |
| 3 | Fizz | +0.99 | 1.13 | 0.14 |  |
| 4 | Udyr | +0.89 | 1.22 | 0.33 |  |
| 5 | Fiora | +0.89 | 1.20 | 0.31 |  |
| 6 | Vladimir | +0.88 | 1.03 | 0.15 |  |
| 7 | Nocturne | +0.81 | 1.14 | 0.33 |  |
| 8 | Maokai | +0.76 | 1.09 | 0.33 |  |
| 9 | Lissandra | +0.72 | 0.72 | 0.00 |  |
| 10 | Gwen | +0.71 | 1.02 | 0.31 |  |
| 11 | Bard | +0.66 | 0.66 | 0.00 |  |
| 12 | Aurora | +0.64 | 0.64 | 0.00 |  |
| 13 | Xayah | +0.62 | 0.62 | 0.00 |  |
| 14 | Master Yi | +0.54 | 1.20 | 0.66 |  |
| 15 | Milio | +0.54 | 0.54 | 0.00 |  |
| 16 | Kled | +0.52 | 0.63 | 0.11 |  |
| 17 | Camille | +0.50 | 0.66 | 0.16 |  |
| 18 | Kalista | +0.50 | 0.50 | 0.00 |  |
| 19 | Rek'Sai | +0.49 | 0.68 | 0.19 |  |
| 20 | Zaahen | +0.49 | 0.68 | 0.19 |  |
| 21 | Samira | +0.49 | 0.49 | 0.00 |  |
| 22 | Vex | +0.47 | 0.47 | 0.00 |  |
| 23 | Mel | +0.46 | 0.46 | 0.00 |  |
| 24 | Ahri | +0.45 | 0.45 | 0.00 |  |
| 25 | Hwei | +0.45 | 0.45 | 0.00 |  |
| 26 | Jinx | +0.45 | 0.45 | 0.00 |  |
| 27 | Teemo | +0.45 | 0.45 | 0.00 | blind (Blinding Dart) |
| 28 | Evelynn | +0.44 | 0.66 | 0.22 |  |
| 29 | Shaco | +0.44 | 0.66 | 0.22 |  |
| 30 | Cassiopeia | +0.43 | 0.43 | 0.00 |  |
| 31 | Viktor | +0.43 | 0.43 | 0.00 |  |
| 32 | Braum | +0.41 | 0.74 | 0.33 | projectile block (Unbreakable), projectile block (Unbreakable) |
| 33 | Veigar | +0.41 | 0.41 | 0.00 |  |
| 34 | Zed | +0.40 | 0.62 | 0.22 |  |
| 35 | Kayle | +0.40 | 0.40 | 0.00 |  |
| 36 | Yasuo | +0.37 | 0.56 | 0.19 |  |
| 37 | Lulu | +0.32 | 0.32 | 0.00 |  |
| 38 | Yuumi | +0.27 | 1.15 | 0.88 |  |
| 39 | Rengar | +0.26 | 0.92 | 0.66 |  |
| 40 | Gangplank | +0.22 | 0.88 | 0.66 |  |
| 41 | Alistar | +0.22 | 0.55 | 0.33 |  |
| 42 | Yone | +0.17 | 0.31 | 0.14 |  |
| 43 | Aphelios | +0.13 | 0.13 | 0.00 |  |
| 44 | Heimerdinger | +0.13 | 0.13 | 0.00 |  |
| 45 | Tristana | +0.11 | 0.11 | 0.00 |  |
| 46 | Nilah | +0.07 | 0.31 | 0.24 |  |
| 47 | Ashe | +0.05 | 0.05 | 0.00 |  |
| 48 | Senna | +0.05 | 0.05 | 0.00 |  |
| 49 | Malzahar | +0.04 | 0.84 | 0.80 |  |
| 50 | Annie | +0.04 | 0.04 | 0.00 |  |
| 51 | Olaf | +0.03 | 0.69 | 0.66 |  |
| 52 | Jax | +0.03 | 0.36 | 0.33 |  |
| 53 | Anivia | +0.03 | 0.03 | 0.00 |  |
| 54 | Xin Zhao | +0.02 | 0.31 | 0.29 |  |
| 55 | Garen | +0.01 | 0.58 | 0.57 |  |
| 56 | K'Sante | +0.01 | 0.16 | 0.15 |  |
| 57 | Azir | 0.00 | 0.00 | 0.00 |  |
| 58 | Brand | 0.00 | 0.00 | 0.00 |  |
| 59 | Corki | 0.00 | 0.00 | 0.00 |  |
| 60 | Draven | 0.00 | 0.00 | 0.00 |  |
| 61 | Elise | 0.00 | 0.00 | 0.00 |  |
| 62 | Ezreal | 0.00 | 0.00 | 0.00 |  |
| 63 | Jayce | 0.00 | 0.00 | 0.00 |  |
| 64 | Kai'Sa | 0.00 | 0.00 | 0.00 |  |
| 65 | Karma | 0.00 | 0.00 | 0.00 |  |
| 66 | Kennen | 0.00 | 0.00 | 0.00 |  |
| 67 | Kindred | 0.00 | 0.00 | 0.00 |  |
| 68 | Kog'Maw | 0.00 | 0.00 | 0.00 |  |
| 69 | LeBlanc | 0.00 | 0.00 | 0.00 |  |
| 70 | Lux | 0.00 | 0.00 | 0.00 |  |
| 71 | Nami | 0.00 | 0.00 | 0.00 |  |
| 72 | Neeko | 0.00 | 0.00 | 0.00 |  |
| 73 | Nidalee | 0.00 | 0.00 | 0.00 |  |
| 74 | Orianna | 0.00 | 0.00 | 0.00 |  |
| 75 | Renata Glasc | 0.00 | 0.00 | 0.00 |  |
| 76 | Seraphine | 0.00 | 0.00 | 0.00 |  |
| 77 | Smolder | 0.00 | 0.00 | 0.00 |  |
| 78 | Sona | 0.00 | 0.00 | 0.00 |  |
| 79 | Soraka | 0.00 | 0.00 | 0.00 |  |
| 80 | Swain | 0.00 | 0.00 | 0.00 |  |
| 81 | Syndra | 0.00 | 0.00 | 0.00 |  |
| 82 | Thresh | 0.00 | 0.00 | 0.00 |  |
| 83 | Twitch | 0.00 | 0.00 | 0.00 |  |
| 84 | Vayne | 0.00 | 0.00 | 0.00 |  |
| 85 | Yunara | 0.00 | 0.00 | 0.00 |  |
| 86 | Zeri | 0.00 | 0.00 | 0.00 |  |
| 87 | Ziggs | 0.00 | 0.00 | 0.00 |  |
| 88 | Zilean | 0.00 | 0.00 | 0.00 |  |
| 89 | Zoe | 0.00 | 0.00 | 0.00 |  |
| 90 | Zyra | 0.00 | 0.00 | 0.00 |  |
| 91 | Malphite | -0.03 | 0.30 | 0.33 |  |
| 92 | Graves | -0.05 | 0.00 | 0.05 |  |
| 93 | Sion | -0.06 | 0.76 | 0.82 |  |
| 94 | Jarvan IV | -0.06 | 0.08 | 0.14 |  |
| 95 | Hecarim | -0.11 | 0.08 | 0.19 |  |
| 96 | Ornn | -0.11 | 0.08 | 0.19 |  |
| 97 | Amumu | -0.12 | 0.21 | 0.33 |  |
| 98 | Rakan | -0.12 | 0.00 | 0.12 |  |
| 99 | Volibear | -0.13 | 0.08 | 0.21 |  |
| 100 | Sylas | -0.14 | 0.00 | 0.14 |  |
| 101 | Urgot | -0.14 | 0.00 | 0.14 |  |
| 102 | Aurelion Sol | -0.15 | 0.00 | 0.15 |  |
| 103 | Briar | -0.16 | 0.00 | 0.16 |  |
| 104 | Lillia | -0.16 | 0.00 | 0.16 |  |
| 105 | Varus | -0.18 | 0.00 | 0.18 |  |
| 106 | Wukong | -0.19 | 0.00 | 0.19 |  |
| 107 | Rell | -0.19 | 0.00 | 0.19 |  |
| 108 | Singed | -0.21 | 0.45 | 0.66 |  |
| 109 | Bel'Veth | -0.21 | 0.00 | 0.21 |  |
| 110 | Qiyana | -0.21 | 0.00 | 0.21 |  |
| 111 | Poppy | -0.22 | 0.51 | 0.73 |  |
| 112 | Akali | -0.22 | 0.00 | 0.22 |  |
| 113 | Ambessa | -0.22 | 0.00 | 0.22 |  |
| 114 | Ekko | -0.22 | 0.00 | 0.22 |  |
| 115 | Lee Sin | -0.22 | 0.00 | 0.22 |  |
| 116 | Riven | -0.22 | 0.00 | 0.22 |  |
| 117 | Talon | -0.22 | 0.00 | 0.22 |  |
| 118 | Shyvana | -0.23 | 0.08 | 0.31 |  |
| 119 | Ivern | -0.24 | 0.00 | 0.24 |  |
| 120 | Illaoi | -0.25 | 0.08 | 0.33 |  |
| 121 | Sett | -0.25 | 0.08 | 0.33 |  |
| 122 | Irelia | -0.27 | 0.00 | 0.27 |  |
| 123 | Aatrox | -0.29 | 0.00 | 0.29 |  |
| 124 | Nautilus | -0.29 | 0.00 | 0.29 |  |
| 125 | Tryndamere | -0.29 | 0.00 | 0.29 |  |
| 126 | Diana | -0.31 | 0.00 | 0.31 |  |
| 127 | Kassadin | -0.31 | 0.00 | 0.31 |  |
| 128 | Sejuani | -0.31 | 0.00 | 0.31 |  |
| 129 | Nasus | -0.32 | 0.34 | 0.66 |  |
| 130 | Kha'Zix | -0.33 | 0.00 | 0.33 |  |
| 131 | Leona | -0.33 | 0.00 | 0.33 |  |
| 132 | Locke | -0.33 | 0.00 | 0.33 |  |
| 133 | Renekton | -0.33 | 0.00 | 0.33 |  |
| 134 | Quinn | -0.36 | 0.00 | 0.36 |  |
| 135 | Kayn | -0.43 | 0.66 | 1.09 |  |
| 136 | Viego | -0.44 | 0.08 | 0.52 |  |
| 137 | Skarner | -0.46 | 0.16 | 0.62 |  |
| 138 | Caitlyn | -0.48 | 0.08 | 0.56 |  |
| 139 | Rammus | -0.49 | 0.34 | 0.83 |  |
| 140 | Mordekaiser | -0.49 | 0.08 | 0.57 |  |
| 141 | Pyke | -0.49 | 0.00 | 0.49 |  |
| 142 | Akshan | -0.56 | 0.00 | 0.56 |  |
| 143 | Jhin | -0.56 | 0.00 | 0.56 |  |
| 144 | Karthus | -0.56 | 0.00 | 0.56 |  |
| 145 | Lucian | -0.56 | 0.00 | 0.56 |  |
| 146 | Miss Fortune | -0.56 | 0.00 | 0.56 |  |
| 147 | Vel'Koz | -0.56 | 0.00 | 0.56 |  |
| 148 | Darius | -0.57 | 0.00 | 0.57 |  |
| 149 | Trundle | -0.57 | 0.00 | 0.57 |  |
| 150 | Yorick | -0.57 | 0.00 | 0.57 |  |
| 151 | Taric | -0.62 | 0.00 | 0.62 |  |
| 152 | Zac | -0.63 | 0.45 | 1.08 |  |
| 153 | Gragas | -0.63 | 0.00 | 0.63 |  |
| 154 | Xerath | -0.64 | 0.00 | 0.64 |  |
| 155 | Blitzcrank | -0.66 | 0.00 | 0.66 |  |
| 156 | Cho'Gath | -0.66 | 0.00 | 0.66 |  |
| 157 | Dr. Mundo | -0.66 | 0.00 | 0.66 |  |
| 158 | Rumble | -0.66 | 0.00 | 0.66 |  |
| 159 | Pantheon | -0.67 | 0.51 | 1.18 |  |
| 160 | Warwick | -0.68 | 0.83 | 1.51 |  |
| 161 | Ryze | -0.70 | 0.00 | 0.70 |  |
| 162 | Twisted Fate | -0.70 | 0.00 | 0.70 |  |
| 163 | Shen | -0.78 | 0.34 | 1.12 |  |
| 164 | Janna | -0.80 | 0.00 | 0.80 |  |
| 165 | Vi | -0.86 | 0.08 | 0.94 |  |
| 166 | Fiddlesticks | -0.88 | 0.00 | 0.88 |  |
| 167 | Katarina | -0.89 | 0.00 | 0.89 |  |
| 168 | Taliyah | -0.96 | 0.00 | 0.96 |  |
| 169 | Naafiri | -1.06 | 0.00 | 1.06 |  |
| 170 | Tahm Kench | -1.16 | 0.00 | 1.16 |  |
| 171 | Nunu & Willump | -1.24 | 0.31 | 1.55 |  |
| 172 | Galio | -1.36 | 0.00 | 1.36 |  |
