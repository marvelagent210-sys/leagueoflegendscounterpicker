# Counters to Katarina (patch 26.20)

## Simulated duels

The duel simulator played each of the 114 other champions with a simulator kit against Katarina: both at level 20 with 15,000 gold of plain stats, each side's spent against the other's, through six scenarios (PLAN.md §6). Scores run from −1 (Katarina wins every time) to +1 (the champion does). Run `npm run duel -- <champion> Katarina --log brawl` to watch a fight.

| # | Champion | Score | You engage | Enemy engages | Brawl | Short trade | Spacing | Escape |
|--:|---|--:|--:|--:|--:|--:|--:|--:|
| 1 | K'Sante | +0.87 | +1.00 | +1.00 | +1.00 | +0.25 | – | +1.00 |
| 2 | Yorick | +0.87 | +1.00 | +1.00 | +1.00 | +0.22 | – | +1.00 |
| 3 | Trundle | +0.86 | +1.00 | +1.00 | +1.00 | +0.09 | +1.00 | +1.00 |
| 4 | Rengar | +0.86 | +1.00 | +1.00 | +1.00 | +0.48 | – | +0.00 |
| 5 | Urgot | +0.86 | +1.00 | +1.00 | +1.00 | +0.38 | +1.00 | +0.00 |
| 6 | Udyr | +0.86 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +1.00 |
| 7 | Master Yi | +0.85 | +1.00 | +1.00 | +1.00 | +0.01 | +1.00 | +1.00 |
| 8 | Fiora | +0.85 | +1.00 | +1.00 | +1.00 | +0.09 | – | +1.00 |
| 9 | Vayne | +0.85 | +1.00 | +1.00 | +1.00 | +0.32 | +1.00 | +0.00 |
| 10 | Heimerdinger | +0.84 | +1.00 | +1.00 | +1.00 | +0.27 | +1.00 | +0.00 |
| 11 | Kayle | +0.83 | +1.00 | +1.00 | +1.00 | +0.22 | +1.00 | +0.00 |
| 12 | Jayce | +0.83 | +1.00 | +1.00 | +1.00 | +0.32 | – | +0.00 |
| 13 | Kalista | +0.83 | +1.00 | +1.00 | +1.00 | +0.19 | +1.00 | +0.00 |
| 14 | Samira | +0.83 | +1.00 | +1.00 | +1.00 | +0.18 | +1.00 | +0.00 |
| 15 | Ziggs | +0.83 | +1.00 | +1.00 | +1.00 | +0.18 | +1.00 | +0.00 |
| 16 | Aphelios | +0.83 | +1.00 | +1.00 | +1.00 | +0.18 | +1.00 | +0.00 |
| 17 | Tristana | +0.82 | +1.00 | +1.00 | +1.00 | +0.17 | +1.00 | +0.00 |
| 18 | Smolder | +0.82 | +1.00 | +1.00 | +1.00 | +0.16 | +1.00 | +0.00 |
| 19 | Graves | +0.82 | +1.00 | +1.00 | +1.00 | +0.16 | +1.00 | +0.00 |
| 20 | Nasus | +0.82 | +1.00 | +1.00 | +1.00 | +0.14 | +1.00 | +0.00 |
| 21 | Vel'Koz | +0.82 | +1.00 | +1.00 | +1.00 | +0.14 | +1.00 | +0.00 |
| 22 | Poppy | +0.82 | +1.00 | +1.00 | +1.00 | +0.25 | – | +0.00 |
| 23 | Gangplank | +0.82 | +1.00 | +1.00 | +1.00 | +0.24 | – | +0.00 |
| 24 | Zeri | +0.82 | +1.00 | +1.00 | +1.00 | +0.12 | +1.00 | +0.00 |
| 25 | Annie | +0.82 | +1.00 | +1.00 | +1.00 | +0.11 | +1.00 | +0.00 |
| 26 | Teemo | +0.82 | +1.00 | +1.00 | +1.00 | +0.11 | +1.00 | +0.00 |
| 27 | Kai'Sa | +0.82 | +1.00 | +1.00 | +1.00 | +0.11 | +1.00 | +0.00 |
| 28 | Cassiopeia | +0.82 | +1.00 | +1.00 | +1.00 | +0.11 | +1.00 | +0.00 |
| 29 | Garen | +0.81 | +1.00 | +1.00 | +1.00 | +0.22 | – | +0.00 |
| 30 | Kog'Maw | +0.81 | +1.00 | +1.00 | +1.00 | +0.10 | +1.00 | +0.00 |
| 31 | Ahri | +0.81 | +1.00 | +1.00 | +1.00 | +0.10 | +1.00 | +0.00 |
| 32 | Ambessa | +0.81 | +1.00 | +1.00 | +1.00 | +0.22 | – | +0.00 |
| 33 | Ornn | +0.81 | +1.00 | +1.00 | +1.00 | +0.21 | – | +0.00 |
| 34 | Olaf | +0.81 | +1.00 | +1.00 | +1.00 | +0.08 | +1.00 | +0.00 |
| 35 | Jhin | +0.81 | +1.00 | +1.00 | +1.00 | +0.08 | +1.00 | +0.00 |
| 36 | Jax | +0.81 | +1.00 | +1.00 | +1.00 | +0.07 | +1.00 | +0.00 |
| 37 | Lucian | +0.81 | +1.00 | +1.00 | +1.00 | +0.07 | +1.00 | +0.00 |
| 38 | Xayah | +0.81 | +1.00 | +1.00 | +1.00 | +0.07 | +1.00 | +0.00 |
| 39 | Ashe | +0.81 | +1.00 | +1.00 | +1.00 | +0.07 | +1.00 | +0.00 |
| 40 | Morgana | +0.81 | +1.00 | +1.00 | +1.00 | +0.07 | +1.00 | +0.00 |
| 41 | Tahm Kench | +0.81 | +1.00 | +1.00 | +1.00 | +0.19 | – | +0.00 |
| 42 | Quinn | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 43 | Skarner | +0.81 | +1.00 | +1.00 | +1.00 | +0.18 | – | +0.00 |
| 44 | Miss Fortune | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 45 | Illaoi | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 46 | Caitlyn | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 47 | Jinx | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 48 | Twitch | +0.81 | +1.00 | +1.00 | +1.00 | +0.05 | +1.00 | +0.00 |
| 49 | Lux | +0.81 | +1.00 | +1.00 | +1.00 | +0.06 | +0.98 | +0.00 |
| 50 | Gnar | +0.81 | +1.00 | +1.00 | +1.00 | +0.04 | +1.00 | +0.00 |
| 51 | Fizz | +0.81 | +1.00 | +1.00 | +1.00 | +0.16 | – | +0.00 |
| 52 | Brand | +0.80 | +1.00 | +1.00 | +1.00 | +0.03 | +1.00 | +0.00 |
| 53 | Draven | +0.80 | +1.00 | +1.00 | +1.00 | +0.03 | +1.00 | +0.00 |
| 54 | Malphite | +0.80 | +1.00 | +1.00 | +1.00 | +0.16 | – | +0.00 |
| 55 | Ezreal | +0.80 | +1.00 | +1.00 | +1.00 | +0.03 | +1.00 | +0.00 |
| 56 | Nautilus | +0.80 | +1.00 | +1.00 | +1.00 | +0.16 | – | +0.00 |
| 57 | Jarvan IV | +0.80 | +1.00 | +1.00 | +1.00 | +0.16 | – | +0.00 |
| 58 | Irelia | +0.80 | +1.00 | +1.00 | +1.00 | +0.16 | – | +0.00 |
| 59 | Gwen | +0.80 | +1.00 | +1.00 | +1.00 | +0.15 | – | +0.00 |
| 60 | Kindred | +0.80 | +1.00 | +1.00 | +1.00 | +0.02 | +1.00 | +0.00 |
| 61 | Xin Zhao | +0.80 | +1.00 | +1.00 | +1.00 | +0.15 | – | +0.00 |
| 62 | Akshan | +0.80 | +1.00 | +1.00 | +1.00 | +0.02 | +1.00 | +0.00 |
| 63 | LeBlanc | +0.80 | +1.00 | +1.00 | +1.00 | +0.01 | +1.00 | +0.00 |
| 64 | Aurora | +0.80 | +1.00 | +1.00 | +1.00 | +0.01 | +1.00 | +0.00 |
| 65 | Varus | +0.80 | +1.00 | +1.00 | +1.00 | +0.01 | +1.00 | +0.00 |
| 66 | Cho'Gath | +0.80 | +1.00 | +1.00 | +1.00 | +0.14 | – | +0.00 |
| 67 | Kennen | +0.80 | +1.00 | +1.00 | +1.00 | +0.01 | +1.00 | +0.00 |
| 68 | Yone | +0.80 | +1.00 | +1.00 | +1.00 | +0.14 | – | +0.00 |
| 69 | Shen | +0.80 | +1.00 | +1.00 | +1.00 | +0.13 | – | +0.00 |
| 70 | Corki | +0.80 | +1.00 | +1.00 | +1.00 | −0.00 | +1.00 | +0.00 |
| 71 | Kassadin | +0.80 | +1.00 | +1.00 | +1.00 | +0.13 | – | +0.00 |
| 72 | Lee Sin | +0.80 | +1.00 | +1.00 | +1.00 | +0.13 | – | +0.00 |
| 73 | Volibear | +0.80 | +1.00 | +1.00 | +1.00 | +0.12 | – | +0.00 |
| 74 | Pantheon | +0.80 | +1.00 | +1.00 | +1.00 | +0.12 | – | +0.00 |
| 75 | Zaahen | +0.80 | +1.00 | +1.00 | +1.00 | +0.12 | – | +0.00 |
| 76 | Sion | +0.80 | +1.00 | +1.00 | +1.00 | +0.11 | – | +0.00 |
| 77 | Diana | +0.80 | +1.00 | +1.00 | +1.00 | +0.11 | – | +0.00 |
| 78 | Naafiri | +0.80 | +1.00 | +1.00 | +1.00 | +0.11 | – | +0.00 |
| 79 | Yasuo | +0.79 | +1.00 | +1.00 | +1.00 | +0.10 | – | +0.00 |
| 80 | Sivir | +0.79 | +1.00 | +1.00 | +1.00 | −0.04 | +1.00 | +0.00 |
| 81 | Warwick | +0.79 | +1.00 | +1.00 | +1.00 | +0.10 | – | +0.00 |
| 82 | Vi | +0.79 | +1.00 | +1.00 | +1.00 | +0.08 | – | +0.00 |
| 83 | Rumble | +0.79 | +1.00 | +1.00 | +1.00 | +0.08 | – | +0.00 |
| 84 | Riven | +0.79 | +1.00 | +1.00 | +1.00 | +0.07 | – | +0.00 |
| 85 | Hecarim | +0.79 | +1.00 | +1.00 | +1.00 | +0.07 | – | +0.00 |
| 86 | Mordekaiser | +0.79 | +1.00 | +1.00 | +1.00 | +0.06 | – | +0.00 |
| 87 | Amumu | +0.79 | +1.00 | +1.00 | +1.00 | +0.06 | – | +0.00 |
| 88 | Aatrox | +0.79 | +1.00 | +1.00 | +1.00 | +0.06 | – | +0.00 |
| 89 | Dr. Mundo | +0.79 | +1.00 | +1.00 | +1.00 | +0.06 | – | +0.00 |
| 90 | Zed | +0.79 | +1.00 | +1.00 | +1.00 | +0.06 | – | +0.00 |
| 91 | Singed | +0.79 | +1.00 | +1.00 | +1.00 | +0.06 | – | +0.00 |
| 92 | Rammus | +0.79 | +1.00 | +1.00 | +1.00 | +0.05 | – | +0.00 |
| 93 | Sett | +0.79 | +1.00 | +1.00 | +1.00 | +0.05 | – | +0.00 |
| 94 | Lissandra | +0.79 | +1.00 | +1.00 | +1.00 | −0.05 | +0.93 | +0.00 |
| 95 | Tryndamere | +0.78 | +1.00 | +1.00 | +1.00 | +0.04 | – | +0.00 |
| 96 | Camille | +0.78 | +1.00 | +1.00 | +1.00 | +0.03 | – | +0.00 |
| 97 | Renekton | +0.78 | +1.00 | +1.00 | +1.00 | +0.03 | – | +0.00 |
| 98 | Leona | +0.78 | +1.00 | +1.00 | +1.00 | +0.03 | – | +0.00 |
| 99 | Nocturne | +0.78 | +1.00 | +1.00 | +1.00 | +0.02 | – | +0.00 |
| 100 | Kled | +0.78 | +1.00 | +1.00 | +1.00 | +0.02 | – | +0.00 |
| 101 | Ekko | +0.78 | +1.00 | +1.00 | +1.00 | +0.01 | – | +0.00 |
| 102 | Darius | +0.78 | +1.00 | +1.00 | +1.00 | +0.01 | – | +0.00 |
| 103 | Evelynn | +0.78 | +1.00 | +1.00 | +1.00 | −0.00 | – | +0.00 |
| 104 | Wukong | +0.78 | +1.00 | +1.00 | +1.00 | −0.01 | – | +0.00 |
| 105 | Akali | +0.77 | +1.00 | +1.00 | +1.00 | −0.02 | – | +0.00 |
| 106 | Kha'Zix | +0.77 | +1.00 | +1.00 | +1.00 | −0.03 | – | +0.00 |
| 107 | Talon | +0.77 | +1.00 | +1.00 | +1.00 | −0.06 | – | +0.00 |
| 108 | Anivia | +0.50 | −0.01 | +1.00 | +1.00 | −0.05 | +0.60 | +0.00 |
| 109 | Malzahar | +0.24 | +0.04 | +0.51 | +1.00 | +0.03 | −1.00 | +0.00 |
| 110 | Karthus | −0.07 | −0.09 | −0.10 | −0.10 | +0.07 | −0.10 | +0.00 |
| 111 | Senna | −0.09 | +1.00 | −1.00 | −1.00 | +0.09 | +1.00 | +0.00 |
| 112 | Veigar | −0.28 | +0.08 | −0.80 | −0.70 | +0.01 | +0.34 | +0.00 |
| 113 | Vladimir | −0.30 | +1.00 | −1.00 | −1.00 | −0.02 | −1.00 | +0.00 |
| 114 | Zyra | −0.38 | +0.09 | −1.00 | −1.00 | +0.02 | +0.48 | +0.00 |

## Interaction ledger estimates

Every champion ranked by what its kit does against Katarina's, from the interaction ledger: projectile blocks, spell shields,
parries, dash stops, crowd control and its defenses, range and more (PLAN.md §5). This ranking is **partial**: it weighs the
interactions but doesn't play the fight out. The duel simulator replaces it as each champion's behavior is verified.

"For" sums the interactions in the champion's favor, "against" those in Katarina's; net = for − against.
A hard counter shuts down part of a kit every time it is used (projectile block, attack dodge, attack block, blind, disarm, attack speed slow, attack reflect, dash stop, grounding, range) with an impact of 0.4 or more (0.5 for range).
Run `npm run matchup -- <champion> Katarina` for the full ledger of a matchup, with sources.

### Top 10

#### 1. Rell (net +1.32)

- **0.28** interrupt: Ferromancy: Crash Down's airborne interrupts Katarina's Death Lotus (normal channel). Ferromancy: Crash Down must land during the channel. (Rell W Ferromancy: Crash Down → Katarina R Death Lotus)
- **0.28** interrupt: Ferromancy: Mount Up's airborne interrupts Katarina's Death Lotus (normal channel). Ferromancy: Mount Up must land during the channel. (Rell W Ferromancy: Mount Up → Katarina R Death Lotus)
- **0.28** interrupt: Full Tilt's stun interrupts Katarina's Death Lotus (normal channel). Full Tilt must land during the channel. (Rell E Full Tilt → Katarina R Death Lotus)

#### 2. Yasuo (net +1.26)

- **0.55** projectile block: Wind Wall blocks Katarina's Death Lotus, a projectile. Wind Wall for 4 s, long enough to use ahead of Death Lotus. (Yasuo W Wind Wall → Katarina R Death Lotus)
- **0.29** projectile block: Wind Wall blocks Katarina's Bouncing Blade, a projectile. Wind Wall for 4 s, long enough to use ahead of Bouncing Blade. (Yasuo W Wind Wall → Katarina Q Bouncing Blade)
- **0.28** interrupt: Last Breath's airborne interrupts Katarina's Death Lotus (normal channel). Last Breath must land during the channel. (Yasuo R Last Breath → Katarina R Death Lotus)

#### 3. Braum (net +1.22)

- **0.55** projectile block: Unbreakable blocks Katarina's Death Lotus, a projectile. Unbreakable for 4 s, long enough to use ahead of Death Lotus. (Braum E Unbreakable → Katarina R Death Lotus)
- **0.42** projectile block: Unbreakable blocks Katarina's Bouncing Blade, a projectile. Unbreakable for 4 s, long enough to use ahead of Bouncing Blade. (Braum E Unbreakable → Katarina Q Bouncing Blade)
- **0.28** interrupt: Concussive Blows's stun interrupts Katarina's Death Lotus (normal channel). Concussive Blows must land during the channel. (Braum I Concussive Blows → Katarina R Death Lotus)

#### 4. Lulu (net +1.00)

- **0.36** range: Lulu's basic attacks reach 425 units farther than Katarina's (550 vs 125 attack range). Katarina closes the gap with Shunpo. (Lulu basic attacks → Katarina basic attacks)
- **0.30** disarm: Whimsy disarms Katarina for 2 s: no basic attacks. Disarm for 2 s on a 18 s cooldown. (Lulu W Whimsy → Katarina basic attacks)
- **0.28** interrupt: Whimsy's polymorph interrupts Katarina's Death Lotus (normal channel). Whimsy must land during the channel. (Lulu W Whimsy → Katarina R Death Lotus)

#### 5. Taliyah (net +1.00)

- **0.28** interrupt: Seismic Shove's airborne interrupts Katarina's Death Lotus (normal channel). Seismic Shove must land during the channel. (Taliyah W Seismic Shove → Katarina R Death Lotus)
- **0.28** interrupt: Unraveled Earth's stun interrupts Katarina's Death Lotus (normal channel). Unraveled Earth must land during the channel. (Taliyah E Unraveled Earth → Katarina R Death Lotus)
- **0.27** range: Taliyah's basic attacks reach 400 units farther than Katarina's (525 vs 125 attack range). Katarina closes the gap with Shunpo. (Taliyah basic attacks → Katarina basic attacks)

#### 6. Gnar (net +0.89)

- **0.33** range: Gnar's basic attacks reach 386.765 units farther than Katarina's (511.765 vs 125 attack range). Katarina closes the gap with Shunpo. (Gnar basic attacks → Katarina basic attacks)
- **0.28** interrupt: GNAR!'s airborne interrupts Katarina's Death Lotus (normal channel). GNAR! must land during the channel. (Gnar R GNAR! → Katarina R Death Lotus)
- **0.28** interrupt: Wallop's stun interrupts Katarina's Death Lotus (normal channel). Wallop must land during the channel. (Gnar W Wallop → Katarina R Death Lotus)

#### 7. Rammus (net +0.88)

- **0.32** attack reflect: Defensive Ball Curl deals damage back to Katarina for each basic attack. Defensive Ball Curl lasts 7 s on a 7 s cooldown. (Rammus W Defensive Ball Curl → Katarina basic attacks)
- **0.28** interrupt: Frenzying Taunt's taunt interrupts Katarina's Death Lotus (normal channel). Frenzying Taunt must land during the channel. (Rammus E Frenzying Taunt → Katarina R Death Lotus)
- **0.28** interrupt: Powerball's airborne interrupts Katarina's Death Lotus (normal channel). Powerball must land during the channel. (Rammus Q Powerball → Katarina R Death Lotus)

#### 8. Xayah (net +0.85)

- **0.38** range: Xayah's basic attacks reach 400 units farther than Katarina's (525 vs 125 attack range). Katarina closes the gap with Shunpo. (Xayah basic attacks → Katarina basic attacks)
- **0.37** untargetable: Featherstorm makes Xayah untargetable, dodging Katarina's Death Lotus. Untargetable for 1.5 s, long enough to use ahead of Death Lotus. (Xayah R Featherstorm → Katarina R Death Lotus)
- **0.20** untargetable: Featherstorm makes Xayah untargetable, dodging Katarina's Bouncing Blade. Untargetable for 1.5 s, long enough to use ahead of Bouncing Blade. (Xayah R Featherstorm → Katarina Q Bouncing Blade)

#### 9. Blitzcrank (net +0.84)

- **0.28** interrupt: Power Fist's airborne interrupts Katarina's Death Lotus (normal channel). Power Fist must land during the channel. (Blitzcrank E Power Fist → Katarina R Death Lotus)
- **0.28** interrupt: Rocket Grab's airborne interrupts Katarina's Death Lotus (normal channel). Rocket Grab must land during the channel. (Blitzcrank Q Rocket Grab → Katarina R Death Lotus)
- **0.28** interrupt: Static Field's silence interrupts Katarina's Death Lotus (normal channel). Static Field must land during the channel. (Blitzcrank R Static Field → Katarina R Death Lotus)

#### 10. Renata Glasc (net +0.84)

- **0.38** range: Renata Glasc's basic attacks reach 425 units farther than Katarina's (550 vs 125 attack range). Katarina closes the gap with Shunpo. (Renata Glasc basic attacks → Katarina basic attacks)
- **0.28** interrupt: Handshake's airborne interrupts Katarina's Death Lotus (normal channel). Handshake must land during the channel. (Renata Glasc Q Handshake → Katarina R Death Lotus)
- **0.18** interrupt: Hostile Takeover's berserk interrupts Katarina's Death Lotus (normal channel). Hostile Takeover must land during the channel. (Renata Glasc R Hostile Takeover → Katarina R Death Lotus)

### Full ranking

| # | Champion | Net | For | Against | Hard counters |
|--:|---|--:|--:|--:|---|
| 1 | Rell | +1.32 | 1.32 | 0.00 |  |
| 2 | Yasuo | +1.26 | 1.26 | 0.00 | projectile block (Wind Wall) |
| 3 | Braum | +1.22 | 1.22 | 0.00 | projectile block (Unbreakable), projectile block (Unbreakable) |
| 4 | Lulu | +1.00 | 1.00 | 0.00 |  |
| 5 | Taliyah | +1.00 | 1.00 | 0.00 |  |
| 6 | Gnar | +0.89 | 0.89 | 0.00 |  |
| 7 | Rammus | +0.88 | 0.88 | 0.00 |  |
| 8 | Xayah | +0.85 | 0.85 | 0.00 |  |
| 9 | Blitzcrank | +0.84 | 0.84 | 0.00 |  |
| 10 | Renata Glasc | +0.84 | 0.84 | 0.00 |  |
| 11 | Anivia | +0.80 | 0.80 | 0.00 |  |
| 12 | Viktor | +0.80 | 0.80 | 0.00 |  |
| 13 | Fizz | +0.78 | 0.78 | 0.00 |  |
| 14 | Teemo | +0.77 | 0.77 | 0.00 | blind (Blinding Dart) |
| 15 | Heimerdinger | +0.76 | 0.76 | 0.00 |  |
| 16 | K'Sante | +0.76 | 0.76 | 0.00 |  |
| 17 | Sejuani | +0.75 | 0.75 | 0.00 |  |
| 18 | Thresh | +0.75 | 0.75 | 0.00 |  |
| 19 | Bard | +0.74 | 0.92 | 0.18 |  |
| 20 | Mel | +0.73 | 0.73 | 0.00 |  |
| 21 | Galio | +0.72 | 0.72 | 0.00 |  |
| 22 | Sivir | +0.71 | 0.89 | 0.18 |  |
| 23 | Twisted Fate | +0.71 | 0.71 | 0.00 |  |
| 24 | Vayne | +0.71 | 0.71 | 0.00 |  |
| 25 | Maokai | +0.70 | 0.82 | 0.12 |  |
| 26 | Malzahar | +0.69 | 0.69 | 0.00 |  |
| 27 | Aurelion Sol | +0.68 | 0.68 | 0.00 |  |
| 28 | Rek'Sai | +0.67 | 0.79 | 0.12 |  |
| 29 | Singed | +0.67 | 0.67 | 0.00 |  |
| 30 | Kayle | +0.66 | 0.66 | 0.00 |  |
| 31 | Quinn | +0.66 | 0.66 | 0.00 |  |
| 32 | Urgot | +0.65 | 0.65 | 0.00 |  |
| 33 | Nocturne | +0.64 | 0.76 | 0.12 |  |
| 34 | Draven | +0.64 | 0.64 | 0.00 |  |
| 35 | Zac | +0.63 | 0.75 | 0.12 |  |
| 36 | Jax | +0.63 | 0.63 | 0.00 |  |
| 37 | Shaco | +0.62 | 0.62 | 0.00 |  |
| 38 | Shen | +0.61 | 0.61 | 0.00 |  |
| 39 | Yuumi | +0.60 | 0.94 | 0.34 |  |
| 40 | Zoe | +0.60 | 0.60 | 0.00 |  |
| 41 | Cassiopeia | +0.58 | 0.80 | 0.22 |  |
| 42 | Fiddlesticks | +0.58 | 0.76 | 0.18 |  |
| 43 | Jayce | +0.58 | 0.58 | 0.00 |  |
| 44 | Kennen | +0.57 | 0.57 | 0.00 |  |
| 45 | Seraphine | +0.56 | 0.74 | 0.18 |  |
| 46 | Vel'Koz | +0.55 | 0.55 | 0.00 |  |
| 47 | Vex | +0.55 | 0.55 | 0.00 |  |
| 48 | Xerath | +0.55 | 0.55 | 0.00 |  |
| 49 | Ziggs | +0.55 | 0.55 | 0.00 |  |
| 50 | Tristana | +0.54 | 0.54 | 0.00 |  |
| 51 | Vladimir | +0.52 | 0.88 | 0.36 |  |
| 52 | Veigar | +0.52 | 0.52 | 0.00 |  |
| 53 | Hwei | +0.51 | 0.51 | 0.00 |  |
| 54 | Leona | +0.51 | 0.51 | 0.00 |  |
| 55 | Janna | +0.50 | 0.82 | 0.32 |  |
| 56 | Nami | +0.50 | 0.68 | 0.18 |  |
| 57 | Evelynn | +0.50 | 0.62 | 0.12 |  |
| 58 | Annie | +0.50 | 0.50 | 0.00 |  |
| 59 | Brand | +0.50 | 0.50 | 0.00 |  |
| 60 | Syndra | +0.50 | 0.50 | 0.00 |  |
| 61 | Aurora | +0.49 | 0.61 | 0.12 |  |
| 62 | Kalista | +0.49 | 0.49 | 0.00 |  |
| 63 | Camille | +0.48 | 0.66 | 0.18 |  |
| 64 | Yone | +0.48 | 0.48 | 0.00 |  |
| 65 | Kled | +0.47 | 0.59 | 0.12 |  |
| 66 | Orianna | +0.47 | 0.47 | 0.00 |  |
| 67 | Vi | +0.47 | 0.47 | 0.00 |  |
| 68 | Lissandra | +0.46 | 0.78 | 0.32 |  |
| 69 | Amumu | +0.46 | 0.46 | 0.00 |  |
| 70 | Azir | +0.46 | 0.46 | 0.00 |  |
| 71 | Ornn | +0.46 | 0.46 | 0.00 |  |
| 72 | Milio | +0.44 | 0.66 | 0.22 |  |
| 73 | Cho'Gath | +0.44 | 0.56 | 0.12 |  |
| 74 | Pyke | +0.44 | 0.56 | 0.12 |  |
| 75 | Riven | +0.44 | 0.56 | 0.12 |  |
| 76 | Twitch | +0.43 | 0.43 | 0.00 |  |
| 77 | Zyra | +0.43 | 0.43 | 0.00 |  |
| 78 | Rakan | +0.42 | 0.60 | 0.18 |  |
| 79 | Pantheon | +0.42 | 0.42 | 0.00 |  |
| 80 | Ashe | +0.41 | 0.59 | 0.18 |  |
| 81 | Sona | +0.41 | 0.59 | 0.18 |  |
| 82 | Neeko | +0.41 | 0.41 | 0.00 |  |
| 83 | Alistar | +0.40 | 0.56 | 0.16 |  |
| 84 | Samira | +0.39 | 0.77 | 0.38 |  |
| 85 | Sion | +0.39 | 0.51 | 0.12 |  |
| 86 | Malphite | +0.39 | 0.39 | 0.00 |  |
| 87 | Xin Zhao | +0.38 | 0.62 | 0.24 |  |
| 88 | Zilean | +0.38 | 0.60 | 0.22 |  |
| 89 | Ahri | +0.38 | 0.50 | 0.12 |  |
| 90 | Gragas | +0.38 | 0.50 | 0.12 |  |
| 91 | Kai'Sa | +0.38 | 0.38 | 0.00 |  |
| 92 | Tahm Kench | +0.37 | 0.76 | 0.39 |  |
| 93 | Sett | +0.36 | 0.48 | 0.12 |  |
| 94 | Caitlyn | +0.36 | 0.36 | 0.00 |  |
| 95 | Gwen | +0.35 | 0.47 | 0.12 |  |
| 96 | Nilah | +0.32 | 0.78 | 0.46 |  |
| 97 | Corki | +0.32 | 0.32 | 0.00 |  |
| 98 | Ezreal | +0.32 | 0.32 | 0.00 |  |
| 99 | Miss Fortune | +0.32 | 0.32 | 0.00 |  |
| 100 | Zed | +0.32 | 0.32 | 0.00 |  |
| 101 | Master Yi | +0.29 | 0.47 | 0.18 |  |
| 102 | Jinx | +0.29 | 0.29 | 0.00 |  |
| 103 | Lux | +0.29 | 0.29 | 0.00 |  |
| 104 | Elise | +0.28 | 0.60 | 0.32 |  |
| 105 | Kassadin | +0.28 | 0.28 | 0.00 |  |
| 106 | Jhin | +0.27 | 0.27 | 0.00 |  |
| 107 | Kog'Maw | +0.27 | 0.27 | 0.00 |  |
| 108 | Varus | +0.27 | 0.27 | 0.00 |  |
| 109 | Lucian | +0.24 | 0.36 | 0.12 |  |
| 110 | Ryze | +0.24 | 0.24 | 0.00 |  |
| 111 | Fiora | +0.22 | 0.50 | 0.28 |  |
| 112 | LeBlanc | +0.22 | 0.22 | 0.00 |  |
| 113 | Swain | +0.21 | 0.49 | 0.28 |  |
| 114 | Nasus | +0.21 | 0.33 | 0.12 |  |
| 115 | Viego | +0.20 | 0.57 | 0.37 |  |
| 116 | Zeri | +0.20 | 0.44 | 0.24 |  |
| 117 | Diana | +0.20 | 0.20 | 0.00 |  |
| 118 | Nautilus | +0.20 | 0.20 | 0.00 |  |
| 119 | Ivern | +0.19 | 0.19 | 0.00 |  |
| 120 | Jarvan IV | +0.19 | 0.19 | 0.00 |  |
| 121 | Karthus | +0.19 | 0.19 | 0.00 |  |
| 122 | Skarner | +0.19 | 0.19 | 0.00 |  |
| 123 | Yunara | +0.18 | 0.36 | 0.18 |  |
| 124 | Poppy | +0.18 | 0.18 | 0.00 |  |
| 125 | Lillia | +0.17 | 0.29 | 0.12 |  |
| 126 | Qiyana | +0.17 | 0.17 | 0.00 |  |
| 127 | Soraka | +0.16 | 0.55 | 0.39 |  |
| 128 | Kindred | +0.16 | 0.47 | 0.31 |  |
| 129 | Garen | +0.16 | 0.28 | 0.12 |  |
| 130 | Kayn | +0.14 | 0.62 | 0.48 |  |
| 131 | Nidalee | +0.12 | 0.30 | 0.18 |  |
| 132 | Graves | +0.12 | 0.24 | 0.12 |  |
| 133 | Darius | +0.10 | 0.28 | 0.18 |  |
| 134 | Nunu & Willump | +0.10 | 0.28 | 0.18 |  |
| 135 | Renekton | +0.10 | 0.28 | 0.18 |  |
| 136 | Shyvana | +0.10 | 0.28 | 0.18 |  |
| 137 | Taric | +0.10 | 0.28 | 0.18 |  |
| 138 | Udyr | +0.10 | 0.28 | 0.18 |  |
| 139 | Senna | +0.08 | 0.32 | 0.24 |  |
| 140 | Wukong | +0.07 | 0.19 | 0.12 |  |
| 141 | Morgana | +0.07 | 0.19 | 0.12 |  |
| 142 | Zaahen | +0.06 | 0.56 | 0.50 |  |
| 143 | Yorick | +0.06 | 0.28 | 0.22 |  |
| 144 | Mordekaiser | +0.05 | 0.36 | 0.31 |  |
| 145 | Lee Sin | +0.05 | 0.23 | 0.18 |  |
| 146 | Irelia | +0.01 | 0.33 | 0.32 |  |
| 147 | Aphelios | 0.00 | 0.38 | 0.38 |  |
| 148 | Hecarim | 0.00 | 0.18 | 0.18 |  |
| 149 | Akali | 0.00 | 0.00 | 0.00 |  |
| 150 | Gangplank | 0.00 | 0.00 | 0.00 |  |
| 151 | Rumble | 0.00 | 0.00 | 0.00 |  |
| 152 | Akshan | -0.01 | 0.34 | 0.35 |  |
| 153 | Smolder | -0.01 | 0.32 | 0.33 |  |
| 154 | Sylas | -0.04 | 0.28 | 0.32 |  |
| 155 | Trundle | -0.06 | 0.28 | 0.34 |  |
| 156 | Karma | -0.06 | 0.22 | 0.28 |  |
| 157 | Warwick | -0.12 | 0.50 | 0.62 |  |
| 158 | Illaoi | -0.12 | 0.00 | 0.12 |  |
| 159 | Aatrox | -0.18 | 0.28 | 0.46 |  |
| 160 | Kha'Zix | -0.18 | 0.00 | 0.18 |  |
| 161 | Locke | -0.18 | 0.00 | 0.18 |  |
| 162 | Olaf | -0.18 | 0.00 | 0.18 |  |
| 163 | Rengar | -0.18 | 0.00 | 0.18 |  |
| 164 | Tryndamere | -0.18 | 0.00 | 0.18 |  |
| 165 | Volibear | -0.21 | 0.28 | 0.49 |  |
| 166 | Talon | -0.32 | 0.00 | 0.32 |  |
| 167 | Dr. Mundo | -0.34 | 0.00 | 0.34 |  |
| 168 | Bel'Veth | -0.35 | 0.28 | 0.63 |  |
| 169 | Briar | -0.35 | 0.20 | 0.55 |  |
| 170 | Ambessa | -0.35 | 0.18 | 0.53 |  |
| 171 | Ekko | -0.36 | 0.00 | 0.36 |  |
| 172 | Naafiri | -0.41 | 0.00 | 0.41 |  |
