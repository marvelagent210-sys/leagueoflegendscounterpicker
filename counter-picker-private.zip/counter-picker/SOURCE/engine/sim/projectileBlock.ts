import type { Side, World } from "./state";
import { other } from "./state";

/** Projectile defenses on a traveled segment, including an explicitly instantaneous projectile. */
export function projectileBlocked(world: World, owner: Side, from: number, to: number): boolean {
  const targetSide = other(owner);
  for (const zone of world.zones) {
    if (zone.kind !== "projectileWall" || zone.owner !== targetSide || world.tick < zone.startTick || world.tick >= zone.endTick) continue;
    if ((from - zone.x) * (to - zone.x) <= 0) return true;
  }
  const target = world.units[targetSide];
  return target.statuses.some((status) => status.kind === "state" && status.key === "projectileBlock"
    && world.tick >= status.startTick && world.tick < status.endTick
    && Math.abs(target.x - to) <= target.spec.base.radius + status.value);
}
