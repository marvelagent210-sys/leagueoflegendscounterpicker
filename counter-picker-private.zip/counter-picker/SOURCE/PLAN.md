# Kit-Based Counter Picker: Plan

Status: M1 to M4 done; M5 built and waiting for your review of the golden matchups; M6 built. A private Codespaces preview starts the packaged app automatically. The tenth expansion batch adds Hecarim, Jarvan IV, Lee Sin, Wukong, Vi and Warwick, bringing validated coverage to 115 of 173 champions, with 58 remaining. All 6,555 pairs, 258 strict reflection directions and 17 browser check groups are validated. Private delivery packages the exact compiled model and working source. Data sources remain pinned to patch 26.20 (Data Dragon 16.20.1).

Accuracy audit on 2026-10-13: combat, crowd control, movement, budgets, source-backed
champion mechanics, result caches, and ranking consistency were corrected; all 1,176
supported duels and ledger rankings were refreshed. That snapshot's validation was 1,161 tests
passing, 2 active draft golden failures (Garen–Yasuo and Malphite–Yasuo),
and 5 existing skips. Type checks, production build, and all 12 production Chromium
checks pass; all 48 stale-fallback rankings match the current matrix. See
[ACCURACY.md](ACCURACY.md) for the evidence, remaining limits, and current validation;
the milestone reports below retain their historical numbers.

## All-champion expansion

The first batch added Amumu, Annie, Ashe, Brand, Leona, Lux, Master Yi, Morgana,
Nautilus, Rammus, Vayne, and Xin Zhao. That 61-kit snapshot covered 1,830 unordered
pairings and left 112 champions to implement.

The second batch implements Ahri, Cassiopeia, Kassadin, Lissandra, Veigar, and
Vladimir. That snapshot covered 67 of 173 champions, with 2,211
unordered pairings and 106 champions remaining. Its pairings were freshly
rebuilt under fingerprint `cc2d3696…`. Both TypeScript projects, the production build,
583 focused checks, 132 side-swap searches and all 16 browser checks pass. The full
suite has 1,887 passing tests, the two original draft winner failures, and five existing
skips across 89 files. All 66 live fallback scores match the matrix within 2.45e-15.
The private package is identified by `cc2d3696`. The generated
[coverage report](data/16.20/reports/coverage.md)
lists the complete queue and each implemented kit's source-read and assumption counts.

The third batch implements Anivia, Karthus, Malzahar, Vel'Koz, Ziggs and Zyra.
Coverage is 73 of 173 champions, with 100 remaining. All 2,628 unordered
pairs have been refreshed under fingerprint `393ffdb2…`. Its 351 champion regressions, shared kit contracts,
both TypeScript projects and 144 full-variant Darius reflection checks pass.
The final full suite has 2,335 passing tests, the two original draft winner
failures and five existing skips. All 17 production browser checks pass, and all
72 live fallback scores match the matrix within 2.46e-15. Full validation and
remaining limits are recorded in [ACCURACY.md](ACCURACY.md).

The fourth batch implements Caitlyn, Ezreal, Jhin, Jinx, Lucian and Miss Fortune.
Coverage is 79 of 173 champions, with 94 remaining and 3,081 unordered pairings.
All 3,081 pairs are freshly rebuilt under fingerprint `bc04dfd2…`. Pinned source
conflicts and explicit one-dimensional/expected-value assumptions stay with each kit.
The full serial suite has 2,684 passing tests, two original draft winner failures
and five existing skips; types, freshness and production build pass. All 17 production
browser checks pass, including 78 complete live fallback rankings and six new source
pages at phone width. Private delivery packages the frozen model and source snapshot;
evidence is in [ACCURACY.md](ACCURACY.md).

The fifth batch implements Corki, Draven, Kog'Maw, Sivir, Tristana and Twitch.
Implemented coverage is 85 of 173 champions, leaving 88 and requiring 3,570 unordered
pairings. The full matrix was freshly regenerated and passes freshness, type and
production-build checks. The final serial suite has 3,026 passing tests, the two
original draft winner failures and five existing skips. All 17 browser checks pass,
including 84 complete live fallback rankings and six source pages at phone width.
Private packaging verifies the exact compiled/source snapshot and startup helper
before publishing a new preview branch; the previous package remains preserved.
Shared contracts cover moving post-death phases, persistent aftermath, separately
ordered basic packets, piercing basic skillshots, spell-shield consumption and actual
pet contacts. Pinned source gaps remain explicit in the three new pair audits.

The sixth batch implements Kai'Sa, Kalista, Samira, Smolder, Varus and Xayah.
Implemented coverage is 91 of 173 champions, leaving 82. All 4,095 unordered
pairings were freshly regenerated and pass provenance, type and production-build
checks. The final serial suite records 3,397 passes, the two original draft winner
failures and five existing skips. Actual production searches pass strict side
reflection for all 90 Darius rivals and all 15 new-champion pairings. All 17 browser
checks pass, including seven source pages at phone width and all 90 live fallback
rankings. Long formulas now wrap within phone width. Private delivery requires
exact archive/source integrity and five startup checks before publication to a new
preview branch. Shared work covers pre-physical passives, visible fixed-time
missiles, projectile interception, independent dash/channel clocks, terrain flight,
sourced summoned-unit classes, lethal-pet attribution and committed post-death
basic missiles. Source conflicts remain explicit in the three new pair audits.

The seventh batch registers Akshan, Aphelios, Graves, Kindred, Senna and Zeri.
Coverage is 97 of 173 champions, leaving 76 and requiring 4,656 unordered pairings.
Pinned sources include 41 primary ability templates and seven versioned binary files,
including Kindred's Wolf companion. Its source, combat, reflection and full-matrix validation
are complete, and its exact model and source form the seventh private delivery. Shared work covers anchored smoke
vision, camouflage, selective silence exceptions, actual alternative-attack pet contacts,
committed pet projectiles and spatial health floors with separate healing and cost rules.

The eighth batch implements Diana, Ekko, Evelynn, Fizz, Katarina and LeBlanc.
Coverage is 103 of 173 champions, leaving 70. All 5,253 unordered pairs were freshly
computed under fingerprint `50faa123…` with four workers in 7,155.1 seconds. The
source audit validates 33 exact primary revisions, six versioned binary files,
24 objects and 33 exact excerpts. All 676 focused tests, both TypeScript projects,
provenance freshness and production build pass. The final serial suite records
4,283 passes, the two retained draft winner failures and five existing skips.
Strict production searches pass 204 Darius directions and 30 directions among the
new champions, with exact spending and options. All 17 browser groups pass, including
102 complete live fallback rankings and seven source pages at phone width. Shared
work covers selective spell defenses, actual clone/pet classes, cosmetic clone
attacks, pet attack resolution, precise projectile destruction, channel cancellation
windows, live dash tracking and completion-time target validation. Co-location
geometry and ordinary scenario mode rules have dedicated regressions. The private
compiled/source package must pass archive, startup and preservation verification
before publication. Remaining source and geometry limits stay in each audit.

The ninth batch implements Kha'Zix, Naafiri, Nocturne, Rengar, Talon and Zed.
Coverage is 109 of 173 champions, leaving 64. All 5,886 unordered pairs were
freshly computed under fingerprint `d2cb2f6a…` with four production workers,
starting without checkpoints. After an interruption, 854 verified results were
retained under that same fingerprint and the remaining 5,032 pairs were computed.
No checkpoint was imported from another model. The source audit validates 36 exact primary revisions,
six versioned binary files, 37 objects and 115 exact excerpts; all 36 full raw
wiki revisions remain in the authored records. All 1,147 focused tests pass.
The final serial suite records 4,686 passes, the two retained draft winner
failures and five existing skips. Both TypeScript projects, provenance freshness,
production build, 216 Darius reflection directions, 30 new-champion directions and
17 browser groups pass. Kha'Zix has four legal three-evolution variants. Shared work
covers multiplicative total movement speed, explicit death-persistent effects and
pets, independent cast/dash clocks, instant overlays and declaration-timed lines.
The private compiled/source package must pass archive, startup and preservation
verification before publication. Each champion audit retains its source conflicts
and model limits.

The tenth batch implements Hecarim, Jarvan IV, Lee Sin, Wukong, Vi and Warwick.
Coverage is 115 of 173 champions, leaving 58. All 6,555 unordered pairs were
freshly computed under fingerprint `d9b033ae…` with four production workers,
starting with zero checkpoints. Every saved worker index matches that fresh
invocation's canonical dispatch, and no checkpoint was imported from another model.
The source audit verifies 34 primary revisions (33 ability templates and Wukong's
pet article), six exact versioned binaries, 56 distinct game objects across
59 source records and 185 exact excerpts. All full raw revisions are retained.
All 891 focused tests pass. The final unfiltered serial suite records 5,097
passes, the two retained draft winner failures and five existing skips. Both
TypeScript projects, final provenance freshness, the production build, 228 Darius
reflection directions, 30 new-champion directions and 17 browser groups pass.
Shared changes observe resolved damage with actual source/target identities,
preserving damage-based healing before Riposte's late damage negation while
keeping actual health loss and shield absorption separate for damage triggers. They
apply typed shields to real pets, respect explicitly sourced pet state immunity
and preserve exact ability-stage identity for pet crowd control. Wukong's clone
has independent combat state and copied attacks. Missing finite movement timings,
terrain projections and unsupported preduel history remain explicit in each audit.
The private compiled/source package must pass archive, five actual startup checks
and preservation of all ten previous previews before publication.

Each batch must read pinned source values, check meaningful damage/timing/counterplay
cases, exercise ordinary behavior, regenerate all affected duels, and pass type/build
checks before updating the private preview. Unresolved source conflicts and model
limitations stay visible in the kit pages. Golden draft winners and margins are not
tuning targets.

Source audits for twelve casters were recorded in
[docs/next-wave](docs/next-wave/README.md): Ahri, Anivia, Cassiopeia, Karthus,
Kassadin, Lissandra, Malzahar, Veigar, Vel'Koz, Vladimir, Ziggs, and Zyra. These
audits cover pinned formulas, counterplay, tests, and required shared-engine work;
the second and third batches now implement all twelve. Their resurrection,
post-death spellcasting, channel, beam, mine and plant mechanics are covered by
the corresponding batch regressions. The fourth batch adds separate source audits
for Caitlyn/Jhin, Ezreal/Lucian and Jinx/Miss Fortune.

### First expansion validation (61-kit snapshot)

Production browser validation exposed two reflected-geometry boundaries affecting
Lux–Darius and Xin Zhao–Darius. Projectile forecasts and Darius's Decimate positioning
are corrected, with ten regression checks. All 1,830 unordered duels are rebuilt and
pass the final provenance check. Both TypeScript projects, 258 focused mechanics
checks and ten reflection regressions pass. The full suite has 1,435 passing tests,
the same two active draft golden failures, and five existing skips across 78 files.
The production build and all 13 browser checks pass. All 60 live stale-matrix
recovery scores against Darius agree with the matrix within 2.6e-15, and the phone
layout has no page overflow. Existing timeout limits and fixture expectations are
unchanged. Evidence for that snapshot and current batch validation is recorded in
[ACCURACY.md](ACCURACY.md).

The seventh batch implements Akshan, Aphelios, Graves, Kindred, Senna and Zeri.
All 4,656 unordered pairs were freshly generated under fingerprint `f5ee5ef4…`.
The final serial suite has 3,877 passes, the two retained draft winner failures and
five existing skips. All 539 focused tests, types, freshness and production build
pass. Strict production reflection covers 192 Darius directions and 30 directions
among the new champions. All 17 browser groups pass, including 96 complete live
fallback rankings and seven source pages at phone width. The private compiled/source
package requires exact integrity checks and five startup checks before publication.
Evidence and remaining modeling limits are recorded in [ACCURACY.md](ACCURACY.md).

## 1. What we're building

A static web app for top lane. You pick the enemy champion, and it ranks every champion in the game by how well its **kit** beats the enemy's kit in a **1v1 at level 20**. Every result explains itself down to individual ability interactions.

### Ground rules (decided)

| Rule | Detail |
|---|---|
| Kits only | No win rates, matchup statistics, tier lists or meta. No runes or summoner spells, with one exception: Udyr's Triple Tonic (§4.1). Correctness is checked with hand-written tests (§8), not statistics. |
| Level 20 | Completing the Top Lane Role Quest raises the level cap from 18 to 20, so both champions are level 20. Base stats keep growing through level 20. Effects that scale with champion level use the game's own formulas, which say whether they keep growing past 18 or cap there. Skill points work differently for Udyr (§4.1). |
| Pure 1v1 | No draft, teammates, jungler or lane phases, and no early-game power spikes. |
| Any champion | You can play every champion, so all 173 are candidates. The enemy can also be any champion; champions the client tags as top lane are listed first. |
| Static web app | No backend, accounts or API keys. |
| Stat budget | Both champions get the same amount of gold, as plain stats only (§10). |

## 2. How a counter is decided

Champion B counters champion A when B's kit wins the 1v1 situations that decide top lane:
- all-ins, whoever starts them;
- short trades;
- the spacing game, meaning who controls when a fight happens.

Two engines work together:

1. **Interaction ledger.** Lists every ability-vs-ability interaction between the two kits, built from per-ability data flags and the wiki's interaction notes. Examples: "Poppy W stops Riven's Q dashes"; "Yasuo W can't block Darius E (not a projectile)"; "Teemo's blind doesn't make Gangplank's Q miss".
2. **Duel simulator.** Plays the fights out with exact level-20 numbers: windups, missile speeds, cooldowns, crowd control (CC) durations, shields, heals and resource costs. For each scenario it returns win probability, HP left and time-to-kill, plus a timeline.

The simulator decides the score. The ledger explains it and flags hard counters. Until a champion's simulator behavior is verified, its matchups fall back to a ledger-only estimate marked **partial**.

## 3. Data sources (checked 2026-10-08)

| Source | What we use | Notes |
|---|---|---|
| LoL Wiki `Module:ChampionData/data` | Base stats and growth; attack windup parameters (`as_ratio`, `windup_modifier`, `attack_delay_offset`); pathing and selection radius; client positions | Current. Each entry records its last-changed patch (up to V26.20). |
| LoL Wiki glossary pages ("Dash", "Untargetability", "Spell shield", "Projectile", "Channel", "Types of Crowd Control/Sources" and /Summary, ...) | Which abilities dash, blink or lunge; which grant untargetability, invulnerability, stasis, spell shields or projectile blocking; every source of each crowd control type; channels and charge-ups; the crowd control rules table (what each type disables, tenacity, interrupts, which abilities cleanse it) | Maintained by the wiki's editors, so new or reworked abilities are picked up with the pages. 35 pages, pinned by revision. |
| LoL Wiki ability data, `Template:Data <Champion>/<Ability>` | Values per rank and ratios; cooldown, cost, range, width, missile speed, cast time; flags `targeting`, `projectile`, `spellshield`, `parry`, `grounded`, `knockdown`; **notes** with edge-case interactions | 2,251 pages covering every form and variant (Mini and Mega Gnar, Hwei's 10 spells, Aphelios's weapons, Udyr's awakened stances, and so on). Fetched through the MediaWiki API at 50 pages per request and pinned by revision ID. |
| CommunityDragon game files (16.20) | Authoritative numbers and formulas: base stats, spell calculations (including the level-scaling formulas that decide behavior past level 18), cast times, windup cancel rules, missile data, collision radius | Cross-checks the wiki. A value they state for a champion's base form replaces the wiki's, and each replacement is logged in `reports/game-files.md`. |
| Data Dragon 16.20.1 | Champion roster, ability ranks, icons | Not used for stats: 16.20 reports 0 attack damage per level for every champion. Tooltip text isn't used because it's partly unfilled placeholders. |
| Wiki page "List of champions/Statistics at level 20" | Test oracle for our level-20 stat math | |
| Meraki Analytics | Not used | Stale since about mid-2025 and missing Zaahen and Locke. |

The pipeline runs these stages:
1. `fetch`: cache raw files per patch.
2. `parse`: turn wiki markup into JSON.
3. `normalize`: map everything to one schema.
4. `crosscheck`: compare wiki values with game files and report mismatches.

The result goes into `data/<patch>/`, committed to the repo along with a per-patch diff report.

## 4. Kit model

### 4.1 Champion at level 20

- **Stats.** A stat at level *n* = base + growth × (*n* − 1) × (0.7025 + 0.0175 × (*n* − 1)). At level 20 that is 19.665 × growth, compared with 17 × growth at level 18.
- **Attack speed and windup.** Attack speed growth is bonus attack speed, scaled by the champion's attack-speed ratio. Attack windup comes from the windup parameters.
- **Other basics.** Collision radius (which affects skillshot hit chance), movement speed, health and resource regeneration, and resource pool.
- **Ability ranks and skill points.** A champion gains one skill point per level.
  - **Everyone except Udyr** has every ability fully ranked once 18 points are spent. A few start with one ability already learned (the R of Elise, Jayce, Karma and Nidalee; Yuumi's W), and Aphelios spends his points on bonus stats instead of abilities. For all of them, levels 19 and 20 add stats only.
  - **Udyr** has no ultimate and four abilities with 6 ranks each (24 ranks). He's the only champion whose skill points continue past 18: he gets points at levels 19 and 20, for 20 in total. Triple Tonic's Elixir of Skill adds a 21st point if he drinks it before level 18.
  - Even with 21 points, 3 of Udyr's ranks stay empty, so his rank split is a real choice. The engine tries every valid split in each matchup and uses the best one, and you can pin a split instead.
  - Triple Tonic is a rune, so it's the one exception to "no runes". It's a setting that's on by default for Udyr. When it's on, the rune's other two elixirs (Force and Avarice) also apply, with the effects the wiki gives them.
  - Several of Udyr's Awaken bonuses keep scaling with champion level through level 20. For example, the bonus attack speed from Wilding Claw's Awaken goes from 70% at level 18 to about 75.9% at level 20.
- **Forms and states.** Mini/Mega Gnar, Kayle's evolutions, Nidalee/Jayce/Elise forms, Udyr's stances and awakenings, Shyvana's dragon form, and others.
- **Stack assumptions.** Some kits grow with game time: Nasus Q, Sion W health, Cho'Gath R, Smolder Q, Gangplank's ultimate upgrades and others. The default is "typical by the time a top laner reaches level 20", adjustable per champion.

### 4.2 Ability record

There is one record per ability per form:

- **Numbers at max rank.** Each effect is a base value plus ratios: AD, bonus AD, AP, max or bonus HP, armor, magic resist (MR), attack speed, and the target's max, current or missing HP.
- **Timing.** Cooldown; cast time and whether attack speed shortens it; channel or charge time; recast windows; charges and recharge; lockouts.
- **Geometry.** Range (measured from center or edge), width or radius, missile speed, dash speed and distance.
- **Delivery flags:**
  - targeting type;
  - projectile (can be intercepted);
  - blocked by spell shields;
  - how parries, dodges and blinds treat it;
  - usable while grounded or knocked down;
  - needs a unit, wall or brush.
- **Effects** (typed):
  - **Offense:** damage, empowered attack, auto-attack reset, on-hit, execute threshold, anti-heal.
  - **Control:** each CC type with its duration.
  - **Movement:** dash and blink.
  - **Defense:** shield, heal, damage reduction, untargetable, invulnerable, stasis, CC immunity, unstoppable, cleanse, tenacity, death prevention, revive.
  - **Vision:** stealth, camouflage, reveal.
  - **Other:** stat buff or steal, summons, terrain or zones, transformation, resource gain and spend.
- **Exceptions from the wiki notes.** For example: "Blinding Dart does not make on-hit abilities (Parrrley, Mystic Shot) miss."
- **Evidence.** Every value and effect links back to the wiki revision or game file it came from.

### 4.3 Global game rules

These are encoded once and unit-tested:
- **Damage:** armor and MR multipliers including negative values; the order of reduction and penetration.
- **Defense:** shield order; healing modifiers.
- **Crits.**
- **CC rules:** CC categories, what tenacity reduces, what can be cleansed.
- **Movement:** slow stacking (only the strongest slow applies); movement-speed soft caps; what interrupts a dash.
- **Attacks and casting:** attack timer, windup and cancel rules, spell buffering.
- **Range:** edge-to-edge versus center measurement.
- **Timing:** the server's 30 ticks per second.

### 4.4 Behaviors

Each champion has a behavior that tells the simulator how to play the kit:
- an **all-in** rotation;
- a **short-trade** pattern;
- a **spacing** preference;
- **reactions** to enemy casts.

A default behavior is generated from the ability data: close the gap when out of range, lead with CC, use damage on cooldown, and use defensive tools in response to big threats. Unusual kits get small hand-written TypeScript modules on top. Examples:
- Sylas R steals the enemy's ultimate, so in a 1v1 he gets *your* ultimate.
- Mordekaiser R steals stats.
- Gnar has a rage cycle.
- Riven has animation cancels and a Q chain.
- Fiora's vitals depend on positioning.
- Yasuo R needs an airborne target.
- Illaoi has tentacles; Yorick has ghouls and the Maiden; Heimerdinger has turrets; Gangplank has barrels.
- Sion, Zac and Anivia have revive passives.
- Hwei, Aphelios and Viego have unique kits.

## 5. Interaction ledger

For every ordered pair (your ability, enemy ability), including basic attacks and passives, the ledger runs these checks. What each ability does (dashes, untargetability, the crowd control it applies, ...) comes from the wiki's glossary lists, joined with the ability's own interaction flags and description (§13, M3).

| Check | Examples and edge cases |
|---|---|
| Projectile interception | Yasuo W, Samira W and Braum E against abilities flagged as projectiles. Yasuo's Q3 whirlwind is a missile and can be intercepted. |
| Spell shields | Sivir E and Nocturne W against abilities flagged as spell-shieldable. Partial cases too: a spell shield removes only the silence from Garen Q. |
| Parries and dodges | Fiora W, Jax E and Shen W against attacks and abilities. Riposte stuns back only if Riposte itself negates an immobilizing effect. Lifesteal from a parried hit still heals the attacker. |
| Anti-dash | Poppy W against dashes. It doesn't stop dashes by CC-immune, displacement-immune, untargetable or spell-shielded units, such as Malphite R, Volibear R or Zed R. |
| Grounding | Cassiopeia W and Singed W against movement abilities. |
| Blind, disarm, attack-speed slow | Against basic attacks and attack-based abilities, with the listed exceptions. |
| Untargetable, invulnerable, stasis | Against targeted abilities, when the ability's cast time leaves enough time to react. |
| CC immunity, cleanse, tenacity | Against each CC effect. |
| Interrupts | Hard CC against channels and charge-ups. |
| Death prevention | Against executes. |
| Damage reflection | Against attackers. |
| Reveal; anti-heal | Reveal against stealth; anti-heal against healing. |
| Range | Range measured from center or from edge. Teemo's Q out-ranges his own basic attack by 45–70 units against champions. |

Each entry stores the direction, severity, timing condition and evidence.

## 6. Duel simulator

### Model

- **One dimension.** The simulator tracks the distance between the two champions. 2D effects such as side-stepping, cones and facing enter through the hit model.
- **Event timing.** Events are quantized to the server's 30 ticks per second. Tracked state includes:
  - attack timers, windups and cancels;
  - cast times and missiles in flight;
  - CC, buffs and debuffs;
  - shields and heals;
  - cooldowns, resources, stacks and forms.
- **Skillshot hit model.** Compares two times:
  - the time until impact (cast time plus travel);
  - the time the target needs to leave the hit area, based on movement speed and collision radius, plus reaction time (default 0.25 s) and any dash available.
- **Probabilities.** The simulator branches on the few skillshots that decide a fight (hit or miss) and averages the minor ones. That gives exact win probabilities and is fast enough to precompute every pairing at build time.
- **Skill level.** Both sides play perfectly within human reaction time, including reactions such as:
  - Fiora W into a telegraphed stun;
  - Jax E as attacks come in;
  - Yasuo W into projectiles;
  - untargetable abilities saved for executes.

### Scenarios

Every scenario starts at level 20 with full HP and resource and everything off cooldown.

1. **You engage:** all-in from your best engage range.
2. **The enemy engages.**
3. **Brawl:** fight from melee range.
4. **Short trade:** your best trade, then disengage. The result is the net HP exchanged.
5. **Spacing:** can the longer-ranged or faster side keep its distance and win, or can the other side force contact?
6. **Escape:** can whoever loses the all-in get away?

### Environment toggles (defaults in brackets)

- Minion wave present [on]: dash targets for Yasuo and Irelia; graves for Yorick.
- Walls nearby [on]: Camille E; Poppy and Vayne wall stuns; Illaoi tentacles.
- Brush nearby [on]: Rengar.
- Lane setup [on]: Heimerdinger turrets and Teemo mushrooms placed in advance.

## 7. Scoring and output

- **Counter score.** A weighted blend of the scenario results; the weights live in one config file.
- **Hard-counter badges.** Taken from the ledger.
- **Result basis.** "Simulated" when both kits are simulated, "Interaction estimate" when the result uses the ledger. These labels describe coverage, rather than certifying accuracy.

### Pages

1. **Enemy picker.** A ranked list of all champions with score bars and the top three reasons for each.
2. **Matchup page.** Verdict, scenario results, key interactions, fight timelines, side-by-side level-20 numbers, and the assumptions used.
3. **Kit page.** Everything the engine knows about one champion, with evidence links, so you can audit it.
4. **Settings.** Stat budget, environment toggles, reaction time, stack assumptions, scenario weights, and Udyr's Triple Tonic and rank split.

Every pairing (173 × 172) is precomputed for the default settings at build time. When you change settings, the selected enemy's list is recomputed in a background Web Worker.

## 8. Validation without statistics

1. **Math tests.** Level-20 stats against the wiki's level-20 table; damage, penetration, tenacity and slow stacking; skill points (every champion fully ranked at 18; Udyr at 20 points, or 21 with Triple Tonic).
2. **Interaction tests.** For example:
   - Yasuo W blocks the Q3 whirlwind but not Darius E.
   - Poppy W doesn't stop Malphite R.
   - Teemo's blind doesn't make Gangplank Q miss.
   - Riposte stuns back only under the right conditions.
3. **Golden matchups.** About 60 kit-driven top-lane matchups, written together with you as the domain expert. Each states the expected winner and a rough margin. Draft examples to confirm:
   - Poppy beats Riven, Irelia and Yasuo (W stops their dashes).
   - Teemo beats Tryndamere (blind).
   - Jax beats Tryndamere (E dodges his attacks).

   A failing test blocks a release.
4. **Kit audits.** You skim the kit pages for anything wrong, and each correction becomes a test.

## 9. Build order

| # | Milestone | Done when |
|---|---|---|
| M1 | Data pipeline and level-20 stat math | All 173 champions are fetched and parsed, and their stats match the wiki's level-20 table. |
| M2 | Ability records for every champion, plus kit pages | Every ability is parsed with numbers, flags and evidence, and mismatches with the game files are listed. |
| M3 | Interaction ledger and interaction tests | The ledger works for any pair, and the first usable ranking exists (ledger-only, marked "partial"). |
| M4 | Simulator core and global rules | Generic mechanics pass unit tests on synthetic kits. |
| M5 | Behavior wave 1 (about 25 top laners you choose, e.g. the ones you face most) and golden matchups | Golden tests pass and you've reviewed the results. |
| M6 | Web app on GitHub Pages | Picker, matchup page, kit page and settings are live. |
| M7 | Behavior waves 2 and 3 | All remaining top-lane champions, then all 173, are simulated. |
| M8 | Patch automation | A scheduled job refetches the data, rebuilds, runs the tests, and opens a PR with a diff report. |

## 10. Stat budget at level 20 (decided)

With zero items, ability ratios (AP, bonus AD, bonus HP) would add nothing at level 20, and a large part of many kits would never be measured. So both champions get the **same gold budget, spent on plain stats only**, with no item passives or actives:
- The gold is allocated according to each champion's own ratios.
- Defensive stats are split against the opponent's damage type.
- Stats are priced at their base gold values from the wiki.
- Penetration is capped near what a full build's items give: 40 lethality, 35% armor penetration, 20 flat and 40% magic penetration. Uncapped, penetration at gold value cost less than the armor it cancels, both sides bought up to 138 lethality (more than any item build reaches), and armor stopped mattering (decided in M5).

A slider runs from 0 gold (pure kit) up to a full build. The default is 15,000 gold, about what a top laner has when the role quest takes it to level 20 (set in M4; see §13).

## 11. Tech and layout

The whole project is TypeScript: Node scripts for the pipeline, Vitest for tests, Vite + React for the UI, and GitHub Pages deployed through GitHub Actions.

```
pipeline/   fetch, parse, normalize, crosscheck
data/       generated kit data per patch (committed)
engine/     game rules, interaction ledger, duel simulator, scoring
kits/       per-champion behaviors and overrides (each override quotes the wiki text it rests on)
tests/      math, interaction and golden-matchup tests
web/        the app
```

## 12. Risks

- **Behavior work is the bulk of the project.** There are 173 champions and 2,251 ability pages including variants. It's done in waves, and the ledger-only fallback keeps the app useful in the meantime.
- **Wiki errors or lag after a patch.** Mitigated by cross-checking against the game files and pinning revisions.
- **The 1D simplification.** Side-stepping, cones and facing are approximated by the hit model.
- **Assumptions shape the results.** Reaction time, environment, stacks and behaviors are all explicit, adjustable and shown on every matchup page.
- **Legal.** The app needs Riot's fan-project disclaimer and attribution under the wiki's license.

## 13. Progress

### M1: data pipeline and level-20 stat math (done)

- `npm run fetch` downloads every source for the current patch. That's 173 champions, 174 game data files and 2,436 wiki data pages, of which 1,206 are redirects. Exact versions and wiki revisions are recorded per patch.
- `npm run build:data` writes `data/16.20/`. The engine computes base stats at any level up to 20, including attack speed and windup. Every one of the 175 champion forms matches the wiki's level-20 table, which serves as the test oracle. The one exception is documented: the table shows Jhin's attack speed growing, but his attack speed ratio is 0, so in game it doesn't.
- Skill points are modeled: everyone is fully ranked at 18; Udyr has 20 points at level 20, or 21 with Triple Tonic, and his rank splits are listed.
- Findings:
  - Data Dragon 16.20.1 reports 0 AD per level for every champion. The game files confirm the real values (for example, Darius gains 5 AD per level).
  - The game files replaced 16 wiki values:
    - Vi's AD per level: 3.5 → 3.9;
    - Singed's and Vayne's attack-speed ratios;
    - Locke's selection radius;
    - 12 attack windup values for 11 champions that the wiki hadn't updated.
  - Differences for Mega Gnar and Kled's two forms are reported but not applied.
  - Senna's attack cast time scales with level and stops at 18. This is the game's flag (`mScalePastDefaultMaxLevel`) that decides what keeps growing at levels 19 and 20. M2 reads the same flag for abilities.

### M2: ability records and kit pages (done)

- The wiki's ability pages are parsed with a small wikitext engine. Its value templates (`{{ap}}`, `{{pp}}`, `{{pplevel}}`) are ported from the wiki's own Lua module, so ranks and level progressions come out exactly as the wiki computes them.
- `data/16.20/abilities/` holds 1,057 ability records for all 173 champions:
  - every innate, Q, W, E and R, plus 10 basic-attack pages;
  - cooldowns, costs, ranges, widths, speeds and cast times;
  - the interaction flags: projectile, spell shield, parry, grounded, knocked down;
  - values by rank and by level with their scaling ratios. 99.7% of 1,973 leveling values are fully understood; the 5 exceptions are one-off formulas such as Syndra's AP².
  - crowd control and other mechanics with their durations, and the wiki's notes verbatim.
- `data/16.20/kits/` has a readable page per champion, with every value linked to the exact wiki revision.
- Level 19-20 findings:
  - The game files write the "scale past level 18" flag only when it is false. A level formula without it keeps scaling at 19 and 20.
  - Of the level-based values the wiki defines up to level 20, all 144 that link to a game formula agree with it, with no disagreements.
  - 15 values that stop at 18 on the wiki were extended to level 20 from the game formulas.
  - 94 level-based values have no matching game formula. Their levels 19-20 are marked unknown and get checked per champion in M5.
- 39 of 1,188 ability cooldowns and costs differ between the wiki and the game files, for example Mordekaiser's R and Camille's W cooldowns. They are listed in `reports/abilities.md` but not applied, because an ability's root spell in the game files isn't always the one whose values apply. They are resolved per champion in M5.
- Limitation: mechanics are read from the wiki's keywords. For example, Poppy's W lists "dash" because enemies dash into it. M3 gives each ability's mechanics their exact roles (applies, triggers on, blocks).

### M3: interaction ledger and ledger-only ranking (done)

- **Removed abilities.** The wiki keeps the data pages of abilities that were reworked away, and M2 had read 110 of them as current (for example Kayle's old ultimate and Dr. Mundo's pre-2021 kit). A page now counts as current only when a slot redirect (`Template:Data Corki/W`) or the champion's skill list in Module:ChampionData points to it, which leaves 947 records; the rest are listed in `reports/abilities.md`.
- **Glossary.** What each ability does comes from the wiki's own classification pages: every dash (by targeting), blink and lunge; untargetability, vanish, stasis, invulnerability, spell shields and projectile blockers; channels and charge-ups; stealth and true sight; Grievous Wounds and tenacity; and every source of each crowd control type. That's 1,005 entries from 35 pages, all but one resolved to a current ability. The crowd control rules table (what each type disables, whether tenacity shortens it, whether it interrupts channels, which abilities cleanse it) is parsed as well.
- **Fight profiles** (`profiles/<champion>.json`), one per ability:
  - delivery: the wiki's flags (projectile, spell shield, parry, grounded, knockdown, disruptable) and whether it's an empowered attack, an on-hit spell or a change to every basic attack;
  - the crowd control it applies to the enemy, with duration and conditions ("If Riposte negates ... Fiora stuns the target"), leaving out effects the lists give only against non-champions (Darius's R fears minions, not champions);
  - movement, and whether knockdowns can interrupt it (Malphite's R can't be stopped);
  - the states it gives its caster. A state counts only when the sentence gives it to the caster: Kalista's R protects her Oathsworn and Tahm Kench's R the unit he devours, so neither counts for them.
  - basic attacks at level 20 per form, including Jayce's cannon, Kayle's 625 range from level 16 and Tristana's 700.
- **Curated data** lives in `kits/`: 2 profile overrides (Riposte's parry and Rammus's W returning damage to attackers, both written as prose on the wiki) and 5 attack forms. Each quotes the wiki text it rests on, and the build fails if that text disappears.
- **Ledger** (`engine/ledger/`): 18 checks covering every row of §5. Each entry has the side it favors, the two abilities, a one-line summary, timing (reaction windows from cast time and missile travel, uptime from duration and cooldown), the wiki's conditions and notes, an impact from 0 to 1, and its sources with revision IDs.
  - Some exceptions come straight from the wiki: Teemo's blind doesn't affect on-hit spells such as Parrrley; Riposte stuns back only after negating an immobilizing effect; Poppy's W can only ground a target whose dash it stopped; states from dying or transforming (Kayn's form change, Kog'Maw's zombie state) aren't dodges.
  - The weights are in one file (`engine/ledger/weights.ts`). Impact = how much the countered ability matters to its kit × how much of its use the counter covers × how completely it counters it. One counter used against several abilities counts with diminishing returns.
- **Ledger-only ranking** (marked partial): `counters/<champion>.md` and `rankings.json` rank every champion against every enemy. "Hard counter" badges go to interactions that shut down part of a kit every time it's used (projectiles, basic attacks, dashes, range). The build computes all 29,756 ledgers in about 7 seconds.
- **Commands.** `npm run matchup -- Fiora Darius` prints a full ledger; `npm run counters -- Tryndamere` prints a ranking.
- **What the ranking gets right and where it's limited:**
  - Against Tryndamere, Teemo ranks first (blind and range) and Jax 13th (Counter Strike dodges his attacks).
  - It counts interactions; it doesn't play the fight. Poppy vs Yasuo shows both hard counters (Poppy's W stops Sweeping Blade; Wind Wall blocks Keeper's Verdict) and nets them slightly in Yasuo's favor. Whether stopping Yasuo's dashes wins the fight is the simulator's call (M4-M5).
  - Without damage numbers or the stat budget, ranged champions with a dodge rank high against most melee champions.
- **Tests:** 306 pass. Besides the earlier suites:
  - glossary parsing;
  - profile facts;
  - the §8 interaction tests: Wind Wall blocks the Steel Tempest whirlwind but not Darius's E; Poppy's W doesn't stop Malphite's R; Teemo's blind doesn't make Parrrley miss; Riposte stuns back only against immobilizing effects;
  - ranking sanity checks.

### M4: simulator core and global rules (done)

- **Global rules** (`engine/rules/`). Each rule comes from a wiki page pinned by revision (the pages are fetched with the glossary) and is unit-tested against the wiki's own examples:
  - damage: resistance multipliers, including negative resistances; flat reduction, then percentage reduction, then percentage penetration, then lethality and flat magic penetration; damage dealt modifiers add up, damage received modifiers multiply;
  - shields absorb after resistances, the one expiring soonest first (Black Shield and Camille's W first of all), by damage type; Grievous Wounds cuts healing and health regeneration by 40%; critical strikes deal 200%;
  - movement speed soft caps; only the strongest slow applies; slow resist;
  - crowd control: what each of the 21 types disables, as in the wiki's summary table (a test keeps the two in step); tenacity, which multiplies within a group of sources and adds across groups; what it shortens; displacements; immobilizing types;
  - timing: 30 ticks per second, with durations rounded up to the next tick; ability haste; the attack speed cap and floor; the attack timer (windup, launch, then cooldown).
- **Kit format** (`engine/sim/spec.ts`). A fighter has level-20 stats, a basic attack, and abilities.
  - Each ability is a delivery plus effects:
    - deliveries: self, aura, unit-targeted (instant or a homing missile), line skillshot, ground circle, dash, blink;
    - effects: damage (with ratios of the caster's or target's stats), crowd control, knock-ups, knock-backs and pulls, shields, heals, defensive states, timed stat changes, damage over time, Grievous Wounds, cleanses, empowered attacks, attack resets, executes, projectile walls, delayed effects.
  - Channels and the wiki's interaction flags are part of the format.
  - Kit hooks handle what the generic effects can't. M5 compiles real champions into this format.
- **The fight** (`engine/sim/simulate.ts`, `combat.ts`, `actions.ts`):
  - Every interaction of the ledger happens in the fight as the wiki describes it, including:
    - spell shields; parries (Riposte stuns back only after negating an immobilizing effect); dodges, blocks and reflected damage;
    - blinds, which count only if present when an attack is declared; projectile walls and blocking auras;
    - untargetability, which drops homing missiles and attack windups and cancels a targeted cast without its cooldown;
    - crowd control and displacement immunity; knockdowns on dashes; channel interrupts;
    - minimum health thresholds against executes; sleep that a hit ends but damage over time doesn't.
  - One dimension, with the wiki's range rules:
    - attacks are measured edge to edge, unit-targeted spells and auras center to center, and skillshots center to the target's edge;
    - champions collide by pathing radius (35 for most);
    - charm drags, fear drives away, taunt forces attacks;
    - a target that walks out of attack range during a windup cancels the attack.
  - Windups and casts that end on the same tick all complete before either takes effect, so neither side gets the first word. Two deaths on one tick are a draw. The two sides alternate going first.
- **Skillshots.**
  - The hit chance compares the time until impact with the time the target needs to step out, after a 0.25 s reaction.
  - Decisive skillshots split the fight into a world where they land and one where they miss, weighted by that chance, up to 64 branches. A skillshot is decisive if it applies crowd control or deals at least 15% of the target's maximum health.
  - Minor ones count by their expected value.
  - A ready dash or blink can dodge.
  - The result is an exact probability under the model, and deterministic.
- **Default behavior** (`engine/sim/behavior.ts`):
  - It sees what the enemy starts only after the reaction time.
  - It saves defensive tools for the threats they answer:
    - a spell shield or untargetability for crowd control or a big hit;
    - a dodge for basic attacks;
    - crowd control immunity for immobilizing effects;
    - projectile blockers for projectiles;
    - a minimum health threshold for lethal damage;
    - a dash for a decisive skillshot.
  - It cleanses long crowd control and finishes with executes.
  - It leads with crowd control, throwing crowd control skillshots only when they're likely to land, and uses damage on cooldown.
  - It weaves attack resets between attacks, closes gaps, and kites when it out-ranges the enemy.
  - When chasing, it gets close enough that the target can't walk out of range during the windup.
  - Modes: fight, trade (walk in, use the burst, back off), hold (hit back without chasing), kite, flee.
- **Scenarios** (`engine/sim/scenarios.ts`). These are the six of §6, each scored from −1 to +1 and weighted 0.25 / 0.25 / 0.2 / 0.15 / 0.1 / 0.05:
  - The all-ins start from each side's longest opener, or its attack range.
  - The short trade is scored as the health exchanged in your trade minus in theirs.
  - Spacing applies only when one side out-ranges the other by 100 units or out-runs it by 15.
  - Escape compares how often each side gets away from the other's all-in, within 8 s or 1,400 units.
- **Stat budget** (`engine/budget.ts`, prices in `data/<dataset>/rules.json` from Module:Gold value/data):
  - It buys AD, AP, attack speed, crit, ability haste, lethality, magic penetration, health, armor and magic resistance in 50-gold steps.
  - Each step goes to whichever stat raises ln(damage per second against the enemy) + ln(effective health against the enemy's damage mix) the most. Damage follows the champion's own ratios; ability shields and heals count toward effective health.
  - The allocation runs twice, so each side answers what the other bought.
  - The default is 15,000 gold.
- **Command.** `npm run duel -- Garen Darius [--gold 15000] [--log brawl] [--sweep]` prints every scenario, what each side bought, a fight's timeline, and the score at budgets from 0 to 20,000 gold. Until M5 compiles the abilities, champions fight with base stats and basic attacks only.
- **Assumptions to review** (all in one place: `SimSettings` and `scenarios.ts`):
  - reaction time 0.25 s; hit-model spread 0.06 s;
  - an attack is cancelled once the target is past attack range (the wiki doesn't give a margin);
  - a trade lasts at most 4 s, and is over once the trader is 700 units away;
  - spell shields and similar tools are kept for crowd control or a hit worth 15% of maximum health.
- **Speed.** A matchup (budget plus six scenarios) takes about 26 ms with stats only, so all 29,756 pairings take about 13 minutes on one core. Real kits will cost more; M6 spreads the precompute across cores.
- **Tests.** 388 pass, 82 of them new:
  - the rules against the wiki's examples;
  - every generic mechanic on synthetic kits whose results are worked out by hand:
    - attack timing, missile travel, crits, empowered attacks and attack resets;
    - blinds, dodges, parries, projectile walls;
    - stuns and tenacity, slows and the soft cap, sleep, charm, fear and taunt;
    - delayed effects, dashes and knockdowns, channel interrupts;
    - spell shields with and without time to react, Riposte, untargetability during a cast time, cleanses, minimum health against executes;
    - shields, Grievous Wounds, damage over time and regeneration;
  - branching: weights sum to 1 over 16 branches, the expected value applies below the branch limit, and a dash dodges;
  - kiting, chasing, trades and escapes; mirror symmetry; the budget.

### M5: behavior wave 1 and golden matchups (built; waiting for your review)

- **Wave 1** (my pick; swap any): Aatrox, Camille, Darius, Dr. Mundo, Fiora, Garen, Gwen, Irelia, Jax, Malphite, Mordekaiser, Nasus, Olaf, Ornn, Poppy, Renekton, Riven, Sett, Shen, Teemo, Tryndamere, Urgot, Volibear, Yasuo, Yone.
- **Kits** (`kits/champions/<id>.ts`):
  - Every number is read from the wiki's ability data at level 20 and max rank, by label, field or quoted sentence (`engine/kits/context.ts`). A read fails loudly when the wiki's text changes.
  - Kits read only while they are built; a read during a fight throws.
  - What the wiki doesn't say is written down as an assumption. Each kit page (`kits/<id>.md`) now ends with the simulator's kit: every ability as the simulator sees it, the assumptions, and every wiki value read, with its revision.
  - Values with no level 19-20 formula use their level-18 value; each one is listed as an assumption.
- **Engine additions** for wave 1:
  - shared cooldowns between versions of a spell; casting during a dash (Umbral Dash during The Darkin Blade); aimed dashes and dashes through the enemy;
  - areas with sweet spots and weaker parts (The Darkin Blade, Decimate's handle); attacks split into physical, magic and true damage (Precision Protocol);
  - Purge replacing basic attacks; healing increases (World Ender); slow resist; minimum damage (Infected Bonesaw);
  - fair fights: each fight runs with each side moving first on tied ticks, at half weight each, so every score is exactly the negative of the reverse matchup;
  - crowd control shortens dodging: a stunned target only has the time after the stun to step out of a skillshot;
  - hits whose damage a kit's hooks compute (Haymaker grows with Grit) tell the enemy how big they are, so Riposte can parry them.
- **Wiki vs game files** (the 39 differences from M2): five concern wave 1, and three matter at max rank. The wiki's values are used, since each is a recent change in the ability's patch history that the game files don't have yet:
  - Camille's W cooldown, 10 (V26.16);
  - Jax's Q cost, 50 (V26.12);
  - Mordekaiser's E cooldown, 8 (V26.15).
  Mordekaiser's R and Volibear's Q cooldowns agree at max rank.
- **Stat budget changes:**
  - Percentage armor and magic penetration can be bought at their wiki gold values (41.67 and 46.15 per point). Each point is a separate 1% source, and sources multiply, so it never reaches 100%.
  - Penetration is capped near what items give (§10): 40 lethality; 35% armor penetration, the most items give (Lord Dominik's Regards); 40% magic penetration (Void Staff); 20 flat magic penetration (Spellslinger's Shoes). Uncapped, AD champions spent 5,000 to 7,000 of their 15,000 gold on penetration, up to 138 lethality, and armor stopped mattering. With the caps they buy 1,500 to 6,800 gold of armor.
  - Both sides answer each other over 8 rounds: each round, each side answers the average of what the other has built so far, and the result is the average of the answers. The old two-pass allocation left armor that didn't see the penetration coming.
  - Kits tell the budget what their hooks do: damage, healing, whether they attack at all (Urgot), stats worth more to them (Living Forge; Yasuo's and Yone's doubled crit), and extra gold (Ornn's Masterwork).
- **Results.** `npm run build:data` now runs all 300 wave-1 matchups on every core, in about a minute:
  - `counters/<id>.md` ranks the other 24 by their simulated score (full confidence), above the ledger ranking (partial);
  - `simulated.json` has every score and scenario;
  - `reports/simulator.md` has the standings, the golden matchups and what the budget buys.
  `npm run golden` prints the golden matchups' scores without a build.
- **Bugs the review found** (all fixed):
  - Sett's Right Punch nearly doubled his attack rate; the wiki's note says only its windup is faster.
  - Attacks made from bonus attack range (Riven, Gwen, Nasus, Renekton and Volibear buffs) were cancelled as out of range on every tick.
  - Irelia never used Defiant Dance, and Ornn hardly ever used his ultimate.
  - Fury of the Sands ignored its cap of 240 damage per second.
- **Golden matchups** (`tests/golden/matchups.ts`): 44 drafted, each with the kit interaction it rests on, for you to confirm, change or extend toward the 60 of §8. 41 hold. 3 are marked disputed and skipped by the tests until you decide:
  - Poppy vs Fiora: Fiora wins (−0.74). Poppy's damage is all physical; Fiora answers it with 5,600 gold of armor, and Poppy spends her gold on damage rather than health.
  - Fiora vs Aatrox: Aatrox wins (−0.25). Each of his hits shortens Deathbringer Stance's cooldown, so the budget buys him 312% attack speed.
  - Urgot vs Ornn: even (0.00). Every all-in runs the full 30 seconds: Ornn's armor, worth 30% more through Living Forge, holds against Urgot's all-physical damage.
  Before the penetration caps, Jax vs Tryndamere, Malphite vs Tryndamere, Teemo vs Garen and Gwen vs Malphite failed instead, and Poppy vs Fiora and Urgot vs Ornn held. Teemo vs Garen holds by a hair (+0.02).
- **Findings:**
  - *Scores are nearly all-or-nothing.* 225 of 300 matchups score beyond ±0.6, because a duel has one winner and the all-ins carry 70% of the weight. The score says who wins more than by how much, and one change can move a champion far (fixing Sett's Right Punch took him from first place to near the bottom).
  - *Plain stats bend some builds* away from anything an item build would give: Fiora spends 9,700 gold on AD (her Vitals grow with bonus AD), Gwen 8,500 on AP with no attack speed, Aatrox 7,800 on attack speed.
  - *Standings* (average score): Darius and Fiora lead (+0.64, +0.61); Riven, Yasuo and Urgot trail (−0.58, −0.47, −0.46), and the tanks Ornn and Shen are near the bottom.
- **Tests.** 541 pass and 3 are skipped (the disputed golden matchups). New: every wave-1 kit compiles and fights with several of its abilities, with spot checks of values read from the wiki; the engine additions on synthetic kits; fair-fight symmetry; the budget's penetration; the simulator pages and `simulated.json`.

### M6: web app on GitHub Pages (built; live once Pages is turned on)

- **The app** (`web/`, Vite + React) has four pages. The URL's hash addresses each one, so a static host serves them all from one file:
  - *Picker* (`#/vs/<champion>`):
    - Pick any champion as the enemy.
    - Simulated duels rank the other 24 wave-1 champions (full confidence); open a row for its six scenarios.
    - The interaction ledger ranks all 173 (partial), with hard-counter tags and the strongest reasons.
  - *Matchup* (`#/matchup/<you>/<enemy>`):
    - the verdict and each scenario's outcomes;
    - the timeline of each fight's likeliest branch;
    - both champions' level-20 numbers and what the budget bought;
    - the assumptions and every ledger interaction.
  - *Kit* (`#/kit/<champion>`):
    - base stats at level 20;
    - the simulator's kit, with its assumptions and every wiki value it read, linked to its revision;
    - the ledger's fight profile and the wiki's ability data.
  - *Settings*: gold, reaction time, lane surroundings, scenario weights, and the kit assumptions (Garen's Courage stacks, Nasus's Siphoning Strike stacks, Sett's Facebreaker stun). Udyr's Triple Tonic and rank split wait for his kit (M7).
- **Data.**
  - `npm run web:data` copies what the app reads from the newest dataset into `web/public/data/` (not committed). Every web build runs it.
  - Default results come precomputed from `simulated.json`.
  - The ledger runs in the browser from the profiles and the glossary.
- **Settings** stay in the visitor's browser.
  - Changing the weights reruns kit variant selection and the duels, because weights can change which rank split or upgrade is best.
  - Changing anything else reruns the duels against the chosen enemy, in up to four Web Workers (about 5 s for 24 duels). A banner says the results use the visitor's settings.
- **Shared ability text.** The text that describes abilities, effects and profiles moved from the pipeline's Markdown pages into `engine/`:
  - `engine/sim/describe.ts`;
  - `engine/abilityText.ts`;
  - `engine/profileText.ts`.

  The kit pages in `data/` and the app now say the same thing.
- **Timelines** now say who inflicts crowd control: "Darius: inflicts airborne for 0.50 s". The old line read as if Darius were airborne.
- **Deploy.** `.github/workflows/pages.yml`:
  - type-checks, tests and builds every pull request;
  - on each push to main, also publishes `web/dist` to GitHub Pages.

  Pages must be turned on once: Settings → Pages → Source: GitHub Actions.
- **Browser check** (Playwright, against the production build):
  - the picker loads in under a second;
  - a matchup simulates in about 0.8 s and matches `simulated.json`;
  - no page scrolls sideways at phone width (390 px), in light or dark mode;
  - no console errors.
- **Tests.** 557 pass and 3 are skipped. New tests cover:
  - the routes;
  - the settings: cleaning stored values, which changes rerun the fights, and blending;
  - four matchups run the way the browser runs them, which must match `simulated.json` to its three decimals, so the app's code and the precomputed data can't drift apart.

### M7: behavior wave 2 (built)

- **Wave 2**, 24 more top laners: Akali, Ambessa, Aurora, Cho'Gath, Gangplank, Gnar, Heimerdinger, Illaoi, Jayce, Kayle, K'Sante, Kennen, Kled, Pantheon, Quinn, Rumble, Singed, Sion, Skarner, Tahm Kench, Trundle, Udyr, Yorick and Zaahen. With wave 1, 49 champions have kits, and `simulated.json` holds 1,176 matchups.
- **Kits** that needed the most care:
  - *Udyr*: 24 stance ranks for 20 skill points (21 with Triple Tonic). Each matchup plays the rank split best against that enemy.
  - *Jayce*: two stances whose spells keep their own cooldowns, running in both stances; Hammer Stance's resistances hold only while he is in it.
  - *Kled*: Skaarl takes hits until she flees; Courage remounts him once.
  - *Gnar*: Rage, then Mega Gnar for 15 s, then tired for 15 s. Catching the boomerang or the boulder refunds part of their cooldown, and GNAR! stuns into walls.
  - *Sion*: Glory in Death's frenzy. *Tahm Kench*: grey health and Devour. *Skarner*: Ixtal's Impact into walls, broken by crowd control.
  - *The pet champions*: Illaoi's Tentacles and the Spirit; Yorick's graves, Mist Walkers and the Maiden; Heimerdinger's turrets, beams and upgrades (each matchup plays the upgrade best for him); Gangplank's Powder Kegs, which chain.
- **Engine additions**:
  - abilities: charge-ups, ability charges, recast chains, post-effect cooldowns and cooldown refunds;
  - movement: accelerating charges, charges the enemy can step aside from, leaps that take a fixed time, charges that lock on; casts and channels the caster can move during don't hold it still for skillshots;
  - fights: forms, lethal saves and two-life champions, invisibility, terrain, fields (chasing ones, and ones whose pulses come in clusters), damage that falls off on repeated hits, and damage over time that stacks;
  - pets: summons that fight, pets that count hits (Tentacles, kegs), pets their owner sets off, leashes, and area damage on pets;
  - kit variants: options each matchup chooses between, recorded for both sides when both kits have a choice (Heimerdinger against Udyr).
- **Lane setup.** When the lane was set up in advance (the default), Teemo's mushroom, Illaoi's Tentacle, Yorick's graves and Heimerdinger's turrets are on the field as the fight starts. The settings page turns that off for all four.
- **Audit** of the wave, narrower than planned: four kits (Akali, Ambessa, Aurora and Cho'Gath) were read in full against the wiki, and the other 20 only where a fight or the usage scan raised a question. The fights of all 24 were watched, and all 49 kits were scanned for abilities that never get used. It found:
  - Riven only used Wind Slash when it would kill, so it went unused in most fights. She now also fires it at its full bonus for the enemy's missing health, below 30% health, or just before Blade of the Exile ends; the bonus is read from the wiki.
  - Aurora's Between Worlds now leaps (25 to 250 units) before the shockwave, which starts ahead of where she lands.
  - Cast times: the wiki's "Cast time" article says nothing interrupts them except death, which is what the engine does. Charges and channels are interrupted as before.
- **Round robin of 49** (average score against the other 48; `reports/simulator.md` has the full table):
  - top: Yorick +0.74, K'Sante +0.61, Trundle +0.58, Fiora +0.54, Zaahen +0.51;
  - bottom: Akali −0.71, Ambessa −0.61, Pantheon −0.52, Skarner −0.50, Sett −0.46.
- **Outliers**, checked against the wiki and their fights; no kit bug was found behind any of them. A win is any score above 0:
  - *Yorick* wins 47 of 48 and loses only to Zaahen; all his wins but Aatrox (+0.21) are by 0.25 or more. His summons' damage is mostly their own: a Mist Walker hits for 113 at level 20 and the Maiden for 100 (plus Touch of the Maiden's share of maximum health), with 20% and 30% of his bonus AD on top, as the wiki gives it. That bonus is small next to their base damage, so the budget buys him health and resistances instead (5,600, 4,600 and 1,600 gold on average), and the health also makes his summons tankier: they get 15% and 60% of his bonus health.
  - *K'Sante* loses only to Fiora, Olaf, Yorick, Trundle, Tryndamere and, narrowly (−0.21), Garen. His abilities scale with bonus armor and magic resistance, so the resistances the budget buys are also his damage; All Out adds true damage on top.
  - *Trundle* loses only to Dr. Mundo, Nasus, Tryndamere, Tahm Kench and Yorick: Subjugate takes 30% of the enemy's maximum health and 40% of its resistances.
  - *Akali* loses 47 of 48 matchups; her one win, over Pantheon, is narrow (+0.24). Her abilities scale with AP, but per gold the budget's damage model finds AD better for her, since it also feeds her attacks; without items like Lich Bane or Hextech Rocketbelt, she ends up an auto-attacker with weak spells. This is the cost of plain stats (section 10), not of her kit.
  - *Ambessa* spends her budget on damage (5,000 gold of AD, 3,000 of critical strike, no health) and loses the long fights.
- **Golden matchups.** 25 new kit-driven expectations for wave 2, across the existing groups: dashes Poppy stops, range and blinds, dodges and parries, tank busters, immunity and armor. 64 of 69 hold. Two new ones are disputed, with what the simulator shows instead:
  - Trundle beats Dr. Mundo: Mundo's 8,600 gold of health, Maximum Dosage and armor outlast Subjugate.
  - Malphite beats Gangplank: both buy armor, so Gangplank's true and magic damage carry the long fight.
- **Tests.** 744 pass and 5 are skipped (the disputed golden matchups). New: every wave-2 kit's values from the wiki and its fights, tick by tick; the engine additions on synthetic kits; both sides' kit options in matchups, in the build and in the browser.
- **Known gap: quoted restrictions can go untested.** A kit quoting a wiki rule ("Trial by Fire cannot be applied with Parrrley nor Powder Keg") only checks that the sentence is still on the wiki; the kit's code enforces the rule, and a test may or may not. Breaking the four restrictions Akali, Ambessa and Aurora quote, in eight ways one at a time (attacks that don't break stealth, or break it at the wrong point of the windup; Ambessa acting while she holds the enemy), failed no test, and seven of the eight changed matchup results: with Ambessa able to attack while she holds the enemy, her loss to Gnar (−0.56) becomes a win (+0.76). Before wave 3: a test for each quoted restriction, each shown to fail when its rule is broken, then a full audit of the 49 kits.
